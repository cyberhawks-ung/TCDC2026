#!/usr/bin/env bash
# =============================================================================
#  lockdown.sh  -  interactive Linux hardening for blue-team competitions
#  Target: Ubuntu / Debian.  Run as root.  Keep a second root session open.
#
#  Every change is shown first and needs a "y". Every file touched is backed
#  up first, and --rollback puts it back.
#
#  Usage:
#    sudo ./lockdown.sh                 text menu: explains each module, then audit or harden it
#    sudo ./lockdown.sh --all           run all modules in order, confirm each change
#    sudo ./lockdown.sh --audit         report only, change nothing
#    sudo ./lockdown.sh --only ssh,firewall    run only the listed modules
#    sudo ./lockdown.sh --list          list modules
#    sudo ./lockdown.sh --baseline      save a snapshot of system state
#    sudo ./lockdown.sh --diff [F.tgz]  compare the system against the snapshot (or an off-box copy)
#    sudo ./lockdown.sh --watch 120     re-check every 120s and print new changes
#    sudo ./lockdown.sh --rollback      undo the last run (files, services, SUID bits, firewall)
#    sudo ./lockdown.sh --runs          list runs;  --rollback run-YYYYMMDD-HHMMSS undoes a specific one
#    sudo ./lockdown.sh --yes           apply without asking (not recommended)
#
#  Optional config: put a lockdown.conf next to the script (see lockdown.conf.example).
# =============================================================================
set -uo pipefail
shopt -s lastpipe

VERSION="1.4"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BK_ROOT="/root/.lockdown"
LOG="$BK_ROOT/lockdown.log"
# new_run: start a fresh run folder (called at start, and again after an undo in the menu)
new_run() {
  TS="$(date +%Y%m%d-%H%M%S)"
  BK="$BK_ROOT/run-$TS"
  local n=1; while [[ -e "$BK" ]]; do BK="$BK_ROOT/run-$TS-$n"; n=$((n+1)); done
  BACKUP_DONE=false
}
new_run

# ---- defaults (override in lockdown.conf) -----------------------------------
ADMIN_USERS=""            # users that should keep sudo, e.g. "blueadmin"
KEEP_USERS=""             # users that must keep working logins (scoring users)
SERVICE_USERS=""          # service accounts whose credentials Black Team sent on Discord (scorer may use them too)
ALLOWED_PORTS=""          # e.g. "22/tcp 80/tcp 443/tcp 3306/tcp 53/udp" ; empty = auto-detect
SSH_PERMIT_ROOT="no"      # no | prohibit-password | yes
SSH_PASSWORD_AUTH="yes"   # keep yes if the scoring engine logs in with passwords
SSH_ALLOW_FORWARDING="no" # yes on the jumpbox: you tunnel/proxy through it (ssh -L/-D)
IS_JUMPBOX="no"           # yes = the team jumpbox (R6/R16): your own attack tooling lives here, Docker runs the
                          # browser/RDP clients on 3001-3008; outbound shells are reported, never offered for killing
FW_ROLLBACK_SECS=90       # firewall auto-reverts unless you confirm within this time
WEB_ROOTS="/var/www /srv/www /usr/share/nginx/html"
# Never locked, de-sudo'd, re-keyed or re-passworded by this script (TCDC R7/R8).
PROTECTED_USERS="root blackteam whiteteam"
# Services, units and processes the script must never stop, kill or quarantine (TCDC R7/R15).
PROTECTED_RE='wazuh|ossec|auditd|audispd|cloud-init|cloud-config|cloud-final|xe-daemon|xe-guest|xe-linux-distribution|xen|xenstore'
# Scanner findings matching this regex are stock-Ubuntu false positives: counted, not shown.
SCAN_IGNORE_RE='/etc/\.java|/usr/lib/debug/\.build-id|\.jinfo$|/usr/lib/libreoffice/share/\.registry|RTNETLINK answers|/proc/[0-9]+/fd/[0-9]+: Permission denied|The modules file .?/proc/modules.? is missing|kernel modules directory|/dev/shm/(PostgreSQL|pulse-shm|sem\.|mono)|/etc/\.updated|/etc/\.resolv\.conf\.systemd-resolved\.bak|/usr/share/man/man5/\.k5|/lib/modules/[^ ]*/vdso/\.build-id'
CLAMAV_MIN_MB=1500        # skip clamscan when less RAM than this is free (it can OOM-kill scored services)
HEAVY_EVERY=5             # --watch: run the slower SUID/capability scans every Nth check only
SCORED_PORTS=""           # e.g. "53/tcp 53/udp": the service guard and --watch alert when these stop listening
                          # (empty = whatever non-loopback ports are listening when a hardening run starts)
WATCH_DIRS=""             # extra folders whose files --diff/--watch track (repos, FTP roots, app dirs), e.g. "/srv /opt/app"
# Optional per-host settings: define ALLOWED_PORTS etc. inside  case "$(hostname -s)" in ... esac  in lockdown.conf
CONF="$SCRIPT_DIR/lockdown.conf"
if [[ -f "$CONF" ]]; then
  # only load a config that only root can change: it runs as root
  if [[ "$(stat -c '%u' "$CONF")" != 0 || -n "$(find "$CONF" "$SCRIPT_DIR" -maxdepth 0 -perm /022 2>/dev/null)" ]]; then
    echo "refusing to load $CONF: it or its folder is not root-owned or is group/world-writable."
    echo "fix:  chown root:root '$CONF' '$SCRIPT_DIR'; chmod go-w '$CONF' '$SCRIPT_DIR'"; exit 1
  fi
  # shellcheck source=/dev/null
  source "$CONF"
fi

AUDIT=false; YES=false; ONLY=""; MODE="harden"; WATCH_SECS=120
CHANGES=0; WARNS=0

# ---- output helpers ----------------------------------------------------------
if [[ -t 1 ]]; then R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; C=$'\e[36m'; B=$'\e[1m'; N=$'\e[0m'
else R=""; G=""; Y=""; C=""; B=""; N=""; fi
log()  { mkdir -p "$BK_ROOT"; echo "[$(date +%T)] $*" >> "$LOG"; }
hdr()  { printf "\n%s== %s ==%s\n" "$B$C" "$*" "$N"; log "== $*"; }
ok()   { printf "  %s[ok]%s %s\n" "$G" "$N" "$*"; }
info() { printf "  %s[..]%s %s\n" "$C" "$N" "$*"; }
warn() { printf "  %s[!!]%s %s\n" "$Y" "$N" "$*"; WARNS=$((WARNS+1)); log "WARN $*"; }
bad()  { printf "  %s[XX]%s %s\n" "$R" "$N" "$*"; WARNS=$((WARNS+1)); log "BAD $*"; }
did()  { printf "  %s[+]%s  %s\n" "$G" "$N" "$*"; CHANGES=$((CHANGES+1)); log "CHANGE $*"; }
have() { command -v "$1" >/dev/null 2>&1; }

# ask "question" -> 0 if the user said yes. Never true in --audit.
ask() {
  $AUDIT && return 1
  $YES && return 0
  local a; read -r -p "  ${Y}?${N} $1 [y/N] " a </dev/tty || return 1
  [[ $a =~ ^[Yy] ]]
}
# ask_risky: like ask, but --yes does NOT answer it. Used for anything that can break scoring or
# remove evidence (locking users, deleting keys/crontabs, disabling units, killing, stripping SUID, DB drops).
ask_risky() {
  $AUDIT && return 1
  if $YES; then info "--yes: skipped (needs a human): $1"; return 1; fi
  ask "$1"
}
# prompt "question" "default" -> echoes the answer (editable default)
prompt() {
  local a
  if $YES || $AUDIT; then echo "$2"; return; fi
  read -r -e -p "  ${Y}?${N} $1 " -i "$2" a </dev/tty || a="$2"
  echo "$a"
}
# backup_file PATH : copy once per run into $BK/files/PATH and record in manifest
backup_file() {
  local f="$1" dest="$BK/files$1"
  [[ -e "$f" ]] || { grep -qxF "NEW:$f" "$BK/manifest" 2>/dev/null || echo "NEW:$f" >> "$BK/manifest"; return 0; }
  mkdir -p "$(dirname "$dest")"
  [[ -e "$dest" ]] || cp -a "$f" "$dest"
  grep -qxF "$f" "$BK/manifest" 2>/dev/null || echo "$f" >> "$BK/manifest"
}
in_list() { local x="$1"; shift; for i in $*; do [[ "$i" == "$x" ]] && return 0; done; return 1; }
protected() { in_list "$1" $PROTECTED_USERS && { info "skipping $1 (protected user)"; return 0; }; return 1; }
# scoring_user: the scorer may log in as this account (packet users + service users). Never lock it or take its shell:
# FTP (vsftpd uses pam_shells) and SSH logins both fail for an account whose shell is nologin.
scoring_user() { in_list "$1" $KEEP_USERS $ADMIN_USERS $SERVICE_USERS; }
protected_thing() { [[ "$1" =~ $PROTECTED_RE ]] && { info "skipping $1 (competition infrastructure)"; return 0; }; return 1; }
# owned_by_pkg PATH : true if dpkg knows the file (handles merged /usr: /lib <-> /usr/lib, /bin <-> /usr/bin)
PKG_FILES=""
owned_by_pkg() {
  local f="$1" alt
  if [[ -z "$PKG_FILES" ]]; then
    PKG_FILES="$(mktemp)"; cat /var/lib/dpkg/info/*.list 2>/dev/null | sort -u > "$PKG_FILES"
  fi
  case "$f" in /usr/*) alt="${f#/usr}";; *) alt="/usr$f";; esac
  grep -qxF -e "$f" -e "$alt" -e "$(readlink -f "$f")" "$PKG_FILES"
}
cleanup() { [[ -n "$PKG_FILES" ]] && rm -f "$PKG_FILES"; [[ -n "${WATCH_TMP:-}" ]] && rm -rf "$WATCH_TMP"; }
trap cleanup EXIT
# restore_file SRC DEST : copy next to DEST then rename over it, so DEST is never missing
# (old code did rm then cp: if cp failed, /etc/shadow was simply gone)
restore_file() {
  local src="$1" dest="$2" tmp
  tmp="$(dirname "$dest")/.lockdown-restore.$$"
  rm -rf "$tmp"
  cp -a "$src" "$tmp" || { rm -rf "$tmp"; return 1; }
  if [[ -d "$tmp" && -d "$dest" ]]; then rm -rf "$dest.lockdown-old"; mv "$dest" "$dest.lockdown-old" && mv "$tmp" "$dest" && rm -rf "$dest.lockdown-old"
  else mv -fT "$tmp" "$dest"; fi
}
# pkg_status PATH -> "packaged, unchanged" / "packaged, MODIFIED" / "not from a package"
# Used to label scanner hits: a packaged file whose checksum still matches is almost always a false positive.
pkg_status() {
  local f="$1" pkg
  [[ -e "$f" ]] || { echo "missing"; return; }
  local rf; rf="$(readlink -f "$f")"
  # dpkg -S is a pattern search ("/dev" matches base-files): require an exact path match
  pkg="$(dpkg -S "$f" "$rf" 2>/dev/null | awk -F': ' -v a="$f" -v b="$rf" '$2==a || $2==b {print $1; exit}')"
  [[ -z "$pkg" ]] && { echo "not from a package"; return; }
  if dpkg --verify "${pkg%%,*}" 2>/dev/null | awk -v a="$f" -v b="$rf" '$NF==a || $NF==b {x=1} END{exit !x}'; then echo "packaged ($pkg), MODIFIED"
  else echo "packaged ($pkg), unchanged"; fi
}
VISUDO="$(command -v visudo || command -v visudo-rs || true)"   # Ubuntu 26.04: sudo is sudo-rs
login_users() { awk -F: '$7 !~ /(nologin|false|sync|halt|shutdown)$/ {print $1}' /etc/passwd; }

# =============================================================================
# MODULES
# =============================================================================
MODULES="backup inventory users sudo ssh keys firewall persistence services sysctl perms caps web db other scanners baseline"

mod_backup() {
  hdr "Backup"
  if $AUDIT; then info "audit mode: no backup needed"; return; fi
  local free_mb; free_mb="$(df -Pm /root 2>/dev/null | awk 'NR==2{print $4}')"
  if [[ "${free_mb:-0}" -lt 300 ]]; then
    bad "only ${free_mb}MB free on /root's filesystem: a full disk takes services down. Old runs: du -sh $BK_ROOT/run-*"
    ask "Continue anyway?" || exit 1
  fi
  mkdir -p "$BK"; chmod 700 "$BK_ROOT"; touch "$BK/manifest"
  ln -sfn "$BK" "$BK_ROOT/latest"
  tar -czpf "$BK/etc-full.tgz" -C / etc 2>/dev/null && ok "full /etc snapshot: $BK/etc-full.tgz"
  iptables-save > "$BK/iptables.rules" 2>/dev/null || true
  have ip6tables-save && ip6tables-save > "$BK/ip6tables.rules" 2>/dev/null || true
  ok "per-file backups go to $BK/files (used by --rollback)"
}

mod_inventory() {
  hdr "Inventory"
  info "host: $(hostname)  kernel: $(uname -r)  os: $(. /etc/os-release; echo "$PRETTY_NAME")"
  info "IPs: $(hostname -I 2>/dev/null)"
  echo "  -- login-capable users:"; login_users | sed 's/^/     /'
  echo "  -- UID 0 accounts:";      awk -F: '$3==0{print "     "$1}' /etc/passwd
  echo "  -- sudo/admin group:";    getent group sudo admin wheel 2>/dev/null | sed 's/^/     /'
  echo "  -- listening sockets:"
  ss -tulnpH 2>/dev/null | awk '{printf "     %-5s %-28s %s\n",$1,$5,$7}'
  echo "  -- logged-in sessions:";  who 2>/dev/null | sed 's/^/     /'
}

# save_acct USER : remember shell, expiry and password hash ONCE per run, so rollback can put
# back exactly this account instead of restoring the whole of /etc/passwd + /etc/shadow
# (whole-file restore silently wiped users and groups created after the run).
save_acct() {
  local u="$1" d="$BK/acct"
  [[ -e "$d/$u" ]] && return 0
  mkdir -p "$d"; chmod 700 "$d"
  printf '%s\n%s\n%s\n' "$(getent passwd "$u" | cut -d: -f7)" "$(getent shadow "$u" | cut -d: -f8)" "$(getent shadow "$u" | cut -d: -f2)" > "$d/$u"
  chmod 600 "$d/$u"
  echo "acct:$u" >> "$BK/manifest"
}
lock_user() {   # lock_user USER : locked password, nologin shell, expired (expiry also blocks SSH keys via PAM)
  save_acct "$1"
  passwd -l "$1" >/dev/null 2>&1; usermod -s /usr/sbin/nologin -e 1 "$1" && did "locked $1"
}

mod_users() {
  hdr "Users"
  local u
  # extra UID 0
  for u in $(awk -F: '$3==0 && $1!="root"{print $1}' /etc/passwd); do
    bad "UID 0 account that isn't root: $u"
    protected "$u" && continue
    ask_risky "Lock $u (password locked, shell nologin, expired)?" && lock_user "$u"
  done
  # password hash stored directly in /etc/passwd, or passwd/shadow out of sync
  awk -F: '$2!="x" && $2!="*" && $2!="!" {print $1}' /etc/passwd | while read -r u; do
    bad "$u has a password hash in /etc/passwd itself (bypasses /etc/shadow)"
  done
  have pwck && pwck -rq 2>&1 | sed 's/^/     pwck: /'
  # empty passwords
  for u in $(awk -F: '($2==""){print $1}' /etc/shadow); do
    bad "account with EMPTY password: $u"
    protected "$u" && continue
    if scoring_user "$u"; then bad "  $u is a scoring user: DON'T lock it. Rotate its password below (and update the dashboard)."; continue; fi
    ask_risky "Lock $u? (its FTP/SSH logins stop working)" && lock_user "$u"
  done
  # system accounts (UID < 1000) that were given a real shell: classic backdoor (www-data -> /bin/bash)
  local shell uid
  while IFS=: read -r u _ uid _ _ _ shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || { [[ -n "$u" ]] && bad "malformed /etc/passwd line for '$u' (uid '$uid')"; continue; }
    [[ "$uid" -eq 0 || "$uid" -ge 1000 ]] && continue
    [[ "$shell" =~ (nologin|false|sync|halt|shutdown)$ || -z "$shell" ]] && continue
    in_list "$u" $PROTECTED_USERS && continue
    scoring_user "$u" && continue
    warn "system account $u (uid $uid) has a login shell: $shell"
    if ps -o user= -p "$(listener_pids "$(listening_ports | tr '\n' ' ')" | tr '\n' ',' | sed 's/,$//')" 2>/dev/null | grep -qx "$u"; then
      info "  $u runs a listening service: left alone (its scripts may rely on that shell)"; continue
    fi
    if ask_risky "Set $u's shell to nologin? (its FTP and SSH logins stop working: if it's a service user from Discord, put it in SERVICE_USERS instead)"; then
      save_acct "$u"; usermod -s /usr/sbin/nologin "$u" && did "$u shell -> nologin"
    fi
  done < /etc/passwd
  # unexpected login users
  local users; users="$(login_users | tr '\n' ' ')"
  info "login-capable users: $users"
  local keep="${KEEP_USERS:-}"
  [[ -z "$keep" ]] && keep="$(prompt "Users to KEEP (scoring + your team). Everyone else is offered for locking:" "$users")"
  for u in $users; do
    in_list "$u" $PROTECTED_USERS && continue
    in_list "$u" $keep $ADMIN_USERS $SERVICE_USERS && continue
    [[ "$(id -u "$u" 2>/dev/null || echo 0)" -lt 1000 ]] && continue   # handled above
    warn "not on keep list: $u ($(getent passwd "$u" | cut -d: -f6,7))"
    ask_risky "Lock $u (passwd -l, shell nologin, expire)? If it's a service user from Discord, answer n and add it to SERVICE_USERS" && lock_user "$u"
  done
  # password rotation
  local rot; rot="$(prompt "Rotate passwords for which users? (space-separated, blank = none):" "")"
  if [[ -n "$rot" ]] && ! $AUDIT; then
    local pf="/root/lockdown-passwords-$TS.txt"; ( umask 077; : > "$pf" )   # subshell: umask doesn't leak
    for u in $rot; do
      id "$u" >/dev/null 2>&1 || { warn "no such user $u"; continue; }
      if [[ "$u" == root ]]; then
        confirm_typed root "root's password is likely a known default. Changing it is allowed (R8 protects only blackteam/whiteteam); make sure Black Team doesn't need it." || continue
      elif protected "$u"; then continue; fi
      local pw; pw="$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 16)"
      save_acct "$u"
      echo "$u:$pw" | chpasswd && echo "$u:$pw" >> "$pf" && did "new password for $u"
    done
    ok "passwords saved to $pf (root-only). Put them in your team's password list (passwords are allowed off-box, R23), then: shred -u $pf"
    bad "UPDATE EVERY CHANGED PASSWORD AT https://dash.playtcdc.org/team/passwords NOW. You aren't told which OS or service user a check uses, so update every one listed there that you changed."
    sed 's/^/     /' "$pf"
  fi
}

# sudoers_plan FILE -> "STRIP|DROP|KEEP<TAB>line" for every rule line that grants something
#   STRIP = admin (ADMIN_USERS, root, %sudo/%admin/%wheel) rule with NOPASSWD -> keep the rule, drop the tag
#   DROP  = rule for anyone else (employees, unknown users, other groups)  -> comment out the whole rule
#   KEEP  = names a protected user anywhere, or uses a User_Alias           -> never touched
SUDOERS_AWK='BEGIN{ n=split(prot,a," "); for(i=1;i<=n;i++) P[a[i]]=1; n=split(adm,a," "); for(i=1;i<=n;i++) A[a[i]]=1
                     G["sudo"]=1; G["admin"]=1; G["wheel"]=1 }
  function cls(line,   who, u) {
    if (line ~ /^[ \t]*(#|$)/ || line ~ /^[ \t]*Defaults/ || line ~ /^[ \t]*[@#]include/ || line ~ /^[ \t]*[A-Za-z_]+_Alias/) return ""
    split(line, f, /[ \t]+/); who=f[1]; if (who=="") who=f[2]
    for (u in P) if (line ~ ("(^|[^A-Za-z0-9_])" u "([^A-Za-z0-9_]|$)")) return "KEEP"
    if (who ~ /^[A-Z][A-Z0-9_]*$/) return "KEEP"
    if (who ~ /,/) return "DROP"
    if (substr(who,1,1)=="%") return (substr(who,2) in G) ? ((line ~ /NOPASSWD/) ? "STRIP" : "") : "DROP"
    if (who in A) return (line ~ /NOPASSWD/) ? "STRIP" : ""
    return "DROP" }'
sudoers_plan() {
  awk -v prot="$PROTECTED_USERS" -v adm="root $ADMIN_USERS" "$SUDOERS_AWK"'
    { c=cls($0); if (c!="") print c "\t" $0 }' "$1"
}
sudoers_apply() {   # sudoers_apply FILE STRIP(true|false) DROP(true|false) -> new file content on stdout
  awk -v prot="$PROTECTED_USERS" -v adm="root $ADMIN_USERS" -v st="$2" -v dr="$3" "$SUDOERS_AWK"'
    { c=cls($0)
      if (c=="STRIP" && st=="true") { l=$0; gsub(/NOPASSWD:[ \t]*/,"",l); print "# lockdown: removed NOPASSWD from the next line"; print l; next }
      if (c=="DROP" && dr=="true")  { print "# lockdown: " $0; next }
      print }' "$1"
}

mod_sudo() {
  hdr "Sudo"
  local members u g gid
  # supplementary members AND users whose primary group is sudo/admin/wheel
  members="$(getent group sudo admin wheel 2>/dev/null | cut -d: -f4 | tr ',' ' ')"
  for g in sudo admin wheel; do
    gid="$(getent group "$g" | cut -d: -f3)"; [[ -n "$gid" ]] || continue
    for u in $(awk -F: -v g="$gid" '$4==g{print $1}' /etc/passwd); do
      bad "$u has $g as its PRIMARY group (doesn't show in the group's member list)"; members="$members $u"
    done
  done
  members="$(echo $members | tr ' ' '\n' | sort -u | tr '\n' ' ')"
  info "sudo-group members: ${members:-none}"
  role_check | while read -r l; do bad "${l#ROLE: }"; done
  # groups that are root in disguise
  for g in docker lxd disk; do
    local m; m="$(getent group "$g" | cut -d: -f4)"
    [[ -n "$m" ]] && warn "members of '$g' can become root: $m"
  done
  local admins="${ADMIN_USERS:-}"
  [[ -z "$admins" ]] && admins="$(prompt "Users that should KEEP sudo:" "$members")"
  for u in $members; do
    in_list "$u" $admins $PROTECTED_USERS && continue
    warn "$u has sudo but isn't on the admin list"
    if ask_risky "Remove $u from sudo/admin/wheel groups?"; then
      for g in sudo admin wheel; do
        id -nG "$u" 2>/dev/null | tr ' ' '\n' | grep -qx "$g" || continue
        gpasswd -d "$u" "$g" >/dev/null 2>&1 && echo "grp:$u:$g" >> "$BK/manifest"
      done
      did "removed $u from sudo groups"
      local pg; pg="$(id -gn "$u")"; [[ "$pg" =~ ^(sudo|admin|wheel)$ ]] && bad "  $u's PRIMARY group is still $pg: change it by hand (usermod -g $u $u)"
    fi
  done
  # direct sudoers grants, NOPASSWD and dangerous Defaults
  local f
  local files; files="/etc/sudoers $(ls -d /etc/sudoers.d/* 2>/dev/null | tr '\n' ' ')"
  # follow @includedir/#includedir that point somewhere other than /etc/sudoers.d
  local inc; for inc in $(grep -hE '^\s*[@#]include(dir)?\s' /etc/sudoers /etc/sudoers.d/* 2>/dev/null | awk '{print $2}'); do
    [[ "$inc" == /etc/sudoers.d || "$inc" == /etc/sudoers.d/ ]] && continue
    bad "sudoers includes $inc (non-standard location)"; files="$files $(ls -d "$inc" "$inc"/* 2>/dev/null | tr '\n' ' ')"
  done
  for f in $files; do
    [[ -f "$f" ]] || continue
    grep -nEv '^\s*(#|Defaults|$|@include|#include)' "$f" | while read -r line; do echo "     $f:$line"; done
    grep -nE '^\s*Defaults.*(!authenticate|env_keep.*LD_|env_keep.*PYTHONPATH|!env_reset)' "$f" | while read -r l; do bad "dangerous sudo Defaults in $f: $l"; done
    if [[ "$f" =~ cloud-init ]]; then info "$f belongs to cloud-init (out of scope, R7): report only. Lock its user if nobody needs it."; continue; fi
    # classify every rule line: admin rules only lose NOPASSWD; rules giving root to anyone else are removed;
    # rules naming protected staff (also inside aliases) and alias-based rules are left alone (R7/R8)
    local plan; plan="$(sudoers_plan "$f")"
    local n_strip n_drop; n_strip="$(grep -c '^STRIP' <<< "$plan")"; n_drop="$(grep -c '^DROP' <<< "$plan")"
    [[ "$n_strip" -gt 0 ]] && { bad "admin rule(s) with NOPASSWD in $f:"; grep '^STRIP' <<< "$plan" | cut -f2- | sed 's/^/     /'; }
    [[ "$n_drop" -gt 0 ]] && { bad "rule(s) in $f giving root to someone who is NOT on the admin list:"; grep '^DROP' <<< "$plan" | cut -f2- | sed 's/^/     /'; }
    grep '^KEEP' <<< "$plan" | cut -f2- | while read -r l; do info "left alone (staff/alias): $l"; done
    [[ "$n_strip" -eq 0 && "$n_drop" -eq 0 ]] && continue
    [[ -z "$VISUDO" ]] && { warn "no visudo/visudo-rs to validate edits: fix these by hand"; continue; }
    local do_strip=false do_drop=false
    [[ "$n_strip" -gt 0 ]] && ask "Remove NOPASSWD from the admin rule(s) above (they keep sudo, but need their password)?" && do_strip=true
    [[ "$n_drop" -gt 0 ]] && ask_risky "Comment out the non-admin rule(s) above (those users lose sudo)?" && do_drop=true
    $do_strip || $do_drop || continue
    backup_file "$f"
    sudoers_apply "$f" "$do_strip" "$do_drop" > "$f.lockdown.tmp" && cat "$f.lockdown.tmp" > "$f"; rm -f "$f.lockdown.tmp"
    if cmp -s "$f" "$BK/files$f"; then info "nothing changed in $f"
    elif $VISUDO -c >/dev/null 2>&1; then did "sudoers updated: $f"
    else restore_file "$BK/files$f" "$f"; bad "visudo check failed, restored $f"; fi
  done
}

mod_ssh() {
  hdr "SSH"
  [[ -f /etc/ssh/sshd_config ]] || { info "sshd not installed, skipping"; return; }
  # Ubuntu 22.10+ (socket activation): /run/sshd may not exist yet, and then sshd -t / -T fail
  mkdir -p /run/sshd; chmod 755 /run/sshd
  local target
  if grep -qE '^\s*Include\s+/etc/ssh/sshd_config\.d' /etc/ssh/sshd_config; then
    target=/etc/ssh/sshd_config.d/00-lockdown.conf   # first value read wins in sshd
    # any drop-in that sorts BEFORE ours overrides us
    local d; for d in /etc/ssh/sshd_config.d/*.conf; do
      [[ -f "$d" && "$d" != "$target" ]] || continue
      [[ "$(basename "$d")" < "00-lockdown.conf" ]] && bad "$d sorts before 00-lockdown.conf and overrides it: $(grep -vcE '^\s*(#|$)' "$d") active lines"
    done
  else target=/etc/ssh/sshd_config; fi
  grep -rnE '^\s*(ForceCommand|AuthorizedKeysCommand|AuthorizedPrincipalsCommand)\s' /etc/ssh/sshd_config /etc/ssh/sshd_config.d 2>/dev/null | while read -r l; do bad "sshd: $l"; done
  [[ -s /etc/ssh/sshrc ]] && bad "/etc/ssh/sshrc exists (runs on every SSH login): $(head -c 120 /etc/ssh/sshrc)"
  local h; for h in /root /home/*; do [[ -s "$h/.ssh/rc" ]] && bad "$h/.ssh/rc exists (runs on every SSH login for that user)"; done
  local settings="PermitRootLogin $SSH_PERMIT_ROOT
PasswordAuthentication $SSH_PASSWORD_AUTH
PermitEmptyPasswords no
PubkeyAuthentication yes
MaxAuthTries 4
LoginGraceTime 30
X11Forwarding no
AllowAgentForwarding no
AllowTcpForwarding $SSH_ALLOW_FORWARDING
PermitTunnel no
PermitUserEnvironment no
HostbasedAuthentication no
IgnoreRhosts yes
ClientAliveInterval 300
ClientAliveCountMax 2"
  info "current effective settings:"
  sshd -T 2>/dev/null | grep -Ei '^(permitrootlogin|passwordauthentication|permitemptypasswords|maxauthtries|x11forwarding|allowtcpforwarding|authorizedkeysfile) ' | sed 's/^/     /'
  echo "  proposed (written to $target):"; echo "$settings" | sed 's/^/     /'
  ask "Apply these SSH settings? (keep this session open!)" || return
  backup_file "$target"; backup_file /etc/ssh/sshd_config
  if [[ "$target" == *00-lockdown.conf ]]; then
    printf "# written by lockdown.sh %s\n%s\n" "$TS" "$settings" > "$target"
  else
    local tmp; tmp="$(mktemp)"
    printf "# lockdown.sh %s\n%s\n\n" "$TS" "$settings" > "$tmp"
    local k; for k in $(echo "$settings" | awk '{print $1}'); do sed -i -E "s/^\s*($k\s.*)$/# lockdown: \1/I" /etc/ssh/sshd_config; done
    cat /etc/ssh/sshd_config >> "$tmp"; cat "$tmp" > /etc/ssh/sshd_config; rm -f "$tmp"
  fi
  local err
  if err="$(sshd -t 2>&1)"; then
    systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || service ssh reload 2>/dev/null
    did "sshd hardened and reloaded. Test a NEW login before closing this session."
    # confirm the values sshd will really use (another file can still win)
    local eff k v want
    eff="$(sshd -T 2>/dev/null)"
    while read -r k want; do
      [[ -z "$k" ]] && continue
      v="$(echo "$eff" | awk -v k="${k,,}" '$1==k{print $2; exit}')"
      [[ -n "$v" && "${v,,}" != "${want,,}" ]] && bad "effective $k is '$v', not '$want': another config file wins"
    done <<< "$settings"
  else
    bad "sshd -t failed, restoring. Error was:"; echo "$err" | sed 's/^/     /'
    if [[ -e "$BK/files$target" ]]; then restore_file "$BK/files$target" "$target"; else rm -f "$target"; fi
    restore_file "$BK/files/etc/ssh/sshd_config" /etc/ssh/sshd_config
  fi
}

mod_keys() {
  hdr "SSH authorized_keys"
  local f home
  while IFS=: read -r u _ _ _ _ home _; do
    for f in "$home/.ssh/authorized_keys" "$home/.ssh/authorized_keys2"; do
      [[ -f "$f" ]] || continue
      in_list "$u" $PROTECTED_USERS && [[ "$u" != "root" ]] && { info "$u: $f left alone (protected user)"; continue; }
      warn "$u: $f ($(grep -cvE '^\s*(#|$)' "$f") keys)"
      [[ "$u" == "root" ]] && info "root keys can belong to Black Team or provisioning. Ask before removing."
      ssh-keygen -lf "$f" 2>/dev/null | sed 's/^/     /'
      grep -nE 'command=|from=|environment=' "$f" >/dev/null && bad "  options in keys (command=/from=/environment=), check by hand"
      # root's keys may be Black Team / provisioning access: a plain "y" is not enough
      if { [[ "$u" == root ]] && confirm_typed root "root's keys may be how Black Team or provisioning gets in."; } || { [[ "$u" != root ]] && ask_risky "Quarantine $f (backed up, removable with --rollback)?"; }; then
        backup_file "$f"; rm -f "$f"; did "removed $f"
      fi
    done
  done < /etc/passwd
  local akf; akf="$(sshd -T 2>/dev/null | awk '/^authorizedkeysfile/{$1="";print}')"
  [[ -n "$akf" && "$akf" != *".ssh/authorized_keys"* ]] && bad "non-default AuthorizedKeysFile:$akf"
  akf="$(sshd -T 2>/dev/null | awk '/^authorizedkeyscommand /{print $2}')"
  [[ -n "$akf" && "$akf" != "none" ]] && bad "AuthorizedKeysCommand is set: $akf"
}

detect_ports() {
  ss -tulnH 2>/dev/null | awk '{
     split($5,a,":"); port=a[length(a)]; addr=substr($5,1,length($5)-length(port)-1);
     if (addr ~ /^(127\.|\[::1\]|::1)/) next;
     p=($1=="udp")?"udp":"tcp"; print port"/"p }' | sort -u | sort -t/ -k1,1n -k2,2 | tr '\n' ' '
}

mod_firewall() {
  hdr "Firewall"
  local ports="${ALLOWED_PORTS:-}"
  local detected; detected="$(detect_ports)"
  info "ports listening on non-loopback addresses now: ${detected:-none}"
  ss -tulnpH 2>/dev/null | awk '$5 !~ /^(127\.|\[::1\])/ {printf "     %-5s %-26s %s\n",$1,$5,$7}'
  info "auto-detect includes EVERYTHING listening, bind shells too. Delete ports you can't explain."
  [[ -z "$ports" ]] && ports="$(prompt "Ports to ALLOW inbound (remove anything you don't recognise):" "$detected")"
  in_list "22/tcp" $ports || warn "22/tcp is not in the allow list. You may lock yourself out."
  # ports opened by staff tooling (Wazuh, Xen tools, cloud-init...) stay reachable: R7/R15
  local sp spp; while read -r spp sp; do
    [[ -n "$spp" && "$sp" =~ $PROTECTED_RE ]] || continue
    port_in "$spp" "$ports" || { ports="$ports $spp"; info "kept open: $spp (staff tooling: $sp)"; }
  done < <(ss -tulnpH 2>/dev/null | awk '{ split($5,a,":"); print a[length(a)] "/" (($1=="udp")?"udp":"tcp"), $7 }')
  # FTP: passive data ports must be configured AND allowed, or logins work but every listing/transfer fails
  if [[ -f /etc/vsftpd.conf ]] && port_in 21/tcp "$ports"; then
    local pmin pmax; pmin="$(grep -E '^\s*pasv_min_port' /etc/vsftpd.conf | cut -d= -f2 | tr -d ' ')"; pmax="$(grep -E '^\s*pasv_max_port' /etc/vsftpd.conf | cut -d= -f2 | tr -d ' ')"
    if [[ -z "$pmin" || -z "$pmax" ]]; then bad "vsftpd has no pasv_min_port/pasv_max_port: passive FTP uses random ports and WILL break behind this firewall. Set them (e.g. 40000/50000), restart vsftpd, allow $((${pmin:-40000})):$((${pmax:-50000}))/tcp."
    elif ! port_in "$pmin/tcp" "$ports" || ! port_in "$pmax/tcp" "$ports"; then bad "vsftpd passive ports $pmin-$pmax are not in the allow list: add $pmin:$pmax/tcp or FTP transfers fail"; fi
  fi
  # ufw and plain iptables both drop FORWARDED traffic by default / docker bypasses INPUT entirely
  [[ "$(sysctl -n net.ipv4.ip_forward 2>/dev/null)" == 1 ]] && warn "ip_forward=1: this box routes or runs containers. ufw's default forward policy (DROP) will break that; set DEFAULT_FORWARD_POLICY=\"ACCEPT\" in /etc/default/ufw if forwarding is needed."
  { have docker || [[ -S /var/run/docker.sock ]]; } && warn "Docker present: ports it publishes BYPASS ufw/INPUT rules. Filter those in the DOCKER-USER chain."
  echo "  plan: default DENY inbound, ALLOW: $ports, allow established + loopback, allow outbound"
  info "TCDC R18: an inbound deny that applies to every source is allowed. Outbound stays open (no default-deny egress)."
  echo "  safety: auto-revert in ${FW_ROLLBACK_SECS}s unless you type KEEP"
  if have ufw; then
    # rules someone added earlier survive 'ufw enable': show the ones that aren't on our list
    local extra; extra="$(ufw show added 2>/dev/null | grep -E '^ufw ' | grep -vE "^ufw (allow|limit) ($(echo $ports | sed 's/ /|/g'))( |$)" )"
    [[ -n "$extra" ]] && { warn "existing ufw rules NOT on your allow list (kept unless you delete them):"; echo "$extra" | sed 's/^/     /'; }
  elif ! have iptables; then
    bad "neither ufw nor iptables is installed. Install ufw (apt install ufw) and run this module again."; return
  fi
  # what this would cut off: every listening port NOT on the allow list
  local lp blocked=""
  for lp in $(listening_ports); do port_in "$lp" "$ports" || blocked="$blocked $lp"; done
  if [[ -n "$blocked" ]]; then
    warn "these listening ports will be BLOCKED from outside:$blocked"
    ss -tulnpH 2>/dev/null | awk '{ split($5,a,":"); print a[length(a)] "/" (($1=="udp")?"udp":"tcp"), $1, $5, $7 }' | while read -r pp rest; do
      in_list "$pp" $blocked && echo "     $pp  $rest"; done | sort -u
  fi
  local sp miss=""; for sp in ${SCORED_PORTS:-}; do port_in "$sp" "$ports" || miss="$miss $sp"; done
  if [[ -n "$miss" ]]; then
    bad "SCORED_PORTS not in the allow list:$miss  -> the scorer would be blocked"
    confirm_typed BLOCK "Blocking scored ports loses uptime points every 30 s." || { info "firewall not applied"; return; }
  fi
  ask "Apply firewall?" || return
  local revert snap
  # a fresh snapshot for THIS attempt (re-running the module used to nest copies and revert to the wrong state)
  snap="$(mktemp -d "$BK/fw-attempt-XXXX")"
  if have ufw; then
    local was; was="$(ufw status | head -1)"
    backup_file /etc/ufw; backup_file /etc/default/ufw
    cp -a /etc/ufw "$snap/ufw" 2>/dev/null; cp -a /etc/default/ufw "$snap/ufw-default" 2>/dev/null
    local p; for p in $ports; do ufw allow "$p" >/dev/null && info "allow $p"; done
    ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
    if [[ -n "${extra:-}" ]] && ask "Delete the existing ufw rules listed above?"; then
      # no eval: rule text comes from a file an attacker may have edited
      echo "$extra" | sed 's/^ufw //' | while read -r r; do local -a args; read -ra args <<< "$r"; ufw delete "${args[@]}" >/dev/null 2>&1 && info "deleted: $r" || warn "could not delete: $r (do it by hand: ufw status numbered)"; done
    fi
    ufw logging low >/dev/null; ufw --force enable >/dev/null
    if [[ "$was" == *inactive* ]]; then revert="ufw --force disable"
    else revert="rm -rf /etc/ufw.lockdown-old; mv /etc/ufw /etc/ufw.lockdown-old && cp -a '$snap/ufw' /etc/ufw && cp -a '$snap/ufw-default' /etc/default/ufw && ufw reload; rm -rf /etc/ufw.lockdown-old"; fi
  else
    local ipt v6=false; have ip6tables && v6=true
    for ipt in iptables $($v6 && echo ip6tables); do
      $ipt -N LOCKDOWN_IN 2>/dev/null || $ipt -F LOCKDOWN_IN
      $ipt -A LOCKDOWN_IN -i lo -j ACCEPT
      $ipt -A LOCKDOWN_IN -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
      if [[ $ipt == iptables ]]; then $ipt -A LOCKDOWN_IN -p icmp -j ACCEPT
      else $ipt -A LOCKDOWN_IN -p ipv6-icmp -j ACCEPT; fi   # IPv6 needs ICMPv6 (neighbour discovery)
      local p; for p in $ports; do $ipt -A LOCKDOWN_IN -p "${p#*/}" --dport "${p%/*}" -j ACCEPT || bad "$ipt: could not add $p"; done
      $ipt -A LOCKDOWN_IN -m limit --limit 5/min -j LOG --log-prefix "lockdown-drop: "
      $ipt -A LOCKDOWN_IN -j DROP
      $ipt -C INPUT -j LOCKDOWN_IN 2>/dev/null || $ipt -I INPUT 1 -j LOCKDOWN_IN
    done
    info "allowed: $ports (IPv4$($v6 && echo " + IPv6"))"
    $v6 || warn "ip6tables missing: IPv6 inbound is NOT filtered"
    revert="iptables -D INPUT -j LOCKDOWN_IN; iptables -F LOCKDOWN_IN; iptables -X LOCKDOWN_IN"
    $v6 && revert="$revert; ip6tables -D INPUT -j LOCKDOWN_IN; ip6tables -F LOCKDOWN_IN; ip6tables -X LOCKDOWN_IN"
    echo "fw:iptables" >> "$BK/manifest"
  fi
  # 9>&- : the timer must not inherit the run lock (it kept the next run locked out for 90 s)
  nohup bash -c "sleep $FW_ROLLBACK_SECS; $revert; echo \"[\$(date +%T)] firewall auto-reverted\" >> '$LOG'" >/dev/null 2>&1 9>&- &
  local rpid=$!
  echo "  ${B}Open a NEW ssh session now and check your scored services.${N}"
  local a=""; read -r -t "$FW_ROLLBACK_SECS" -p "  Type KEEP within ${FW_ROLLBACK_SECS}s to keep the rules: " a </dev/tty || true
  if [[ "$a" == "KEEP" ]]; then
    kill "$rpid" 2>/dev/null; did "firewall applied: allow $ports"
    if ! have ufw; then
      if have netfilter-persistent; then netfilter-persistent save >/dev/null 2>&1 && ok "rules saved (netfilter-persistent)"
      else warn "iptables rules are not persistent across reboot (install iptables-persistent)"; fi
    fi
  else
    warn "not confirmed. Rules will revert when the timer fires."
  fi
}

# svc_off UNIT [mask] : stop+disable (optionally mask) and record the PREVIOUS state, so rollback
# restores exactly that (old rollback always did "enable --now", even for units that were disabled before)
svc_off() {
  local u="$1" en act
  en="$(systemctl is-enabled "$u" 2>/dev/null)"; act="$(systemctl is-active "$u" 2>/dev/null)"
  GUARD_EXPECT="$GUARD_EXPECT $(unit_ports "$u" | tr '\n' ' ')"   # you chose to stop it: its ports going away is expected
  systemctl disable --now "$u" >/dev/null 2>&1
  [[ "${2:-}" == mask ]] && systemctl mask "$u" >/dev/null 2>&1
  echo "svc:$u:${en:-unknown}:${act:-unknown}" >> "$BK/manifest"
}

# Unpackaged files you've already checked: stored as "sha256  path". If the file changes, it's flagged again.
KNOWN_FILES="$BK_ROOT/known-files.txt"
UNPKG_SEEN=""
is_known() { [[ -f "$KNOWN_FILES" && -f "$1" ]] && grep -qxF "$(sha256sum "$1")" "$KNOWN_FILES"; }
# unpkg PATH : true if PATH is NOT from a package and NOT marked known (and remembers it for "mark as known")
unpkg() {
  owned_by_pkg "$1" && return 1
  if is_known "$1"; then KNOWN_HITS=$((KNOWN_HITS+1)); return 1; fi
  UNPKG_SEEN="$UNPKG_SEEN $1"; return 0
}
offer_known() {
  local f n=0; for f in $UNPKG_SEEN; do [[ -f "$f" ]] && n=$((n+1)); done
  [[ "${KNOWN_HITS:-0}" -gt 0 ]] && info "${KNOWN_HITS} unpackaged file(s) skipped: already marked known and unchanged ($KNOWN_FILES)"
  [[ $n -eq 0 ]] && return
  info "$n unpackaged file(s) flagged above. Image/vendor files (e.g. Ubuntu minimal's 60-unminimize) show up here too."
  if ask_risky "Mark ALL $n as known for this box? Only if you've read every one. (Any later edit flags it again)"; then
    for f in $UNPKG_SEEN; do [[ -f "$f" ]] && sha256sum "$f"; done >> "$KNOWN_FILES"
    sort -u -o "$KNOWN_FILES" "$KNOWN_FILES"; chmod 600 "$KNOWN_FILES"; did "marked $n files known"
  fi
}

mod_persistence() {
  hdr "Persistence hunt"
  local u f; UNPKG_SEEN=""; KNOWN_HITS=0
  echo "  -- user crontabs:"
  for u in $(cut -d: -f1 /etc/passwd); do
    local c; c="$(crontab -l -u "$u" 2>/dev/null | grep -vE '^\s*(#|$)')"
    [[ -z "$c" ]] && continue
    warn "crontab for $u:"; echo "$c" | sed 's/^/       /'
    in_list "$u" $PROTECTED_USERS && [[ "$u" != "root" ]] && { info "left alone (protected user)"; continue; }
    if [[ "$c" =~ $PROTECTED_RE ]]; then bad "  $u's crontab has staff-tool lines (R7/R15): edit it by hand (crontab -e -u $u), don't remove it"; continue; fi
    if ask_risky "Remove $u's crontab (backed up)?"; then
      mkdir -p "$BK/crontabs"; crontab -l -u "$u" > "$BK/crontabs/$u" 2>/dev/null
      echo "crontab:$u" >> "$BK/manifest"; crontab -r -u "$u" && did "removed crontab for $u"
    fi
  done
  echo "  -- system cron (files not from a package are flagged):"
  grep -hvE '^\s*(#|$|SHELL|PATH|MAILTO)' /etc/crontab /etc/cron.d/* 2>/dev/null | sed 's/^/     /'
  for f in /etc/cron.d/* /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/*; do
    [[ -f "$f" ]] || continue; [[ "$(basename "$f")" == .placeholder ]] && continue
    unpkg "$f" && { grep -qE "$PROTECTED_RE" "$f" && info "cron file from staff tooling (left alone): $f" || warn "cron file not from any package: $f"; }
  done
  have atq && [[ -n "$(atq 2>/dev/null)" ]] && { warn "at jobs queued:"; atq | sed 's/^/     /'; }

  echo "  -- systemd units, timers, sockets and paths not owned by any package:"
  for f in /etc/systemd/system/*.{service,timer,socket,path} /usr/lib/systemd/system/*.{service,timer,socket,path} \
           /lib/systemd/system/*.{service,timer,socket,path} /run/systemd/system/*.{service,timer,socket,path} /etc/systemd/user/*.service; do
    [[ -e "$f" ]] || continue
    local unit; unit="$(basename "$f")"
    if [[ -L "$f" ]]; then   # symlinks are normal only when they point at a packaged unit or /dev/null (masked)
      local t; t="$(readlink -f "$f")"
      [[ "$t" == /dev/null ]] && continue
      unpkg "$t" || continue
      bad "$f is a symlink to $t (not from a package)"
    else
      unpkg "$f" || continue
    fi
    [[ "$unit" == snap.* ]] && grep -qE '^ExecStart=/usr/bin/snap run ' "$f" && continue   # generated by snapd
    protected_thing "$unit" && continue
    warn "$unit  ->  $(grep -m1 -E '^(ExecStart|ListenStream|PathChanged|PathModified|Unit)=' "$f" | cut -c1-120)"
    local serving=false; scored_units | grep -qx "$unit" && serving=true
    $serving && bad "  $unit is SERVING a listening port right now: this is probably a SCORED app ($(unit_ports "$unit" | tr '\n' ' '))"
    if { $serving && confirm_typed "$unit" "Disabling $unit takes that port down."; } || { ! $serving && ask_risky "Stop and disable $unit? (custom units can be the SCORED app: check ExecStart first)"; }; then
      backup_file "$f"; svc_off "$unit"; did "disabled $unit"
    fi
  done
  # drop-in overrides hijack PACKAGED units (the main unit file still looks clean)
  for f in /etc/systemd/system/*.d/*.conf /run/systemd/system/*.d/*.conf /usr/lib/systemd/system/*.d/*.conf; do
    [[ -f "$f" ]] || continue
    unpkg "$f" || continue
    protected_thing "$f" && continue
    local ex; ex="$(grep -E '^\s*(Exec[A-Za-z]*|Environment|EnvironmentFile|User)=' "$f" | tr '\n' ' ' | cut -c1-140)"
    [[ -n "$ex" ]] && bad "drop-in override $f: $ex" || info "drop-in $f (no Exec/Environment lines)"
  done
  for f in /home/*/.config/systemd/user/*.service /root/.config/systemd/user/*.service; do
    [[ -f "$f" ]] && bad "user systemd unit: $f -> $(grep -m1 ExecStart "$f")"
  done

  echo "  -- preload, rc.local, PAM, login hooks:"
  if [[ -s /etc/ld.so.preload ]]; then
    bad "/etc/ld.so.preload is set: $(cat /etc/ld.so.preload)  (classic userland rootkit)"
    if grep -qE "$PROTECTED_RE" /etc/ld.so.preload; then info "  ld.so.preload names staff tooling: left alone, ask Black Team"
    elif ask "Quarantine /etc/ld.so.preload?"; then backup_file /etc/ld.so.preload; rm -f /etc/ld.so.preload; did "removed ld.so.preload"; fi
  else ok "no ld.so.preload"; fi
  grep -HnE 'LD_PRELOAD|LD_LIBRARY_PATH' /etc/environment /etc/profile /etc/profile.d/* /etc/bash.bashrc /root/.bashrc /home/*/.bashrc 2>/dev/null | while read -r l; do bad "loader variable set: $l"; done
  [[ -s /etc/rc.local ]] && warn "/etc/rc.local exists: $(grep -vcE '^\s*(#|$)' /etc/rc.local) active lines"
  # PAM: stock Ubuntu has 'required pam_permit.so' at the END of common-*. Anything that lets
  # pam_permit decide success (sufficient / [success=...]) or runs pam_exec is a backdoor.
  grep -rnE '^\s*[^#[:space:]]' /etc/pam.d 2>/dev/null | while read -r l; do
    if [[ "$l" =~ pam_exec ]]; then bad "PAM runs a program: $l"
    elif [[ "$l" =~ pam_permit\.so ]]; then
      if [[ "$l" =~ (sufficient|\[success=[^]]*\]|\[default=ok|done) ]] || [[ ! "$l" =~ /common-(auth|account|session|password|session-noninteractive): ]]; then
        bad "PAM pam_permit can grant access: $l"; fi
    fi
  done
  dpkg --verify libpam-runtime libpam-modules 2>/dev/null | awk '{print $NF}' | grep '^/etc/pam.d' | while read -r f; do warn "PAM file changed since install: $f"; done
  local secdir; for secdir in /lib/x86_64-linux-gnu/security /usr/lib/x86_64-linux-gnu/security /lib/aarch64-linux-gnu/security /usr/lib/aarch64-linux-gnu/security /lib/security; do
    [[ -d "$secdir" && ! -L "$secdir" ]] || continue
    for f in "$secdir"/*.so; do [[ -f "$f" ]] && unpkg "$f" && bad "PAM module not from any package: $f"; done
  done
  # other places that run code as root automatically
  for f in /etc/update-motd.d/* /etc/apt/apt.conf.d/* /etc/udev/rules.d/* /etc/profile.d/* /etc/init.d/* /etc/network/if-up.d/* /etc/NetworkManager/dispatcher.d/*; do
    [[ -f "$f" ]] || continue
    unpkg "$f" || continue
    case "$f" in
      /etc/apt/apt.conf.d/*) grep -qiE '(Pre|Post)-Invoke' "$f" && bad "APT hook (runs as root on apt): $f: $(grep -iE 'Invoke' "$f" | head -2 | tr '\n' ' ')" || info "apt config not from a package: $f";;
      /etc/udev/rules.d/*) grep -q 'RUN' "$f" && bad "udev rule runs a program: $f: $(grep -m1 RUN "$f")" || info "udev rule not from a package: $f";;
      /etc/update-motd.d/*) bad "motd script not from a package (runs as root at every SSH login): $f";;
      *) warn "not from any package: $f";;
    esac
  done

  echo "  -- shell startup files with suspicious content:"
  local pat='(/dev/tcp/|nc\s+-e|ncat|socat|bash\s+-i|curl[^|]*\|\s*(ba)?sh|wget[^|]*\|\s*(ba)?sh|base64\s+-d|python[23]?\s+-c|perl\s+-e|alias\s+(sudo|su|ps|ss|netstat|who|last|lsof|crontab|passwd|ssh)=)'
  grep -HnEi "$pat" /etc/profile /etc/profile.d/* /etc/bash.bashrc /etc/environment /root/.bashrc /root/.profile /home/*/.bashrc /home/*/.profile /home/*/.bash_profile 2>/dev/null | sed 's/^/     /' | while read -r l; do bad "$l"; done

  echo "  -- package integrity (modified binaries in key packages):"
  local pk; for pk in openssh-server openssh-client sudo sudo-rs rust-coreutils coreutils-from-uutils passwd login libpam-modules libpam-runtime coreutils procps iproute2 net-tools util-linux findutils; do
    dpkg -s "$pk" >/dev/null 2>&1 || continue
    # flag only checksum mismatches (5 in 3rd column) or missing files in binary/library paths, skip config + docs
    dpkg --verify "$pk" 2>/dev/null | awk '$2!="c" && $NF !~ /^\/usr\/share\// && (substr($1,3,1)=="5" || $1=="missing")' | while read -r l; do bad "$pk: $l"; done
  done
  ok "dpkg --verify done (only non-config changes shown)"

  echo "  -- OUTBOUND connections from shells/interpreters (possible reverse shells):"
  # inbound connections to a listening port (scorer -> python/php web app) are server traffic, not reverse shells
  local lports listeners; lports=" $(ss -tlnH 2>/dev/null | awk '{n=split($4,a,":"); print a[n]}' | sort -u | tr '\n' ' ') "
  listeners=" $(ss -tlnpH 2>/dev/null | grep -oE 'pid=[0-9]+' | cut -d= -f2 | sort -u | tr '\n' ' ') "
  ss -tnpH state established 2>/dev/null | grep -E '"(bash|sh|dash|zsh|nc|ncat|netcat|socat|python[0-9.]*|perl|php|ruby|telnet|node)"' | while read -r l; do
    local lp; lp="$(awk '{n=split($3,a,":"); print a[n]}' <<< "$l")"
    [[ "$lports" == *" $lp "* ]] && continue
    local pid; pid="$(echo "$l" | grep -oE 'pid=[0-9]+' | head -1 | cut -d= -f2)"
    [[ -n "$pid" && "$listeners" == *" $pid "* ]] && { info "server process $pid also has an outbound connection (not killing a server): $l"; continue; }
    bad "$l"
    [[ -n "$pid" ]] && protected_thing "$(ps -o cmd= -p "$pid" 2>/dev/null)" && continue
    if [[ "$IS_JUMPBOX" == yes ]]; then info "  jumpbox: may be your own purple-team tooling (R16). Report only; check with your team."; continue; fi
    [[ -n "$pid" ]] && ask_risky "Kill pid $pid ($(ps -o cmd= -p "$pid" 2>/dev/null | cut -c1-60))?" && kill -9 "$pid" && did "killed $pid"
  done
  echo "  -- processes running from /tmp, /dev/shm, /var/tmp or deleted binaries:"
  # readlink instead of parsing ls (ls columns move with the locale's date format)
  local pd exe base
  for pd in /proc/[0-9]*; do
    exe="$(readlink "$pd/exe" 2>/dev/null)" || continue
    case "$exe" in
      /tmp/*|/dev/shm/*|/var/tmp/*|/memfd:*) bad "pid ${pd#/proc/} runs from $exe: $(tr '\0' ' ' < "$pd/cmdline" 2>/dev/null | cut -c1-80)";;
      *" (deleted)")
        base="${exe% (deleted)}"
        # binary replaced by an apt upgrade: the new file exists and dpkg vouches for it -> just needs a restart
        if [[ -f "$base" ]] && owned_by_pkg "$base"; then info "pid ${pd#/proc/} runs an old copy of $base (updated by apt; restart that service)"
        else bad "pid ${pd#/proc/} runs a DELETED binary $base: $(tr '\0' ' ' < "$pd/cmdline" 2>/dev/null | cut -c1-80)"; fi;;
    esac
  done
  offer_known
}

mod_services() {
  hdr "Services"
  local risky="telnet.socket inetd xinetd rsh.socket rlogin.socket rexec.socket tftpd-hpa atftpd avahi-daemon cups cups-browsed rpcbind nfs-server snmpd nis ypbind talk ntalk"
  info "running services:"
  systemctl list-units --type=service --state=running --no-legend --plain 2>/dev/null | awk '{print "     "$1}'
  local s
  for s in $risky; do
    protected_thing "$s" && continue
    if systemctl is-active --quiet "$s" 2>/dev/null; then
      if [[ -n "$(unit_ports "$s")" ]] && [[ -n "${SCORED_PORTS:-}" ]] && for p in $(unit_ports "$s"); do port_in "$p" "$SCORED_PORTS" && break; done; then
        bad "$s serves a SCORED port ($(unit_ports "$s" | tr '\n' ' ')): not touching it"; continue
      fi
      warn "risky service running: $s"
      if ask_risky "Stop, disable and MASK $s and its .socket/.path units? (make sure it isn't scored)"; then
        # disabling alone isn't enough: avahi-daemon.socket, cups.socket/cups.path, rpcbind.socket start it again on demand
        local base="${s%.*}" x
        for x in "$base.socket" "$base.path"; do
          systemctl list-unit-files "$x" >/dev/null 2>&1 && systemctl cat "$x" >/dev/null 2>&1 && svc_off "$x" mask
        done
        svc_off "$s" mask; did "stopped, disabled and masked $s"
      fi
    fi
  done
  ok "checked risky list. Anything else is left alone. Review the list above by hand."
}

mod_sysctl() {
  hdr "Kernel (sysctl)"
  local f=/etc/sysctl.d/99-zz-lockdown.conf   # must sort after 99-sysctl.conf (/etc/sysctl.conf) or that file wins at boot
  [[ -f /etc/sysctl.d/99-lockdown.conf ]] && warn "old /etc/sysctl.d/99-lockdown.conf from v1.0 exists (it loses to /etc/sysctl.conf at boot); remove it after this module"
  local conf="net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.rp_filter = 2
net.ipv4.conf.default.rp_filter = 2
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.icmp_ignore_bogus_error_responses = 1
net.ipv4.conf.all.log_martians = 1
kernel.kptr_restrict = 2
kernel.dmesg_restrict = 1
kernel.yama.ptrace_scope = 1
kernel.sysrq = 0
fs.protected_symlinks = 1
fs.protected_hardlinks = 1
fs.protected_fifos = 2
fs.protected_regular = 2
fs.suid_dumpable = 0"
  echo "$conf" | sed 's/^/     /'
  info "ip_forward is left unchanged (some boxes route)"
  ask "Write $f and apply?" || return
  backup_file "$f"
  local k; for k in $(echo "$conf" | awk '{print $1}'); do echo "$k = $(sysctl -n "$k" 2>/dev/null)"; done > "$BK/sysctl-before.conf"
  echo "sysctl:$BK/sysctl-before.conf" >> "$BK/manifest"
  echo "$conf" > "$f"
  sysctl -p "$f" >/dev/null 2>&1; did "sysctl hardening applied"
  # check that nothing else overrides us at boot
  local k v want bad_k=""
  while read -r k _ want; do v="$(sysctl -n "$k" 2>/dev/null)" || continue; [[ "$v" != "$want" ]] && bad_k="$bad_k $k=$v"; done <<< "$conf"
  [[ -n "$bad_k" ]] && warn "not in effect (kernel lacks them or something overrides):$bad_k"
  grep -rlE "$(echo "$conf" | awk '{k=k (k?"|":"") $1} END{gsub(/\./,"\\.",k); print k}')" /etc/sysctl.conf /etc/sysctl.d /run/sysctl.d 2>/dev/null | grep -v "$f" | while read -r o; do info "also sets some of these keys: $o"; done
}

mod_perms() {
  hdr "File permissions"
  local fixes="/etc/passwd:644:root:root /etc/group:644:root:root /etc/shadow:640:root:shadow /etc/gshadow:640:root:shadow /etc/sudoers:440:root:root /etc/ssh/sshd_config:600:root:root /etc/crontab:600:root:root /root:700:root:root"
  local e path mode own grp
  for e in $fixes; do
    IFS=: read -r path mode own grp <<< "$e"
    [[ -e "$path" ]] || continue
    local cur; cur="$(stat -c '%a:%U:%G' "$path")"
    if [[ "$cur" != "$mode:$own:$grp" ]]; then
      warn "$path is $cur (want $mode:$own:$grp)"
      ask "Fix $path?" && { echo "perm:$path:$(stat -c '%a:%U:%G' "$path")" >> "$BK/manifest"; chown "$own:$grp" "$path"; chmod "$mode" "$path"; did "fixed $path"; }
    fi
  done
  echo "  -- world-writable files in system dirs:"
  find /etc /usr /bin /sbin /lib -xdev -type f -perm -0002 2>/dev/null | head -50 | while read -r f; do bad "world-writable: $f"; done
  echo "  -- SUID/SGID binaries not owned by any package (all local filesystems, incl. /tmp, /dev/shm, /home):"
  suid_scan | while read -r f; do
    owned_by_pkg "$f" && continue
    bad "unpackaged SUID/SGID: $f"
    protected_thing "$f" && continue
    ask_risky "Strip setuid/setgid from $f?" && { echo "chmod:$f:$(stat -c %a "$f")" >> "$BK/manifest"; chmod u-s,g-s "$f"; did "stripped $f"; }
  done
  echo "  -- known GTFOBins with SUID set:"
  local gtfo="find vim vi nano less more awk gawk python python3 perl ruby bash sh dash zsh env tar zip cp mv nmap tee dd wget curl socat xxd base64 cat head tail sed od strace gdb node php lua busybox systemctl journalctl openssl rsync"
  for e in $gtfo; do local p; p="$(command -v "$e" 2>/dev/null)" || continue
    p="$(readlink -f "$p")"; [[ -u "$p" ]] && { bad "SUID on $p"; ask_risky "Strip setuid from $p?" && { echo "chmod:$p:$(stat -c %a "$p")" >> "$BK/manifest"; chmod u-s "$p"; did "stripped $p"; }; }
  done
}

# suid_scan: SUID/SGID files on every local filesystem (find / -xdev skipped separate /tmp, /home, /var, /dev/shm)
suid_scan() {
  local m; for m in $(findmnt -rn -o TARGET -t ext2,ext3,ext4,xfs,btrfs,zfs,tmpfs,vfat,f2fs 2>/dev/null | grep -vE '^/(proc|sys|run/user|snap)'); do
    find "$m" -xdev \( -path /var/lib/docker -o -path /var/lib/containerd -o -path /var/lib/containers -o -path /var/lib/lxd -o -path /var/snap -o -path /snap \) -prune -o \( -perm -4000 -o -perm -2000 \) -type f -print 2>/dev/null
  done | sort -u
}
caps_scan() { getcap -r / 2>/dev/null | grep -vE '^/(proc|sys|snap)/|^/var/lib/(docker|containerd|containers|lxd)/|^/var/snap/' | sort; }
mod_caps() {
  hdr "File capabilities"
  have getcap || { warn "getcap missing (apt install libcap2-bin): capabilities NOT checked"; return; }
  local f c
  caps_scan | while read -r f c; do
    case "$c" in
      *cap_setuid*|*cap_setgid*|*cap_dac_override*|*cap_dac_read_search*|*cap_sys_admin*|*cap_sys_ptrace*|*cap_sys_module*|*cap_chown*|*cap_fowner*)
        bad "dangerous capability: $f $c"
        protected_thing "$f" && continue
        ask_risky "Remove capabilities from $f?" && { echo "cap:$f:$c" >> "$BK/manifest"; setcap -r "$f" && did "removed caps from $f"; };;
      *) info "capability: $f $c ($(pkg_status "$f"))";;
    esac
  done
}

# web_roots: configured WEB_ROOTS plus every DocumentRoot / root the web servers actually use
web_roots() {
  { echo $WEB_ROOTS | tr ' ' '\n'
    grep -rhoiE '^\s*DocumentRoot\s+"?[^" ]+' /etc/apache2/sites-enabled /etc/apache2/apache2.conf 2>/dev/null | awk '{print $2}' | tr -d '"'
    grep -rhoE '^\s*root\s+[^;]+' /etc/nginx/sites-enabled /etc/nginx/conf.d /etc/nginx/nginx.conf 2>/dev/null | awk '{print $2}'
  } | grep '^/' | sort -u
}
mod_web() {
  hdr "Web"
  local roots="" r; for r in $(web_roots); do [[ -d "$r" ]] && roots="$roots $r"; done
  if [[ -n "$roots" ]]; then
    echo "  -- likely webshells (pattern match) in:$roots"
    grep -rlEi --include=*.{php,phtml,php5,php7,phar,jsp,aspx} \
      '(eval\s*\(\s*(base64_decode|gzinflate|str_rot13|\$_(POST|GET|REQUEST|COOKIE))|(system|shell_exec|passthru|exec|popen|proc_open)\s*\(\s*\$_(POST|GET|REQUEST|COOKIE)|assert\s*\(\s*\$_|preg_replace\s*\(.*/e)' \
      $roots 2>/dev/null | head -50 | while read -r f; do bad "suspicious: $f"; done
    echo "  -- web files changed in the last 24h:"
    find $roots -type f -mmin -1440 2>/dev/null | head -30 | sed 's/^/     /'
    echo "  -- executable scripts in upload directories:"
    find $roots -type d -iname '*upload*' -exec find {} -type f \( -iname '*.php*' -o -iname '*.phtml' \) \; 2>/dev/null | while read -r f; do bad "script in upload dir: $f"; done
    # .htaccess can turn any upload into PHP (AddType/AddHandler/SetHandler) or auto-prepend a backdoor
    grep -rnEi --include=.htaccess '(AddType|AddHandler|SetHandler|php_value\s+auto_(pre|ap)pend_file|ForceType)' $roots 2>/dev/null | head -20 | while read -r l; do bad ".htaccess: $l"; done
    find $roots -name wp-config.php 2>/dev/null | while read -r f; do info "WordPress at $(dirname "$f")"; done
  else info "no web roots found"; fi
  if [[ -f /etc/apache2/conf-available/security.conf ]]; then
    local sc=/etc/apache2/conf-available/security.conf
    if grep -qE '^\s*ServerTokens\s+(OS|Full)' "$sc" || grep -qE '^\s*ServerSignature\s+On' "$sc"; then
      warn "Apache leaks its version (ServerTokens/ServerSignature)"
      if ask "Set ServerTokens Prod, ServerSignature Off, TraceEnable Off?"; then
        backup_file "$sc"
        sed -i -E 's/^\s*ServerTokens.*/ServerTokens Prod/; s/^\s*ServerSignature.*/ServerSignature Off/; s/^\s*TraceEnable.*/TraceEnable Off/' "$sc"
        if apache2ctl configtest >/dev/null 2>&1; then systemctl reload apache2; did "apache tokens hidden"
        else cp -a "$BK/files$sc" "$sc"; bad "apache configtest failed, restored"; fi
      fi
    fi
    grep -rnE '^\s*Options.*\+?Indexes' /etc/apache2/sites-enabled /etc/apache2/apache2.conf 2>/dev/null | grep -v -- '-Indexes' | while read -r l; do warn "directory listing enabled: $l"; done
  fi
  if [[ -f /etc/nginx/nginx.conf ]]; then
    grep -qE '^\s*server_tokens\s+off' /etc/nginx/nginx.conf || warn "nginx: add 'server_tokens off;' in the http block"
    grep -rnE '^\s*autoindex\s+on' /etc/nginx 2>/dev/null | while read -r l; do warn "nginx autoindex: $l"; done
  fi
  local ini; for ini in /etc/php/*/apache2/php.ini /etc/php/*/fpm/php.ini; do
    [[ -f "$ini" ]] || continue
    grep -qE '^\s*allow_url_include\s*=\s*On' "$ini" && bad "$ini: allow_url_include = On"
    grep -qE '^\s*expose_php\s*=\s*On' "$ini" && warn "$ini: expose_php = On"
    info "$ini disable_functions = $(grep -E '^\s*disable_functions' "$ini" | cut -d= -f2- | cut -c1-60)"
  done
}

# ---- scanner false-positive handling ------------------------------------------
# Each finding becomes one line "tool| text". Then, in order:
#   1. matches SCAN_IGNORE_RE (stock Ubuntu noise)            -> counted, hidden
#   2. listed in /root/.lockdown/scan-known.txt (this box)     -> counted, hidden
#   3. everything else is NEW: shown, with dpkg's opinion of any file it names
# After a clean first run, answer y to "mark as known": from then on you only see what changed.
SCAN_KNOWN="$BK_ROOT/scan-known.txt"
scan_findings() {   # scan_findings TOOL RAWFILE -> one finding per line
  local t="$1" f="$2"
  [[ -s "$f" ]] || return 0
  case "$t" in
    rkhunter)   # a warning plus its indented continuation lines = one finding
      awk '/^Warning:/{if(w)print w; w=$0; next} /^[ \t]+/ && w {gsub(/^[ \t]+/," "); w=w $0; next} {if(w)print w; w=""} END{if(w)print w}' "$f";;
    chkrootkit) # split "suspicious files were found:" lists into one line per path, drop noise
      awk '/suspicious files and directories were found/{l=1; next} l && /^\//{print "suspicious file: " $0; next} {l=0} /INFECTED|Warning|WARNING|[Ss]uspicious|PACKET SNIFFER|promisc/{print}' "$f";;
    lynis)      grep '^warning\[\]=' "$f" | cut -d= -f2- | cut -d'|' -f1,2;;
    clamav)     grep 'FOUND$' "$f";;
    *)          grep -v '^\s*$' "$f";;
  esac | sed "s/^/$t| /" | sort -u
}
scan_report() {     # scan_report FINDINGS_FILE TOOL
  local ff="$1" t="$2" l p st n_ign=0 n_known=0 n_new=0
  local newf; newf="$(mktemp)"
  while IFS= read -r l; do
    [[ -z "$l" ]] && continue
    if [[ -n "$SCAN_IGNORE_RE" && "$l" =~ $SCAN_IGNORE_RE ]]; then n_ign=$((n_ign+1)); continue; fi
    if [[ -f "$SCAN_KNOWN" ]] && grep -qxF "$l" "$SCAN_KNOWN"; then n_known=$((n_known+1)); continue; fi
    n_new=$((n_new+1)); echo "$l" >> "$newf"
    p="$(echo "$l" | grep -oE "/[^ :,'\")]+" | awk '{ if (length($0) > length(m)) m=$0 } END{print m}')"   # longest path in the line
    st=""; [[ -n "$p" && -e "$p" ]] && st="  [$(pkg_status "$p")]"
    # a packaged, unmodified file is very likely a false positive: show it quieter
    if [[ "$st" == *"unchanged"* ]]; then info "${l#*| }$st  <- likely false positive"
    else bad "${l#*| }$st"; fi
  done < "$ff"
  info "$t: $n_new new, $n_known known on this box, $n_ign stock-Ubuntu false positives hidden"
  cat "$newf" >> "$BK_ROOT/.scan-new-$TS"; rm -f "$newf"
}

mod_scanners() {
  hdr "Malware and rootkit scanners (report only)"
  local missing="" t
  for t in lynis rkhunter chkrootkit; do have "$t" || missing="$missing $t"; done
  [[ "${INSTALL_CLAMAV:-no}" == yes ]] && ! have clamscan && missing="$missing clamscan"   # ~1 GB RAM + a resident updater: opt-in only
  info "scanners run at the lowest CPU/disk priority, but still take minutes: best right after your first audit, not mid-incident"
  if [[ -n "$missing" ]]; then
    info "not installed:$missing"
    if $AUDIT; then info "audit mode: run in harden mode to install them"
    else
      # don't run apt as root against sources an attacker may have changed
      local src; src="$(grep -rhE '^\s*(deb|URIs:)' /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null | grep -vE '(archive|security|ports)\.ubuntu\.com|deb\.debian\.org|security\.debian\.org|ppa\.launchpad|esm\.ubuntu' )"
      grep -rqE 'trusted=yes|AllowInsecureRepositories|AllowUnauthenticated' /etc/apt/ 2>/dev/null && bad "APT is set to accept UNSIGNED packages (trusted=yes / AllowUnauthenticated). Fix before installing anything."
      [[ -n "$src" ]] && { warn "non-standard APT sources (check before installing):"; echo "$src" | sed 's/^/     /'; }
      if timeout 30 apt-get -qq update >/dev/null 2>&1; then
        local pk="${missing/clamscan/clamav}"
        ask "Install$pk with apt (no extra recommended packages)?" && \
          { DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends $pk >/dev/null 2>&1 && did "installed$pk" || warn "apt install failed (another apt running? try again in a minute)"; }
      else
        warn "apt can't reach a mirror. Copy .deb files from the jumpbox and install with: dpkg -i *.deb"
      fi
    fi
  fi
  local out="$BK_ROOT/scans-$TS"; mkdir -p "$out"; rm -f "$BK_ROOT/.scan-new-$TS"
  if have lynis; then
    info "Lynis system audit (about 1-3 min)..."
    nice -n 19 ionice -c3 timeout 300 lynis audit system --quick --no-colors --report-file "$out/lynis-report.dat" > "$out/lynis.txt" 2>&1
    scan_findings lynis "$out/lynis-report.dat" > "$out/lynis.findings"; scan_report "$out/lynis.findings" lynis
    info "hardening index: $(grep '^hardening_index=' "$out/lynis-report.dat" 2>/dev/null | cut -d= -f2)  suggestions: $(grep -c '^suggestion\[\]=' "$out/lynis-report.dat" 2>/dev/null)  (full list: $out/lynis.txt)"
  fi
  if have rkhunter; then
    info "rkhunter..."
    [[ -s /var/lib/rkhunter/db/rkhunter.dat ]] || warn "rkhunter has no file-property database yet: run the baseline step (it runs rkhunter --propupd) on a clean box"
    nice -n 19 ionice -c3 timeout 300 rkhunter --check --sk --rwo --nocolors > "$out/rkhunter.txt" 2>&1
    scan_findings rkhunter "$out/rkhunter.txt" > "$out/rkhunter.findings"; scan_report "$out/rkhunter.findings" rkhunter
  fi
  if have chkrootkit; then
    info "chkrootkit..."
    nice -n 19 ionice -c3 timeout 300 chkrootkit -q > "$out/chkrootkit.txt" 2>&1
    scan_findings chkrootkit "$out/chkrootkit.txt" > "$out/chkrootkit.findings"; scan_report "$out/chkrootkit.findings" chkrootkit
  fi
  if have clamscan; then
    local free_mb; free_mb="$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)"
    if [[ "${free_mb:-0}" -lt "$CLAMAV_MIN_MB" ]] && ! ask "Only ${free_mb}MB RAM free; clamscan needs ~1.5GB and can get scored services OOM-killed. Run it anyway?"; then
      warn "clamscan skipped (low memory)"
    else
      local dirs="" d; for d in /tmp /var/tmp /dev/shm /root /home $(web_roots) /srv; do [[ -d "$d" ]] && dirs="$dirs $d"; done
      info "ClamAV on:$dirs (signatures may be old if freshclam can't update)..."
      nice -n 19 ionice -c3 timeout 600 clamscan -r -i --no-summary --max-filesize=25M $dirs > "$out/clamav.txt" 2>&1
      grep -q 'No supported database' "$out/clamav.txt" && warn "ClamAV has no signatures yet. Run freshclam (needs internet) or wait for clamav-freshclam to finish"
      scan_findings clamav "$out/clamav.txt" > "$out/clamav.findings"; scan_report "$out/clamav.findings" clamav
    fi
  fi
  if have maldet; then
    info "Linux Malware Detect on web roots..."
    local w; for w in $(web_roots); do [[ -d "$w" ]] && timeout 600 maldet -a "$w" >> "$out/maldet.txt" 2>&1; done
    grep -iE 'hits|malware' "$out/maldet.txt" | tail -3 | while read -r l; do info "maldet: $l"; done
  fi
  local nf="$BK_ROOT/.scan-new-$TS" n=0
  [[ -s "$nf" ]] && n="$(wc -l < "$nf")"
  if [[ "$n" -gt 0 ]]; then
    info "Lines tagged [packaged (...), unchanged] are files dpkg vouches for: almost always false positives."
    info "Lines tagged [not from a package] or [MODIFIED] are the ones to look at by hand."
    if ask_risky "Mark these $n findings as KNOWN for this box, so later runs only show new ones? (only after you've checked them)"; then
      cat "$nf" >> "$SCAN_KNOWN"; sort -u -o "$SCAN_KNOWN" "$SCAN_KNOWN"; chmod 600 "$SCAN_KNOWN"; did "saved to $SCAN_KNOWN (delete a line to see it again)"
    fi
  else ok "no new scanner findings"; fi
  rm -f "$nf"
  ok "scanner output saved in $out. Scanners only report. Nothing was quarantined or deleted."
}

mod_db() {
  hdr "Databases"
  if have mysql && mysql -NBe 'select 1' >/dev/null 2>&1; then
    info "MySQL/MariaDB users:"
    mysql -NBe "select user,host,plugin from mysql.user" 2>/dev/null | sed 's/^/     /'
    local anon; anon="$(mysql -NBe "select count(*) from mysql.user where user=''" 2>/dev/null)"
    [[ "${anon:-0}" -gt 0 ]] && { bad "$anon anonymous MySQL user(s)"; ask_risky "Drop anonymous MySQL users?" && { mysql -NBe "select host from mysql.user where user=''" | while read -r h; do mysql -e "DROP USER ''@'$h'" && did "dropped anonymous user ''@$h"; done; }; }
    mysql -NBe "select user,host from mysql.user where host='%'" 2>/dev/null | while read -r l; do warn "MySQL user reachable from any host: $l"; done
    mysql -NBe "show databases like 'test'" 2>/dev/null | grep -q test && { warn "test database exists"; ask_risky "Drop test database?" && mysql -e "DROP DATABASE test" && did "dropped test db"; }
    info "MySQL users with FILE/SUPER/GRANT privileges:"
    mysql -NBe "select user,host from mysql.user where File_priv='Y' or Super_priv='Y' or Grant_priv='Y'" 2>/dev/null | sed 's/^/     /'
  elif have mysql; then info "mysql present but can't log in as root via socket. Check it manually"; fi
  local hba; for hba in /etc/postgresql/*/main/pg_hba.conf; do
    [[ -f "$hba" ]] || continue
    grep -nE '^\s*[^#].*\btrust\b' "$hba" | while read -r l; do bad "$hba: trust auth: $l"; done
    grep -nE '^\s*host.*0\.0\.0\.0/0' "$hba" | while read -r l; do warn "$hba: open to any IP: $l"; done
  done
  if have psql; then
    info "Postgres superusers:"; sudo -u postgres psql -Atc "select rolname from pg_roles where rolsuper" 2>/dev/null | sed 's/^/     /'
  fi
}

mod_other() {
  hdr "FTP / Mail / DNS / SMB"
  if [[ -f /etc/vsftpd.conf ]]; then
    if grep -qE '^\s*anonymous_enable\s*=\s*YES' /etc/vsftpd.conf; then
      bad "vsftpd allows anonymous login"
      if ask "Disable anonymous FTP? (check the scorer doesn't use it)"; then
        backup_file /etc/vsftpd.conf; sed -i -E 's/^\s*anonymous_enable\s*=.*/anonymous_enable=NO/' /etc/vsftpd.conf
        systemctl restart vsftpd; sleep 2
        if systemctl is-active --quiet vsftpd; then did "anonymous FTP off (vsftpd restarted and running)"
        else restore_file "$BK/files/etc/vsftpd.conf" /etc/vsftpd.conf; systemctl restart vsftpd; bad "vsftpd did not come back: config restored and restarted"; fi
      fi
    else ok "vsftpd anonymous off"; fi
    grep -qE '^\s*chroot_local_user\s*=\s*YES' /etc/vsftpd.conf || warn "vsftpd: chroot_local_user is not YES"
  fi
  if have postconf; then
    info "postfix mynetworks: $(postconf -h mynetworks 2>/dev/null)"
    postconf -h mynetworks 2>/dev/null | grep -qE '0\.0\.0\.0/0|::/0' && bad "postfix is an OPEN RELAY (mynetworks too wide)"
    info "postfix relay restrictions: $(postconf -h smtpd_relay_restrictions 2>/dev/null)"
  fi
  if [[ -d /etc/bind ]]; then
    grep -rqE 'allow-transfer\s*\{\s*any' /etc/bind && bad "BIND allows zone transfers to anyone"
    grep -rqE 'allow-recursion' /etc/bind || warn "BIND: no allow-recursion set (check for an open resolver)"
    have named-checkconf && { named-checkconf >/dev/null 2>&1 && ok "named-checkconf passes" || bad "named-checkconf fails"; }
  fi
  if [[ -f /etc/samba/smb.conf ]]; then
    grep -nEi '^\s*(guest ok|public)\s*=\s*yes' /etc/samba/smb.conf | while read -r l; do warn "samba guest share: $l"; done
    grep -qiE 'server min protocol\s*=\s*SMB[23]' /etc/samba/smb.conf || warn "samba: set 'server min protocol = SMB2'"
  fi
}

# ---- service guard: never leave a scored service down ---------------------------
# listening_ports -> "port/proto" for every non-loopback listener
listening_ports() {
  ss -tulnH 2>/dev/null | awk '{ split($5,a,":"); port=a[length(a)]; addr=substr($5,1,length($5)-length(port)-1);
     if (addr ~ /^(127\.|\[::1\]|::1)/) next; print port "/" (($1=="udp")?"udp":"tcp") }' | sort -u
}
# port_in "53/udp" "list" : handles ranges like 40000:50000/tcp
port_in() {
  local p="${1%/*}" pr="${1#*/}" e lo hi
  for e in $2; do
    [[ "${e#*/}" == "$pr" ]] || continue
    if [[ "${e%/*}" == *:* ]]; then lo="${e%%:*}"; hi="${e%/*}"; hi="${hi#*:}"; (( p >= lo && p <= hi )) && return 0
    elif [[ "${e%/*}" == "$p" ]]; then return 0; fi
  done; return 1
}
# pids listening on the given ports (default: guarded ports)
listener_pids() {
  local want="${1:-$GUARD_PORTS}"
  ss -tulnpH 2>/dev/null | awk '{ split($5,a,":"); print a[length(a)] "/" (($1=="udp")?"udp":"tcp"), $0 }' \
    | while read -r pp rest; do port_in "$pp" "$want" && grep -oE 'pid=[0-9]+' <<< "$rest" | cut -d= -f2; done | sort -u
}
unit_of_pid() { grep -oE '[^/]+\.(service|socket|scope)' "/proc/$1/cgroup" 2>/dev/null | tail -1; }
scored_units() { local p; for p in $(listener_pids "${1:-}"); do unit_of_pid "$p"; done | sort -u; }
# ports a unit is listening on (to know which ports are EXPECTED to go away when we stop it)
unit_ports() {
  local u="$1" p
  ss -tulnpH 2>/dev/null | awk '{ split($5,a,":"); print a[length(a)] "/" (($1=="udp")?"udp":"tcp"), $0 }' | while read -r pp rest; do
    for p in $(grep -oE 'pid=[0-9]+' <<< "$rest" | cut -d= -f2); do [[ "$(unit_of_pid "$p")" == "$u" ]] && { echo "$pp"; break; }; done
  done | sort -u
}
GUARD_PORTS=""; GUARD_EXPECT=""
guard_start() {
  local now p; now="$(listening_ports | tr '\n' ' ')"; GUARD_PORTS=""
  if [[ -z "${SCORED_PORTS:-}" ]]; then GUARD_PORTS="$now"
  else
    for p in $SCORED_PORTS 22/tcp; do
      [[ "$p" == *:* ]] && continue
      if port_in "$p" "$now"; then GUARD_PORTS="$GUARD_PORTS $p"
      elif [[ "$p" != 22/tcp ]]; then bad "SCORED_PORTS says $p but nothing listens there NOW: service already down, or wrong port in lockdown.conf (check: ss -tulpn)"; fi
    done
  fi
  info "service guard: will re-check these listening ports after every module: ${GUARD_PORTS:-none}"
  [[ -n "${SERVICE_CHECK_CMD:-}" ]] && info "service guard: and run: $SERVICE_CHECK_CMD"
}
# scored_down -> one line per guarded/scored port that is not listening (used by the guard and --watch)
scored_down() {
  local want="${SCORED_PORTS:-}" now p
  [[ -z "$want" ]] && return 0
  now="$(listening_ports | tr '\n' ' ')"
  for p in $want; do [[ "$p" == *:* ]] && continue; port_in "$p" "$now" || echo "SCORED SERVICE DOWN: nothing listening on $p"; done
}
guard_check() {   # guard_check MODULE
  [[ -z "$GUARD_PORTS" && -z "${SERVICE_CHECK_CMD:-}" ]] && return 0
  local try missing now p
  for try in 1 2 3; do   # services can take a moment to come back after a reload/restart
    missing=""; now="$(listening_ports | tr '\n' ' ')"
    for p in $GUARD_PORTS; do
      [[ "$p" == *:* ]] && continue                      # ranges (FTP passive) aren't listening sockets
      in_list "$p" $GUARD_EXPECT && continue             # you chose to stop the service that owned it
      port_in "$p" "$now" || missing="$missing $p"
    done
    [[ -z "$missing" ]] && break; sleep 2
  done
  local cmd_fail=""
  if [[ -n "${SERVICE_CHECK_CMD:-}" ]] && ! bash -c "$SERVICE_CHECK_CMD" >/dev/null 2>&1; then cmd_fail=" and '$SERVICE_CHECK_CMD' FAILS"; fi
  if [[ -z "$missing" && -z "$cmd_fail" ]]; then ok "service guard: everything still listening after $1"; return 0; fi
  bad "SERVICE GUARD: after module '$1' these stopped listening:${missing:- (none)}$cmd_fail"
  if ask "Undo EVERYTHING this run changed, right now?"; then
    ROLLBACK_RUN="$BK" do_rollback; ROLLBACK_RUN=""
    new_run; mod_backup >/dev/null; BACKUP_DONE=true
  fi
}
# confirm_typed NAME "why" : extra-careful yes for things that serve a scored port
confirm_typed() {
  $AUDIT && return 1
  $YES && { info "--yes: never done automatically: $2"; return 1; }
  local a; read -r -p "  ${R}${B}$2${N} Type '$1' to do it anyway, anything else to skip: " a </dev/tty || return 1
  [[ "$a" == "$1" ]]
}

# ---- baseline / diff / watch -------------------------------------------------
# Files where any change matters most. Their contents are copied into the baseline, so --diff
# can show WHAT changed inside them, not only that a hash changed.
CRITICAL_PATHS="/etc/pam.d /etc/sudoers /etc/sudoers.d /etc/ssh/sshd_config /etc/ssh/sshd_config.d /etc/ssh/sshrc
/etc/systemd/system /etc/systemd/user /etc/update-motd.d /etc/apt/apt.conf.d /etc/apt/sources.list /etc/apt/sources.list.d
/etc/udev/rules.d /etc/profile /etc/profile.d /etc/bash.bashrc /etc/environment /etc/ld.so.preload /etc/ld.so.conf.d
/etc/rc.local /etc/crontab /etc/cron.d /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/init.d
/etc/security /etc/hosts /etc/nsswitch.conf /etc/modules /etc/modprobe.d /etc/ufw/user.rules /etc/ufw/user6.rules"
critical_files() { local p; for p in $CRITICAL_PATHS; do [[ -e "$p" ]] && find "$p" -xdev -type f 2>/dev/null; done | sort -u; }

# privileged_users -> "user|how" lines: everyone who can become root, and how
# (UID 0, sudo/admin/wheel membership incl. PRIMARY group, docker/lxd/disk, and sudoers grants incl. %groups and User_Alias)
sudoers_files() {
  local f inc
  echo /etc/sudoers; ls -d /etc/sudoers.d/* 2>/dev/null
  for inc in $(grep -hE '^\s*[@#]include(dir)?\s' /etc/sudoers /etc/sudoers.d/* 2>/dev/null | awk '{print $2}'); do
    [[ "$inc" == /etc/sudoers.d || "$inc" == /etc/sudoers.d/ ]] && continue
    ls -d "$inc" "$inc"/* 2>/dev/null
  done
}
group_members() { local g="$1" gid; gid="$(getent group "$g" | cut -d: -f3)"; [[ -n "$gid" ]] || return 0
  getent group "$g" | cut -d: -f4 | tr ',' '\n'; awk -F: -v g="$gid" '$4==g{print $1}' /etc/passwd; }
privileged_users() {
  local g u f
  {
    awk -F: '$3==0{print $1"|UID 0"}' /etc/passwd
    for g in sudo admin wheel; do group_members "$g" | awk -v h="group $g" 'NF{print $0 "|" h}'; done
    for g in docker lxd disk; do group_members "$g" | awk -v h="group $g (root-equivalent)" 'NF{print $0 "|" h}'; done
    for f in $(sudoers_files); do
      [[ -f "$f" ]] || continue
      # skip files sudo itself ignores (names with a dot or ending in ~)
      [[ "$f" == /etc/sudoers.d/* && ( "$(basename "$f")" == *.* || "$f" == *~ ) ]] && continue
      awk -v f="$f" '
        /^[ \t]*(#|$)/ || /^[ \t]*Defaults/ || /^[ \t]*[@#]include/ {next}
        /^[ \t]*User_Alias/ { sub(/^[ \t]*User_Alias[ \t]+/,""); n=split($0,parts,"="); name=parts[1]; gsub(/[ \t]/,"",name);
                              m=parts[2]; gsub(/[ \t]/,"",m); A[name]=m; next }
        /^[ \t]*[A-Za-z_]+_Alias/ {next}
        { who=$1; tag=($0 ~ /NOPASSWD/)?" NOPASSWD":""
          if (who in A) { k=split(A[who],mem,","); for(i=1;i<=k;i++) print mem[i] "|sudoers " f tag }
          else print who "|sudoers " f tag }' "$f"
    done
  } | while IFS='|' read -r u how; do
        [[ -z "$u" ]] && continue
        if [[ "$u" == %* ]]; then g="${u#%}"; group_members "$g" | awk -v h="$how (via %$g)" 'NF{print $0 "|" h}'
        elif [[ "$u" == ALL ]]; then echo "ALL (every user)|$how"
        else echo "$u|$how"; fi
      done | grep -v '^|' | sort -u
}
# role_check: compare who CAN be root against the packet's roles (ADMIN_USERS / KEEP_USERS in lockdown.conf).
# Prints one "ROLE:" line per problem. Absolute check: catches problems that were already there at baseline time.
role_check() {
  local allowed="root $ADMIN_USERS $PROTECTED_USERS" priv u how
  if [[ -z "$ADMIN_USERS" ]]; then echo "ROLE: ADMIN_USERS is not set in lockdown.conf, so roles can't be checked"; return; fi
  priv="$(privileged_users)"
  for u in $(echo "$priv" | cut -d'|' -f1 | sort -u); do
    in_list "$u" $allowed && continue
    how="$(echo "$priv" | awk -F'|' -v u="$u" '$1==u{o=o (o?"; ":"") $2} END{print o}')"
    if [[ "$u" == "ALL (every user)" ]]; then echo "ROLE: EVERY user has root rights: $how"
    elif in_list "$u" $KEEP_USERS; then echo "ROLE: $u is an EMPLOYEE in the packet but can become root: $how"
    else echo "ROLE: $u is NOT in the packet but can become root: $how"; fi
  done
  # login accounts the packet doesn't know about
  for u in $(login_users); do
    in_list "$u" root $ADMIN_USERS $KEEP_USERS $SERVICE_USERS $PROTECTED_USERS && continue
    echo "ROLE: $u can log in but is not a packet user ($(getent passwd "$u" | cut -d: -f3,7))"
  done
  # packet users that are missing (R8: don't delete them; the scorer may log in as them)
  for u in $ADMIN_USERS $KEEP_USERS; do id "$u" >/dev/null 2>&1 || echo "ROLE: packet user $u is MISSING from this box"; done
  # admins who lost sudo (red team removing your admins, or a mistake)
  for u in $ADMIN_USERS; do
    id "$u" >/dev/null 2>&1 || continue
    echo "$priv" | cut -d'|' -f1 | grep -qx "$u" || echo "ROLE: admin $u has NO sudo rights (packet role: admin)"
  done
}

# hash_tree NAME DIR... -> "sha256  path" for every file, but only files whose inode/size/ctime changed since
# the last run are actually re-hashed (ctime can't be set back with touch). A multi-GB repo costs a find, not a re-read.
# HASH_FULL=1 ignores the cache (baseline does that).
hash_tree() {
  local name="$1"; shift
  local cache="$BK_ROOT/.hc-$name" w d dirs=""
  for d in "$@"; do [[ -d "$d" ]] && dirs="$dirs $d"; done
  [[ -z "$dirs" ]] && return 0
  w="$(mktemp -d)"
  if [[ -f "$cache" && "${HASH_FULL:-0}" != 1 ]]; then cp "$cache" "$w/cache"; else : > "$w/cache"; fi
  # shellcheck disable=SC2086
  find $dirs -xdev -type f -not -path '*/.git/objects/*' -not -path '*/cache/*' -printf '%i %s %C@\t%p\n' 2>/dev/null | sort -u -t$'\t' -k2 > "$w/cur"
  : > "$w/ok"; : > "$w/todo"
  awk -F'\t' -v ok="$w/ok" -v todo="$w/todo" 'FILENAME==ARGV[1] { m[$3]=$1; h[$3]=$2; next }
       { if (($2 in m) && m[$2]==$1) print $1 "\t" h[$2] "\t" $2 > ok; else print $2 > todo }' "$w/cache" "$w/cur"
  if [[ -s "$w/todo" ]]; then
    nice -n 19 xargs -r -d '\n' sha256sum -- < "$w/todo" 2>/dev/null \
      | awk -F'\t' 'FILENAME==ARGV[1] { m[$2]=$1; next } { print m[substr($0,67)] "\t" substr($0,1,64) "\t" substr($0,67) }' "$w/cur" - >> "$w/ok"
  fi
  cp "$w/ok" "$cache.$$" && mv -f "$cache.$$" "$cache"; chmod 600 "$cache"
  awk -F'\t' '{print $2 "  " $3}' "$w/ok" | sort -k2
  rm -rf -- "${w:?}"
}

snapshot() {   # snapshot DIR [light PREVDIR] : light = reuse the slow SUID/capability scans from PREVDIR
  local d="$1" f u h mode="${2:-full}" prev="${3:-}"
  mkdir -p "$d"; chmod 700 "$d"
  getent passwd | sort > "$d/passwd"
  getent group | sort > "$d/group"
  awk -F: '{print $1, $2}' /etc/shadow | while read -r u h; do echo "$u $(echo "$h" | sha256sum | cut -c1-12)"; done | sort > "$d/shadow-hashes"
  cat /etc/sudoers /etc/sudoers.d/* 2>/dev/null | grep -vE '^\s*(#|$)' | sort > "$d/sudoers"
  { while IFS=: read -r u _ _ _ _ h _; do for f in "$h"/.ssh/authorized_keys*; do [[ -f "$f" ]] && sed "s|^|$f: |" "$f"; done; done < /etc/passwd; } | sort -u > "$d/authorized_keys"
  # cron CONTENT only (old version used ls -la, so every timestamp change showed up)
  { for u in $(cut -d: -f1 /etc/passwd); do crontab -l -u "$u" 2>/dev/null | grep -vE '^\s*(#|$)' | sed "s|^|crontab $u: |"; done
    for f in /etc/crontab /etc/cron.d/*; do [[ -f "$f" ]] && grep -vE '^\s*(#|$)' "$f" | sed "s|^|$f: |"; done
    for f in /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/*; do [[ -f "$f" ]] && echo "script $f"; done
    for f in /var/spool/cron/atjobs/*; do [[ -f "$f" && "$(basename "$f")" != .SEQ ]] && echo "at job $(basename "$f"): $(grep -vE '^\s*(#|$)|^[A-Za-z_]+=|^export ' "$f" | tail -1)"; done
  } | sort > "$d/cron"
  systemctl list-unit-files --state=enabled --no-legend --plain 2>/dev/null | awk '{print $1}' | sort > "$d/enabled-units"
  # protocol, address, process NAMES (no pids/fds: those change on every restart and were pure noise)
  ss -tulnpH 2>/dev/null | awk '{n=$7; out=""; delete seen
      while (match(n, /"[^"]+"/)) { p=substr(n,RSTART+1,RLENGTH-2); if(!(p in seen)){seen[p]=1; out=out (out?",":"") p}; n=substr(n,RSTART+RLENGTH) }
      print $1, $5, out}' | sort -u > "$d/listening"
  if [[ "$mode" == light && -f "$prev/suid" && -f "$prev/caps" ]]; then cp "$prev/suid" "$prev/caps" "$d/"
  else suid_scan > "$d/suid"; caps_scan > "$d/caps"; fi
  for f in /root/.bashrc /root/.profile /root/.bash_logout /root/.ssh/rc /home/*/.bashrc /home/*/.profile /home/*/.bash_profile /home/*/.bash_logout /home/*/.zshrc /home/*/.ssh/rc; do
    [[ -f "$f" ]] && sha256sum "$f"; done | sort -k2 > "$d/dotfiles"
  lsmod 2>/dev/null | awk 'NR>1{print $1}' | sort > "$d/modules"
  # critical files: hash + copy (for content diffs)
  critical_files > "$d/.critical-list"
  xargs -r -d '\n' sha256sum < "$d/.critical-list" 2>/dev/null | sort -k2 > "$d/critical-hashes"
  mkdir -p "$d/files"; tar -cf - -T "$d/.critical-list" 2>/dev/null | tar -xf - -C "$d/files" 2>/dev/null
  # shellcheck disable=SC2046
  hash_tree web $(web_roots) > "$d/web-hashes"
  privileged_users > "$d/privileged"
  # shellcheck disable=SC2086
  hash_tree watch $WATCH_DIRS > "$d/watched-dirs"
  # the rest of /etc (critical files and account files are covered above)
  hash_tree etc /etc \
    | grep -vE '  /etc/(mtab|ld\.so\.cache|adjtime|passwd|group|shadow|gshadow|subuid|subgid)$|-$' \
    | awk 'FILENAME==ARGV[1]{c[$0]=1; next} !(substr($0,67) in c)' "$d/.critical-list" - \
    | sort -k2 > "$d/etc-hashes"
}
fingerprint() { (cd "$1" && find . -type f ! -name FINGERPRINT -print0 | sort -z | xargs -0 sha256sum | sha256sum | cut -c1-16); }

# hashdiff OLD NEW -> "changed: path" / "new: path" / "removed: path" (instead of raw hash pairs)
hashdiff() {
  awk 'FILENAME==ARGV[1] { o[substr($0,67)]=$1; next }
       { p=substr($0,67); if (!(p in o)) print "  new:     " p; else if (o[p]!=$1) print "  changed: " p; delete o[p] }
       END { for (p in o) print "  removed: " p }' "$1" "$2" | sort -k2
}
compare() {   # compare OLD NEW -> prints changes, returns 0 if any
  local o="$1" n="$2" any=1 f name out
  # most important first, raw /etc hashes last
  for name in passwd group shadow-hashes privileged sudoers authorized_keys cron critical-hashes listening suid caps enabled-units dotfiles modules web-hashes watched-dirs etc-hashes; do
    f="$n/$name"; [[ -f "$f" && -f "$o/$name" ]] || continue
    case "$name" in
      critical-hashes|web-hashes|watched-dirs|etc-hashes|dotfiles) out="$(hashdiff "$o/$name" "$f")";;
      *) out="$(diff "$o/$name" "$f" | grep -E '^[<>]' | sed -e 's/^</  - /' -e 's/^>/  + /')";;
    esac
    [[ -z "$out" ]] && continue
    any=0; printf "%s[%s]%s\n" "$Y" "$name" "$N"
    if [[ "$name" != critical-hashes ]]; then echo "$out"
    else   # show what changed INSIDE each critical file, right under it
      local st p
      echo "$out" | while read -r st p; do
        echo "  $st $p"
        case "$st" in
          changed:) [[ -f "$o/files$p" ]] && diff -u "$o/files$p" "$p" 2>/dev/null | tail -n +3 | grep -E '^[-+]' | head -15 | sed 's/^/        /';;
          new:)     [[ -f "$p" ]] && grep -vE '^\s*(#|$)' "$p" 2>/dev/null | head -8 | sed 's/^/        + /';;
        esac
      done
    fi
  done
  return $any
}
mod_baseline() {
  hdr "Baseline"
  $AUDIT && { info "audit mode: run --baseline to save one"; return; }
  ask "Save a baseline of the current state (run this AFTER hardening)?" || return
  save_baseline
}
save_baseline() {
  [[ -d "$BK_ROOT/baseline" ]] && { rm -rf "$BK_ROOT/baseline.prev"; mv "$BK_ROOT/baseline" "$BK_ROOT/baseline.prev"; }
  HASH_FULL=1 snapshot "$BK_ROOT/baseline"     # baseline re-reads every file (no cache)
  local fp; fp="$(fingerprint "$BK_ROOT/baseline")"; echo "$fp" > "$BK_ROOT/baseline/FINGERPRINT"
  local tgz="$BK_ROOT/baseline-$(hostname -s)-$(date +%Y%m%d-%H%M%S).tgz"
  tar -czf "$tgz" -C "$BK_ROOT" baseline 2>/dev/null; chmod 600 "$tgz"
  did "baseline saved to $BK_ROOT/baseline (previous one kept as baseline.prev)"
  echo "  ${B}Baseline fingerprint: $fp${N}  <- write it on paper or take a screenshot (R23 allows screenshots)."
  echo "  Anyone with root here can edit the baseline. --diff prints the fingerprint each time: if it differs, the baseline was tampered with."
  echo "  Second copy: put it on your JUMPBOX (another box in your topology), NOT your own laptop: R23 forbids taking"
  echo "  artifacts off competition infrastructure. From the jumpbox: scp root@$(hostname -I 2>/dev/null | awk '{print $1}'):$tgz ~/baselines/"
  echo "  Compare later with:  $0 --diff /path/to/that.tgz  (copy it back first)"
  if have rkhunter; then
    rkhunter --propupd --nocolors >/dev/null 2>&1 && ok "rkhunter --propupd: rkhunter's own file baseline updated (stops its 'file changed' false positives)"
  fi
}
do_diff() {   # do_diff [baseline dir or .tgz]
  local base="${1:-$BK_ROOT/baseline}" tmpb=""
  if [[ -f "$base" ]]; then tmpb="$(mktemp -d)"; tar -xzf "$base" -C "$tmpb" && base="$tmpb/baseline"; fi
  [[ -d "$base" ]] || { echo "no baseline. Run --baseline first"; return 1; }
  local cur; cur="$(mktemp -d)"; snapshot "$cur"
  local fp; fp="$(fingerprint "$base")"
  echo "${B}Changes since baseline ($(stat -c %y "$base" | cut -d. -f1)), baseline fingerprint $fp${N}"
  [[ -f "$base/FINGERPRINT" && "$(cat "$base/FINGERPRINT")" != "$fp" ]] && echo "${R}${B}WARNING: baseline fingerprint changed since it was saved ($(cat "$base/FINGERPRINT")): the baseline itself was modified!${N}"
  local rc=0; compare "$base" "$cur" || { echo "  no changes"; rc=1; }
  local roles; roles="$(role_check)"
  if [[ -n "$roles" ]]; then printf "%s[roles vs packet]%s\n" "$R$B" "$N"; echo "$roles" | sed 's/^ROLE: /  /'; rc=0
  else printf "%s[roles vs packet]%s ok: only packet admins and staff can become root\n" "$G" "$N"; fi
  rm -rf "$cur" "$tmpb"
  return $rc
}
do_watch() {
  [[ -d "$BK_ROOT/baseline" ]] || { save_baseline; }
  # lowest CPU and disk priority: scored services always win
  renice -n 19 -p $$ >/dev/null 2>&1; have ionice && ionice -c3 -p $$ >/dev/null 2>&1
  WATCH_TMP="$(mktemp -d)"
  local wl="$BK_ROOT/watch.log" prev="$WATCH_TMP/prev.txt" now="$WATCH_TMP/now.txt" last="$WATCH_TMP/last" cur="$WATCH_TMP/cur"
  local n=0 mode t0 took
  : > "$prev"
  echo "${Y}R10: hands-off periods (e.g. lunch 12:00-13:00 CT) = do nothing on the boxes. Ask Black Team before leaving this running then.${N}"
  echo "watching every ${WATCH_SECS}s against the baseline, low priority; SUID/capability scans every ${HEAVY_EVERY} cycles (Ctrl-C to stop). Log: $wl"
  [[ -n "$SCORED_PORTS" ]] && echo "scored ports watched: $SCORED_PORTS"
  while true; do
    t0=$SECONDS
    mode=light; (( n % HEAVY_EVERY == 0 )) && mode=full
    rm -rf -- "${cur:?}"; snapshot "$cur" "$mode" "$last"
    # compare against the BASELINE (not the previous check), plus absolute checks (roles, scored ports)
    { compare "$BK_ROOT/baseline" "$cur"; role_check | sed 's/^ROLE: /  ROLE: /'; scored_down | sed 's/^/  /'; } | sed 's/\x1b\[[0-9;]*m//g' > "$now"
    local fresh; fresh="$(grep -vxFf "$prev" "$now" | grep -vE '^\[')"
    if [[ -n "$fresh" ]]; then
      printf "\n%s=== %s %s: NEW changes ===%s\n%s\n" "$R$B" "$(date +%T)" "$(hostname)" "$N" "$fresh"
      { echo "=== $(date '+%F %T')"; echo "$fresh"; } >> "$wl"
      printf '\a'   # terminal bell
    fi
    local gone; gone="$(grep -vxFf "$now" "$prev" | grep -vE '^\[')"
    [[ -n "$gone" ]] && { printf "%s%s back to baseline:%s\n%s\n" "$G" "$(date +%T)" "$N" "$gone"; { echo "=== $(date '+%F %T') reverted"; echo "$gone"; } >> "$wl"; }
    took=$((SECONDS-t0))
    printf "%s[%s] %d line(s) differ from the baseline (--diff for details). check took %ss (%s)%s\r" "$C" "$(date +%T)" "$(grep -vc '^\[' "$now")" "$took" "$mode" "$N"
    cp "$now" "$prev"; rm -rf -- "${last:?}"; mv "$cur" "$last"; n=$((n+1))
    sleep "$WATCH_SECS"
  done
}

# newest run that changed something and hasn't been undone
last_undoable() {
  local d best=""
  for d in "$BK_ROOT"/run-*; do
    [[ -s "$d/manifest" && ! -e "$d/undone" ]] && best="$d"
  done
  echo "$best"
}
list_runs() {
  local d n any=false nxt; nxt="$(last_undoable)"
  echo "Runs that changed something (oldest first):"
  for d in "$BK_ROOT"/run-*; do
    [[ -s "$d/manifest" ]] || continue
    any=true; n="$(grep -c . "$d/manifest")"
    if [[ -e "$d/undone" ]]; then printf "  %s  %3d changes  (undone)\n" "$(basename "$d")" "$n"
    else printf "  %s  %3d changes%s\n" "$(basename "$d")" "$n" "$([[ "$d" == "$nxt" ]] && echo "  <- next to undo")"; fi
  done
  $any || echo "  none yet (audit runs and runs where you answered no to everything aren't listed)"
  echo "Undo the next one: $0 --rollback    Undo a specific one: $0 --rollback <name>"
}
do_rollback() {
  local L
  if [[ -n "${ROLLBACK_RUN:-}" ]]; then
    L="$BK_ROOT/${ROLLBACK_RUN#$BK_ROOT/}"
    [[ -d "$L" ]] || { echo "no run called $ROLLBACK_RUN"; list_runs; return 1; }
    [[ -s "$L/manifest" ]] || { echo "$(basename "$L") made no changes (audit run, or you answered no to everything). Nothing to undo."; list_runs; return 1; }
    if [[ -e "$L/undone" ]]; then echo "$(basename "$L") was already undone at $(cat "$L/undone")."; ask "Restore it again anyway?" || return 0; fi
  else
    L="$(last_undoable)"
    [[ -n "$L" ]] || { echo "Nothing left to undo."; list_runs; return 1; }
  fi
  echo "Rolling back run: $(readlink -f "$L")"
  local newer; newer="$(for d in "$BK_ROOT"/run-*; do [[ "$d" > "$L" && -s "$d/manifest" && ! -e "$d/undone" ]] && basename "$d"; done)"
  [[ -n "$newer" ]] && echo "  ${Y}warning: newer runs not undone yet: $(echo $newer). Undo those first or files may end up mixed.${N}"
  # preview, so you can see what a restore would overwrite (including edits made AFTER the run)
  local e i=0
  while read -r e; do
    i=$((i+1))
    case "$e" in
      acct:*) printf "  %2d  account %s: put back shell/expiry/password as before the run\n" "$i" "${e#acct:}";;
      grp:*)  IFS=: read -r _ u g <<< "$e"; printf "  %2d  add %s back to group %s\n" "$i" "$u" "$g";;
      svc:*)  IFS=: read -r _ u en act <<< "$e"; printf "  %2d  service %s back to %s/%s\n" "$i" "$u" "${en:-enabled}" "${act:-active}";;
      cap:*)  IFS=: read -r _ p c <<< "$e"; printf "  %2d  capability %s back on %s\n" "$i" "$c" "$p";;
      crontab:*) printf "  %2d  put back %s's crontab\n" "$i" "${e#crontab:}";;
      NEW:*)  printf "  %2d  delete %s (created by the run)\n" "$i" "${e#NEW:}";;
      chmod:*|perm:*|sysctl:*|fw:*) printf "  %2d  %s\n" "$i" "$e";;
      *) if [[ -e "$L/files$e" ]]; then
           if [[ -f "$e" && -f "$L/files$e" ]]; then
             if cmp -s "$e" "$L/files$e"; then printf "  %2d  %s (already identical, will skip)\n" "$i" "$e"
             else printf "  %2d  restore %s (%s lines differ now)\n" "$i" "$e" "$(diff "$L/files$e" "$e" 2>/dev/null | grep -c '^[<>]')"; fi
           else printf "  %2d  restore %s\n" "$i" "$e"; fi
         fi;;
    esac
  done < <(tac "$L/manifest")
  local how=""
  if $YES; then how=y
  else read -r -p "  Restore [a]ll of the above, [s]elect one by one, or [N]othing? " how </dev/tty || how=n; fi
  case "$how" in a|A|y|Y) how=all;; s|S) how=select;; *) echo "  nothing restored."; return 0;; esac

  local reload_ssh=false reload_sysctl=false fix_ufw=false reload_apache=false fails=0 skipped=0
  local u g p m o c en act src
  # reverse order, so the last change is undone first
  while read -r e; do
    if [[ "$how" == select ]]; then
      local a; read -r -p "  restore: $e ? [y/N] " a </dev/tty || a=n
      [[ "$a" =~ ^[Yy] ]] || { skipped=$((skipped+1)); continue; }
    fi
    case "$e" in
      acct:*)
        u="${e#acct:}"; src="$L/acct/$u"
        if [[ -f "$src" ]] && id "$u" >/dev/null 2>&1; then
          local sh ex hs; { read -r sh; read -r ex; read -r hs; } < "$src"
          [[ -n "$ex" ]] && ex="$(date -u -d "@$((ex*86400))" +%F)"
          if usermod -p "$hs" -s "${sh:-/bin/bash}" -e "$ex" "$u"; then echo "  restored account $u"
          else echo "  ${R}could not restore account $u${N}"; fails=$((fails+1)); fi
        else echo "  ${R}no saved state for $u (or user gone)${N}"; fails=$((fails+1)); fi;;
      crontab:*) u="${e#crontab:}"; crontab -u "$u" "$L/crontabs/$u" 2>/dev/null && echo "  restored $u's crontab" || { echo "  ${R}could not restore $u's crontab${N}"; fails=$((fails+1)); };;
      grp:*)   IFS=: read -r _ u g <<< "$e"; gpasswd -a "$u" "$g" >/dev/null 2>&1 && echo "  added $u back to $g" || { echo "  ${R}could not add $u to $g${N}"; fails=$((fails+1)); };;
      cap:*)   IFS=: read -r _ p c <<< "$e"; setcap "$c" "$p" 2>/dev/null && echo "  restored $c on $p" || { echo "  ${R}could not restore caps on $p${N}"; fails=$((fails+1)); };;
      NEW:*)   rm -rf "${e#NEW:}"; echo "  removed ${e#NEW:}"; [[ "$e" == *sysctl* ]] && reload_sysctl=true; [[ "$e" == *ssh* ]] && reload_ssh=true;;
      chmod:*) IFS=: read -r _ p m <<< "$e"; chmod "$m" "$p" 2>/dev/null && echo "  restored mode $m on $p" || { echo "  ${R}could not chmod $p${N}"; fails=$((fails+1)); };;
      svc:*)   # restore the state it had BEFORE (old format "svc:unit" meant enabled+active)
               IFS=: read -r _ u en act <<< "$e"; en="${en:-enabled}"; act="${act:-active}"
               systemctl unmask "$u" >/dev/null 2>&1
               case "$en" in enabled|enabled-runtime|static|alias|indirect) systemctl enable "$u" >/dev/null 2>&1;; masked) systemctl mask "$u" >/dev/null 2>&1;; esac
               [[ "$act" == active ]] && systemctl start "$u" >/dev/null 2>&1
               if [[ "$act" != active ]] || systemctl is-active --quiet "$u"; then echo "  $u back to $en/$act"
               else echo "  ${R}could not start $u (do it by hand)${N}"; fails=$((fails+1)); fi;;
      sysctl:*) sysctl -p "${e#sysctl:}" >/dev/null 2>&1; echo "  restored previous kernel settings";;
      perm:*)  IFS=: read -r _ p m o g <<< "$e"; chown "$o:$g" "$p" && chmod "$m" "$p" && echo "  restored $m $o:$g on $p" || { fails=$((fails+1)); };;
      fw:iptables)
               for c in iptables ip6tables; do have $c || continue; $c -D INPUT -j LOCKDOWN_IN 2>/dev/null; $c -F LOCKDOWN_IN 2>/dev/null; $c -X LOCKDOWN_IN 2>/dev/null; done
               echo "  removed lockdown iptables/ip6tables rules";;
      *)       [[ -e "$L/files$e" ]] || continue
               if [[ -f "$e" ]] && cmp -s "$e" "$L/files$e"; then continue; fi
               if restore_file "$L/files$e" "$e"; then echo "  restored $e"
               else echo "  ${R}FAILED to restore $e (original is still at $L/files$e)${N}"; fails=$((fails+1)); continue; fi
               case "$e" in
                 /etc/ssh/*) reload_ssh=true;; /etc/ufw|/etc/default/ufw) fix_ufw=true;; /etc/apache2/*) reload_apache=true;;
               esac;;
    esac
  done < <(tac "$L/manifest")
  $reload_ssh && { mkdir -p /run/sshd; if sshd -t; then { systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null; echo "  reloaded sshd"; }; else echo "  ${R}sshd -t failed, check /etc/ssh by hand${N}"; fails=$((fails+1)); fi; }
  $fix_ufw && { if grep -q '^ENABLED=no' /etc/ufw/ufw.conf 2>/dev/null; then ufw --force disable >/dev/null; echo "  ufw disabled (was off before)"; else ufw reload >/dev/null; echo "  ufw reloaded"; fi; }
  $reload_apache && { apache2ctl configtest >/dev/null 2>&1 && systemctl reload apache2 && echo "  reloaded apache2"; }
  $reload_sysctl && { sysctl --system >/dev/null 2>&1; echo "  sysctl files reloaded"; }
  grep -q "^acct:" "$L/manifest" && echo "  ${Y}Restored accounts have their old password/lock state back. If a password had been rotated, update the scoring dashboard!${N}"
  if [[ $fails -gt 0 ]]; then
    echo "  ${R}$fails item(s) failed. The run is NOT marked undone; fix them and run --rollback $(basename "$L") again.${N}"
    return 1
  fi
  if [[ $skipped -gt 0 ]]; then
    echo "  $skipped item(s) skipped on purpose. The run stays active, so the rest can be undone later."
    return 0
  fi
  date +%T > "$L/undone"
  echo "Done. $(basename "$L") is marked undone. Not reversible: killed processes, dropped MySQL users or test database."
}

# ---- plain-English descriptions (menu + before each module) ------------------
declare -A RISK DESC CHG TIME
# rough wall-clock on a 2-vCPU competition VM (most of it waiting on you)
TIME=([inventory]="<5s" [users]="<10s" [sudo]="<5s" [ssh]="<5s" [keys]="<5s" [firewall]="~90s (KEEP window)" [persistence]="10-40s"
      [services]="<5s" [sysctl]="<2s" [perms]="5-30s" [caps]="2-15s" [web]="5-30s" [db]="<5s" [other]="<5s"
      [scanners]="3-15 min, heavy CPU/disk" [baseline]="5-30s")
RISK[inventory]="READ-ONLY"
DESC[inventory]="Shows host info, login users, UID 0 accounts, sudo members, listening ports, sessions."
CHG[inventory]="Nothing."
RISK[users]="MEDIUM"
DESC[users]="Finds extra UID 0 accounts, empty passwords, and login users not on your keep list. Can rotate passwords."
CHG[users]="Locks accounts you approve (never deletes). New passwords saved to /root/lockdown-passwords-*.txt. Update the dashboard."
RISK[sudo]="MEDIUM"
DESC[sudo]="Lists who has sudo and any NOPASSWD rules."
CHG[sudo]="Removes non-admins from sudo groups and their sudoers rules, removes NOPASSWD from admin rules (visudo-checked). Staff rules kept."
RISK[ssh]="HIGH"
DESC[ssh]="Shows current SSH settings and proposes safer ones. Password login stays on."
CHG[ssh]="Writes sshd_config.d/00-lockdown.conf, tests with sshd -t, reloads sshd. Test a NEW login afterwards."
RISK[keys]="MEDIUM"
DESC[keys]="Lists every authorized_keys file with key fingerprints."
CHG[keys]="Moves key files you approve into the backup folder. Staff keys are never touched."
RISK[firewall]="HIGH"
DESC[firewall]="Shows listening ports and builds an inbound allow list."
CHG[firewall]="Denies inbound except your ports (ufw or iptables). Shows what it would block first. Auto-reverts unless you type KEEP. Outbound untouched."
RISK[persistence]="MEDIUM"   # units/processes serving a listening port need the name typed
DESC[persistence]="Hunts cron jobs, unknown systemd units, ld.so.preload, PAM, shell rc backdoors, modified binaries, reverse shells."
CHG[persistence]="Removes crontabs, disables units, or kills processes you approve. Staff tools are skipped."
RISK[services]="MEDIUM"
DESC[services]="Lists running services and flags risky legacy ones (telnet, rsh, tftp, cups, avahi, rpcbind...)."
CHG[services]="Stops, disables and masks flagged services (and their sockets) you approve. Everything else is left alone."
RISK[sysctl]="LOW"
DESC[sysctl]="Shows safe kernel/network settings (syncookies, no redirects, restricted ptrace/dmesg)."
CHG[sysctl]="Writes /etc/sysctl.d/99-zz-lockdown.conf and applies it. ip_forward unchanged."
RISK[perms]="LOW"
DESC[perms]="Checks permissions on passwd/shadow/sudoers, world-writable files, and unusual SUID binaries."
CHG[perms]="Fixes file modes and strips SUID bits you approve. Original modes recorded for rollback."
RISK[caps]="MEDIUM"
DESC[caps]="Lists files with Linux capabilities (cap_setuid on python = silent root backdoor)."
CHG[caps]="Removes dangerous capabilities you approve. Recorded for rollback."
RISK[web]="LOW"
DESC[web]="Scans web roots for webshell patterns, scripts in upload dirs, recent changes; checks Apache/nginx/PHP settings."
CHG[web]="Only hides the Apache version if you approve (configtest-checked). Everything else is report only."
RISK[db]="MEDIUM"
DESC[db]="Lists MySQL/Postgres users, hosts and risky auth settings."
CHG[db]="Drops anonymous MySQL users or the test database if you approve. NOT reversible."
RISK[other]="LOW"
DESC[other]="Checks vsftpd, Postfix, BIND and Samba for common weak settings."
CHG[other]="Turns off anonymous FTP if you approve (check the scorer doesn't use it). Rest is report only."
RISK[scanners]="MEDIUM"
DESC[scanners]="Runs Lynis, rkhunter, chkrootkit, ClamAV and maldet; hides stock-Ubuntu false positives and findings you marked known."
CHG[scanners]="Installs missing scanners with apt if you approve (checks APT sources first). Skips ClamAV on low RAM. Nothing is quarantined."
RISK[baseline]="READ-ONLY"
DESC[baseline]="Saves a snapshot of users, keys, cron, units, ports, SUID files and file hashes."
CHG[baseline]="Writes /root/.lockdown/baseline (+ an off-box .tgz) and runs rkhunter --propupd if installed."

explain() {
  local m="$1" col="$G"
  case "${RISK[$m]:-}" in HIGH) col="$R";; MEDIUM) col="$Y";; esac
  printf "  %sWhat it does:%s %s\n" "$B" "$N" "${DESC[$m]:-}"
  printf "  %sRisk:%s %s%s%s   %sTime:%s %s\n" "$B" "$N" "$col" "${RISK[$m]:-}" "$N" "$B" "$N" "${TIME[$m]:-}"
  if $AUDIT; then printf "  %sChanges:%s none (audit mode)\n" "$B" "$N"
  else printf "  %sChanges if you answer y:%s %s\n" "$B" "$N" "${CHG[$m]:-}"; fi
}

run_module() {   # run_module NAME audit|harden
  local m="$1" was="$AUDIT"
  [[ "$2" == audit ]] && AUDIT=true || AUDIT=false
  if ! $AUDIT && ! $BACKUP_DONE; then mod_backup; BACKUP_DONE=true; guard_start; fi
  "mod_$m"
  $AUDIT || in_list "$m" inventory scanners baseline || guard_check "$m"
  AUDIT="$was"
}

menu() {
  local list=(inventory users sudo ssh keys firewall persistence services sysctl perms caps web db other scanners baseline)
  while true; do
    printf "\n%s=== lockdown.sh v%s  |  %s ===%s\n" "$B$C" "$VERSION" "$(hostname)" "$N"
    echo "  Pick a number to read what a module does, then choose audit (look only) or harden."
    local i=1 m col
    for m in "${list[@]}"; do
      col="$G"; [[ "${RISK[$m]}" == HIGH ]] && col="$R"; [[ "${RISK[$m]}" == MEDIUM ]] && col="$Y"
      printf "   %2d) %-12s %s%-9s%s %-10s %s\n" "$i" "$m" "$col" "${RISK[$m]}" "$N" "${TIME[$m]%% *}" "$( d="${DESC[$m]}"; [[ ${#d} -gt 52 ]] && echo "${d:0:49}..." || echo "$d")"
      i=$((i+1))
    done
    echo
    echo "    A) Audit everything (changes nothing)        H) Harden everything (asks before each change)"
    echo "    D) Diff against baseline   W) Watch for changes   U) Undo last run   L) List runs   Q) Quit"
    local c; read -r -p "  > " c </dev/tty || return
    case "$c" in
      [0-9]*)
        [[ "$c" -ge 1 && "$c" -le ${#list[@]} ]] 2>/dev/null || { echo "  no such number"; continue; }
        m="${list[$((c-1))]}"; printf "\n%s>> %s%s\n" "$B$C" "$m" "$N"
        AUDIT=false; explain "$m"
        local how; read -r -p "  Run it: [a]udit (look only), [h]arden, or [b]ack? " how </dev/tty
        case "$how" in a|A) run_module "$m" audit;; h|H) run_module "$m" harden;; *) ;; esac;;
      a|A) for m in "${list[@]}"; do printf "\n%s>> %s%s\n" "$B$C" "$m" "$N"; AUDIT=true; explain "$m"; run_module "$m" audit; done;;
      h|H) echo "  Every change will be shown and needs a y."; for m in "${list[@]}"; do printf "\n%s>> %s%s\n" "$B$C" "$m" "$N"; AUDIT=false; explain "$m"; run_module "$m" harden; done;;
      d|D) do_diff;;
      w|W) local s; read -r -p "  Check every how many seconds? [120] " s </dev/tty; WATCH_SECS="${s:-120}"; do_watch;;
      u|U) do_rollback; list_runs; new_run;;   # later changes go to a NEW run, not the one just undone
      l|L) list_runs;;
      q|Q) echo "  changes this session: $CHANGES   warnings: $WARNS   log: $LOG"; return;;
      *) echo "  type a number or a letter from the menu";;
    esac
  done
}

usage() { sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

# tests/selftest.sh loads the functions with LOCKDOWN_LIB=1 and drives them directly
[[ "${LOCKDOWN_LIB:-}" == 1 ]] && return 0 2>/dev/null

# =============================================================================
# MAIN
# =============================================================================
[[ $# -eq 0 ]] && MODE=menu
while [[ $# -gt 0 ]]; do
  case "$1" in
    --audit) AUDIT=true;;
    --all) ;;
    --yes|-y) YES=true;;
    --only) ONLY="${2//,/ }"; shift;;
    --list) echo "$MODULES"; exit 0;;
    --baseline) MODE=baseline;;
    --diff) MODE=diff; [[ -n "${2:-}" && "$2" != -* ]] && { DIFF_BASE="$2"; shift; };;
    --watch) MODE=watch; [[ "${2:-}" =~ ^[0-9]+$ ]] && { WATCH_SECS="$2"; shift; };;
    --rollback) MODE=rollback; [[ -n "${2:-}" && "$2" != -* ]] && { ROLLBACK_RUN="$2"; shift; };;
    --runs) MODE=runs;;
    -h|--help) usage;;
    *) echo "unknown option $1"; usage;;
  esac; shift
done
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
grep -qiE 'debian|ubuntu' /etc/os-release 2>/dev/null || echo "${Y}warning: built for Debian/Ubuntu. Other distros may misbehave.${N}"
mkdir -p "$BK_ROOT"; chmod 700 "$BK_ROOT"
for m in $ONLY; do in_list "$m" $MODULES || { echo "unknown module '$m'. Modules: $MODULES"; exit 1; }; done
# one changing run at a time (two teammates on one box would mix backups); diff/watch/runs don't need the lock
if [[ "$MODE" != diff && "$MODE" != watch && "$MODE" != runs ]] && ! $AUDIT; then
  exec 9>"$BK_ROOT/.lock"
  flock -n 9 || { echo "another lockdown.sh is already changing this box (lock: $BK_ROOT/.lock). Wait for it to finish."; exit 1; }
fi

case "$MODE" in
  baseline) save_baseline; exit 0;;
  diff) do_diff "${DIFF_BASE:-}"; exit $?;;
  watch) do_watch;;
  rollback) do_rollback; exit 0;;
  runs) list_runs; exit 0;;
  menu) menu; exit 0;;
esac

printf "%slockdown.sh v%s%s  %s  mode: %s\n" "$B" "$VERSION" "$N" "$(hostname)" "$($AUDIT && echo AUDIT || ($YES && echo AUTO || echo CONFIRM))"
$AUDIT || echo "${Y}Keep a second root session open until you've tested SSH and the firewall.${N}"
log "start run $TS mode=$($AUDIT && echo audit || echo harden) only=$ONLY"
mod_backup
$AUDIT || guard_start
for m in $MODULES; do
  [[ "$m" == "backup" ]] && continue
  [[ -n "$ONLY" ]] && ! in_list "$m" $ONLY && continue
  printf "\n%s>> %s%s\n" "$B$C" "$m" "$N"; explain "$m"
  "mod_$m"
  $AUDIT || in_list "$m" inventory scanners baseline || guard_check "$m"
done
hdr "Summary"
echo "  changes applied: $CHANGES   warnings: $WARNS"
$AUDIT && echo "  log: $LOG" || echo "  backups: $BK    log: $LOG"
$AUDIT || echo "  undo everything from this run: $0 --rollback"
echo "  next: $0 --baseline  then  $0 --watch 120"
