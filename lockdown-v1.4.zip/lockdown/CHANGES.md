# v1.4: updated packet (v2) + full line-by-line reread (selftest 105/106 on 24.04; chaos run 100% uptime)

## Packet v2 changes
- R6 (jumpbox now in scope) / R16 (attack infra allowed on the jumpbox): jumpbox profile in the config
  (IS_JUMPBOX=yes): your team's outbound shells are report-only, never offered for killing; ports 3001-3008
  (browser/RDP clients) allowed; SSH forwarding kept (SSH_ALLOW_FORWARDING); SUID/capability scans skip Docker/
  containerd/LXD/snap storage so the containerised clients are never touched.
- R23 (no artifacts off competition infrastructure): baseline/backups go to the jumpbox, never your laptop;
  fingerprint on paper or a screenshot. Password list is fine (passwords are an R23 exception).
- R14/R24: lab tools (lab-setup, plant, chaos, selftest) refuse to run on Xen, on playtcdc.org names and on
  competition hostnames (they create fake Wazuh/Xen units and backdoors). Your own lab uses LAB_OK=1.
- "Password Changes" section: checks may use any OS or service user; reminder now links
  https://dash.playtcdc.org/team/passwords; SERVICE_USERS covers every Discord OS/service user.
- Store link updated (https://dash.playtcdc.org/team/store); README rules section updated.

## Bugs from the reread
- Sudoers: commenting out `%sudo ... NOPASSWD: ALL` removed sudo from EVERY admin. Now: admin rules
  (ADMIN_USERS, root, %sudo/%admin/%wheel) only lose the NOPASSWD tag; rules giving root to anyone else
  (employees, unknown users, other groups, multi-user lines) are commented out (needs a human, not --yes);
  rules naming staff anywhere or using aliases are never touched.
- root's password can now be rotated (R8 protects only blackteam/whiteteam), with a typed confirmation.
- Crontab removal/undo no longer depends on the cron spool path (cron vs cronie on 26.04).
- A malformed /etc/passwd line (easy for red team to plant) could crash the users module under set -u.
- ufw: allow rules are added before the default is switched to deny (no window where allowed ports drop).
- "packaged but MODIFIED" label could match the wrong file (substring match).

# v1.3: competition risk review (verified: selftest 95/96 on 24.04, chaos "y to everything" 100% uptime)

- FTP risk: vsftpd uses pam_shells, so a locked/nologin account can't FTP. Scoring users (packet + new SERVICE_USERS)
  are never locked or given nologin; an empty password on one says "rotate, don't lock".
- Staff tooling: PROTECTED_RE now covers xe-linux-distribution.service (the real Xen guest-tools unit),
  cloud-config/cloud-final; protection added to SUID/caps/cron/crontab/ld.so.preload/risky services; staff
  tooling's listening ports stay open in the firewall; NOPASSWD lines using aliases or naming a protected user are kept.
- root's authorized_keys need "root" typed to quarantine (may be Black Team / provisioning access).
- Firewall: vsftpd passive range missing/not allowed is flagged.
- Bug: the firewall's revert timer inherited the run lock, blocking every run for 90 s after a firewall step.
- Disk-space check before backups; R10 hands-off reminder in --watch.
- New test lab for one machine: tests/lab-up.sh (Multipass VMs with competition hostnames), tests/scorer.sh
  (mini scoring engine), tests/chaos.sh (worst-case operator + reboot test), staff-tooling simulation; test tools
  refuse to run outside a VM.

# v1.2: comp-safety and cost (all verified by tests/selftest.sh, 95/96 on 24.04; the 1 is "not 26.04")

## Never take down a scored service
- Service guard: records listening ports (or SCORED_PORTS) before hardening, re-checks after every module,
  offers an instant undo of the run if one stopped (--yes undoes automatically). Optional SERVICE_CHECK_CMD.
  Warns at start if a SCORED_PORTS entry isn't listening (wrong config or already down).
- Units/processes serving a listening port need their name typed to be stopped.
- Reverse-shell check only flags OUTBOUND interpreter connections: the scorer's inbound connections to a
  python/php/node app are no longer offered for killing.
- Firewall shows every listening port it would block and refuses to block SCORED_PORTS unless you type BLOCK.
- vsftpd restart verified, config restored if it doesn't come back. Service accounts that run a listener keep their shell.
- Risky-service module refuses to stop anything serving a SCORED port.

## Watch / diff
- Roles vs the packet on every check: employees who can become root (sudo group, primary group, sudoers rule,
  %group rule, User_Alias, docker/lxd/disk, UID 0), unknown login/root users, admins who lost sudo, missing packet users.
- "privileged" category: who can become root and how, diffed against the baseline.
- WATCH_DIRS: track repos / FTP roots / app folders (new, changed, deleted files). Per-host presets in the config.
- SCORED_PORTS down alert on every check.

## Cost
- Hash cache: files re-hashed only when inode/size/ctime changed (faked mtimes still caught). 3000 files /
  294 MB: 316 ms first, 29 ms after. Baseline always re-reads everything.
- --watch at nice 19 / idle I/O, SUID+capability scans every HEAVY_EVERY (5) checks, per-check timing shown.
- Scanners at nice 19 / idle I/O; ClamAV only with INSTALL_CLAMAV=yes. Time estimate shown per module.
- Fixed: awk "first file" check misread empty files (an empty old list hid every new file).

# v1.1 changes (all verified by tests/selftest.sh)

## Bugs fixed
- Firewall auto-detect dropped 53/udp when 53/tcp was also listening (DNS outage on ns1).
- Undo in the menu, then hardening again: new changes went into the already-undone run, so the next undo
  said "nothing to undo" or rolled back an OLDER run. Each undo now starts a new run.
- Rollback restored whole /etc/passwd, /etc/shadow, /etc/group: users, groups and sudo memberships added after
  the run were wiped (left half-deleted accounts). Now only the touched accounts are restored.
- Rollback did rm then cp: a failed copy left /etc/shadow missing. Restores are now atomic (copy + rename).
- Rollback re-enabled and started every service it had disabled, even ones that were off before. It now restores
  the exact previous state, and a run is marked undone only if every item succeeded.
- Re-running the firewall module in one session corrupted its auto-revert copy (nested /etc/ufw/ufw).
- Baseline: listening-port check kept PIDs, so every service restart looked like an attack; cron check used
  `ls -la`, so timestamps showed up as changes; --watch compared against the previous check, so a change was shown once and then counted as normal.
- sysctl file 99-lockdown.conf lost to /etc/sysctl.conf at boot. Now 99-zz-lockdown.conf, and verified after apply.
- sshd -t errors were hidden; /run/sshd missing on 22.10+ made it fail silently. Effective values now checked.
- MariaDB 10.4+: anonymous-user removal used DELETE on a view (fails). Now DROP USER.
- umask 077 leaked into the rest of the run after password rotation.
- chkrootkit: only the first 20 lines were shown, mostly RTNETLINK noise.

## Detection added
PAM `sufficient pam_permit` (was explicitly ignored), unpackaged PAM modules, systemd drop-in overrides, symlinked
units, .socket/.path units, motd / APT / udev / if-up hooks, ~/.ssh/rc, sshrc, ForceCommand, sshd drop-ins that
override ours, LD_PRELOAD in environment, file capabilities, SUID on all local filesystems (not just /), more
GTFOBins, system accounts with shells, hashes in /etc/passwd, primary-group sudo, docker/lxd/disk groups,
dangerous sudo Defaults, @includedir elsewhere, existing ufw rules not on your list, .htaccess handler tricks,
real DocumentRoots from Apache/nginx config, IPv6 in the iptables path.

## Safety
- `--yes` no longer locks users, deletes keys/crontabs, disables units, kills processes, strips SUID/caps, drops
  DB objects or marks findings known. Those always need a human.
- Config file is loaded only if root-owned and not group/world-writable.
- One changing run at a time (flock). `--only` rejects unknown module names.
- Baseline fingerprint + off-box .tgz, `--diff file.tgz` to compare against a copy the red team can't edit.
- Scanners: APT sources checked before installing; ClamAV skipped when RAM is low; runs at low priority.

## False positives
Built-in stock-Ubuntu ignore list, dpkg verdict on every file a finding names, per-box "known" lists
(files stored with hash, so edits re-flag). See README.
