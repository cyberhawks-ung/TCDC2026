#!/usr/bin/env bash
# lab-setup.sh - turn a FRESH Ubuntu Server 26.04 VM into a practice copy of a TCDC box.
# Run ONLY on a throwaway VM you can reset (see README "Testing"). Never on competition boxes.
#   sudo ./lab-setup.sh            # all roles on one VM (dns + ftp + web + ssh)
#   sudo ./lab-setup.sh dns        # or one role: dns | ftp | web | ssh
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
# Lab tools only: they plant backdoors and create FAKE Wazuh/Xen units. On competition boxes that would break
# R14/R15 (impersonating staff tools) and R24 (test outside competition infrastructure). Competition boxes are
# Xen VMs, so "is it a VM" isn't enough: refuse on Xen, on playtcdc.org names, and on competition hostnames.
virt="$(systemd-detect-virt 2>/dev/null || echo none)"
fqdn="$(hostname -f 2>/dev/null) $(grep -hE '^(search|domain)' /etc/resolv.conf 2>/dev/null | tr '\n' ' ')"
if [[ "$virt" == xen || "$fqdn" == *playtcdc* || "$(hostname -s)" =~ ^(ns1|ipcam|ftp-archive|artifactorium|ssh-workstation|jumpbox|ad|mqtt|opnsense)$ && "${LAB_OK:-0}" != 1 ]]; then
  echo "this looks like COMPETITION infrastructure (Xen VM, playtcdc.org name or a competition hostname): refusing (R14/R24)."
  echo "In your own Multipass lab with competition hostnames, run with LAB_OK=1."; exit 1
fi
[[ "$virt" == xen || "$fqdn" == *playtcdc* ]] && { echo "refusing on Xen / playtcdc.org even with LAB_OK=1"; exit 1; }
if [[ "$virt" == none && "${FORCE:-0}" != 1 ]]; then echo "this looks like a REAL machine, not a VM: refusing (it adds users/backdoors and hardens for real). Use tests/lab-up.sh to make VMs."; exit 1; fi
ROLE="${1:-all}"
TESTPW="${TESTPW:-Museum-Test-2026}"   # practice password for every packet user

echo "== packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
pk="openssh-server cron at ufw iptables libcap2-bin python3 dnsutils curl"
[[ $ROLE == all || $ROLE == dns ]] && pk="$pk bind9"
[[ $ROLE == all || $ROLE == ftp ]] && pk="$pk vsftpd"
[[ $ROLE == all || $ROLE == web ]] && pk="$pk apache2 php libapache2-mod-php"
apt-get install -y -qq $pk >/dev/null

echo "== packet users (p.15) + staff accounts"
for u in washington kennedy teddy lincoln ross streep franklin parks armstrong hamilton mlk tubman manziel deniro bush blackteam whiteteam; do
  id "$u" >/dev/null 2>&1 || useradd -m -s /bin/bash "$u"
  echo "$u:$TESTPW" | chpasswd
done
for u in washington kennedy teddy lincoln ross blackteam; do usermod -aG sudo "$u"; done
echo 'blackteam ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/90-blackteam; chmod 440 /etc/sudoers.d/90-blackteam

if [[ $ROLE == all || $ROLE == ftp ]]; then
  echo "== vsftpd (local users, passive 40000-50000)"
  sed -i -E '/^#?\s*(write_enable|chroot_local_user|pasv_enable|pasv_min_port|pasv_max_port|allow_writeable_chroot)=/d' /etc/vsftpd.conf
  printf 'write_enable=YES\nchroot_local_user=YES\nallow_writeable_chroot=YES\npasv_enable=YES\npasv_min_port=40000\npasv_max_port=50000\n' >> /etc/vsftpd.conf
  systemctl restart vsftpd
fi
if [[ $ROLE == all || $ROLE == web ]]; then
  echo "== apache + a page"
  echo '<h1>Museum of American and Aggie History</h1>' > /var/www/html/index.html
  systemctl restart apache2
fi
if [[ $ROLE == all || $ROLE == dns ]]; then
  echo "== bind9 test zone museum.test"
  cat > /etc/bind/db.museum.test <<'Z'
$TTL 300
@ IN SOA ns1.museum.test. admin.museum.test. ( 1 300 300 600 300 )
@ IN NS ns1.museum.test.
ns1 IN A 127.0.0.1
www IN A 127.0.0.1
Z
  grep -q museum.test /etc/bind/named.conf.local || echo 'zone "museum.test" { type master; file "/etc/bind/db.museum.test"; };' >> /etc/bind/named.conf.local
  systemctl restart named 2>/dev/null || systemctl restart bind9
fi
echo "== simulate competition staff tooling (must never be touched: R7/R15)"
for u in wazuh-agent xe-linux-distribution; do
  printf '[Unit]\nDescription=%s (simulated staff tool)\n[Service]\nExecStart=/bin/sleep infinity\n[Install]\nWantedBy=multi-user.target\n' "$u" > /etc/systemd/system/$u.service
done
systemctl daemon-reload 2>/dev/null; systemctl enable --now wazuh-agent xe-linux-distribution >/dev/null 2>&1 || true
mkdir -p /var/ossec/bin && cp /bin/true /var/ossec/bin/wazuh-helper && chmod 4755 /var/ossec/bin/wazuh-helper
( crontab -l -u root 2>/dev/null | grep -v wazuh; echo '*/10 * * * * /var/ossec/bin/wazuh-helper # wazuh' ) | crontab -u root -
echo 'whiteteam ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/91-whiteteam; chmod 440 /etc/sudoers.d/91-whiteteam
echo "== a Discord-style service user (system account, used by the scorer for FTP) and a non-packet user"
id ftpsvc >/dev/null 2>&1 || useradd -r -m -s /bin/bash ftpsvc; echo "ftpsvc:$TESTPW" | chpasswd
id intern >/dev/null 2>&1 || useradd -m -s /bin/bash intern; echo "intern:$TESTPW" | chpasswd
systemctl enable --now ssh >/dev/null 2>&1 || true
echo
echo "Done. Practice password for all packet users: $TESTPW"
echo "NOW take a VM snapshot called 'lab-clean' (see README), then run: sudo tests/selftest.sh"
