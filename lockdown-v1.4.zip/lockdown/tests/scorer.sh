#!/usr/bin/env bash
# scorer.sh - a mini scoring engine. Run it on the HOST (or the jumpbox) while you harden the lab VMs.
# Every 30 s ("tick", like the real scorer) it checks each box's scored service with a real answer/login,
# prints a live board, and logs every failed tick with a timestamp, so you can see exactly which step
# of lockdown.sh (or which mistake) cost uptime.
#   tests/scorer.sh                       # uses `tests/lab-up.sh ips` (multipass lab)
#   TARGETS="ns1=10.0.0.5:dns ftp-archive=10.0.0.6:ftp" tests/scorer.sh
# Ctrl-C prints uptime % per service. Log: scorer-<date>.log
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TICK="${TICK:-30}"
TESTPW="${TESTPW:-Museum-Test-2026}"
LOG="${LOG:-$PWD/scorer-$(date +%Y%m%d-%H%M%S).log}"
role_of() { case "$1" in ns1) echo dns;; ftp-archive) echo ftp;; artifactorium|ipcam) echo http;; ssh-workstation) echo ssh;; lab) echo "dns http ftp ssh";; *) echo "";; esac; }
if [[ -z "${TARGETS:-}" ]]; then
  TARGETS=""
  while read -r n ip; do [[ -n "$ip" ]] || continue; for r in $(role_of "$n"); do TARGETS="$TARGETS $n=$ip:$r"; done; done < <("$HERE/lab-up.sh" ips 2>/dev/null)
fi
[[ -n "$TARGETS" ]] || { echo "no targets: set TARGETS or build the lab with tests/lab-up.sh"; exit 1; }
command -v sshpass >/dev/null || echo "note: install sshpass on this machine so SSH is checked with a real password login"
declare -A UP TOTAL
for t in $TARGETS; do UP[$t]=0; TOTAL[$t]=0; done
summary() {
  echo; echo "== uptime"
  for t in $TARGETS; do printf "  %-34s %3d/%-3d ticks  %5.1f%%\n" "$t" "${UP[$t]}" "${TOTAL[$t]}" "$(awk -v u="${UP[$t]}" -v n="${TOTAL[$t]}" 'BEGIN{print n?100*u/n:0}')"; done
  echo "failures logged in $LOG"; exit 0
}
trap summary INT TERM
echo "mini scorer: tick every ${TICK}s. Targets:$TARGETS"; echo "log: $LOG"
while true; do
  line="$(date +%T)"
  for t in $TARGETS; do
    name="${t%%=*}"; rest="${t#*=}"; ip="${rest%%:*}"; svc="${rest#*:}"
    TOTAL[$t]=$((TOTAL[$t]+1))
    if out="$(HOST="$ip" TESTPW="$TESTPW" timeout 20 "$HERE/checks.sh" "$svc" 2>&1)"; then UP[$t]=$((UP[$t]+1)); line="$line  $name/$svc:UP"
    else line="$line  $name/$svc:DOWN"; echo "$(date '+%F %T') DOWN $name $svc: $(echo "$out" | sed 's/\x1b\[[0-9;]*m//g' | grep FAIL | tr '\n' ' ')" >> "$LOG"; fi
  done
  echo "$line" | sed -E "s/:UP/:\x1b[32mUP\x1b[0m/g; s/:DOWN/:\x1b[31mDOWN\x1b[0m/g"
  sleep "$TICK"
done
