#!/usr/bin/env bash
# chaos.sh - the WORST-CASE operator: a tired teammate who answers "y" to every single prompt.
# Run INSIDE a lab VM (never on a competition box or your own machine) while tests/scorer.sh runs on the host.
# Afterwards it checks: scored services still answer, staff tooling untouched, you can still log in.
# Things that need a typed name/KEEP/BLOCK are NOT done by "y" by design: this measures exactly that.
#   sudo tests/chaos.sh            # all modules except the slow scanners
#   sudo tests/chaos.sh --reboot   # ... then reboot, and re-run the checks after boot with: sudo tests/chaos.sh --after-reboot
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; LD="$HERE/lockdown.sh"
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
# Lab tools only: they plant backdoors and create FAKE Wazuh/Xen units. On competition boxes that would break
# R14/R15 (impersonating staff tools) and R24 (test outside competition infrastructure). Competition boxes are
# Xen VMs, so "is it a VM" isn't enough: refuse on Xen, on playtcdc.org names, and on competition hostnames.
virt="$(systemd-detect-virt 2>/dev/null || echo none)"
fqdn="$(hostname -f 2>/dev/null) $(grep -hE '^(search|domain)' /etc/resolv.conf 2>/dev/null | tr '\n' ' ')"
if [[ "$virt" == xen || "$fqdn" == *playtcdc* || "$(hostname -s)" =~ ^(ns1|ipcam|ftp-archive|artifactorium|ssh-workstation|jumpbox|ad|mqtt|opnsense)$ && "${LAB_OK:-0}" != 1 ]]; then
  echo "this looks like COMPETITION infrastructure (Xen VM, playtcdc.org name or a competition hostname): refusing (R14/R24)."
  echo "In your own Multipass lab with competition hostnames, run with LAB_OK=1."; exit 1
fi
[[ "$virt" == xen || "$fqdn" == *playtcdc* ]] && { echo "refusing on Xen / playtcdc.org even with LAB_OK=1"; exit 1; }
if [[ "$virt" == none && "${FORCE:-0}" != 1 ]]; then echo "this looks like a REAL machine, not a VM: refusing (it adds users/backdoors and hardens for real). Use tests/lab-up.sh to make VMs."; exit 1; fi
P=0; F=0
pass(){ printf "  \e[32mPASS\e[0m %s\n" "$1"; P=$((P+1)); }
fail(){ printf "  \e[31mFAIL\e[0m %s\n" "$1"; F=$((F+1)); }
t(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then pass "$d"; else fail "$d"; fi; }

after_checks() {
  echo "== scored services (local view)"
  if bash "$HERE/tests/checks.sh" all; then pass "all local service checks"; else fail "a local service check failed (see above)"; fi
  [[ -n "$(getent passwd ftpsvc)" ]] && { FTP_USER=ftpsvc bash "$HERE/tests/checks.sh" ftp && pass "FTP login as service user ftpsvc" || fail "FTP login as service user ftpsvc"; }
  echo "== staff tooling (R7/R15) untouched"
  t "wazuh-agent unit still enabled"            systemctl is-enabled wazuh-agent
  t "xe-linux-distribution unit still enabled"  systemctl is-enabled xe-linux-distribution
  t "root crontab staff line still there"       bash -c 'crontab -l -u root | grep -q wazuh'
  t "staff SUID helper still SUID"              test -u /var/ossec/bin/wazuh-helper
  t "blackteam can still sudo without password" bash -c 'sudo -l -U blackteam | grep -q NOPASSWD'
  t "blackteam/whiteteam not locked"            bash -c '! passwd -S blackteam | grep -q " L " && ! passwd -S whiteteam | grep -q " L "'
  echo "== you can still get in"
  t "sshd config valid"                         sshd -t
  t "sshd listening on 22"                      bash -c 'ss -tln | grep -q ":22 "'
  t "admin washington still has sudo"           bash -c 'id -nG washington | grep -qw sudo'
  t "packet users not locked"                   bash -c 'for u in washington streep parks bush; do passwd -S $u | grep -q " L " && exit 1; done; true'
  echo; printf "\e[1m%d passed, %d failed\e[0m\n" "$P" "$F"
}

if [[ "${1:-}" == --after-reboot ]]; then echo "== after reboot"; after_checks; exit; fi

cd "$HERE"
[[ -f lockdown.conf ]] || cp lockdown.conf.example lockdown.conf
grep -q '^SERVICE_USERS="ftpsvc"' lockdown.conf || sed -i 's/^SERVICE_USERS=""/SERVICE_USERS="ftpsvc"/' lockdown.conf
chown -R root:root "$HERE"; chmod -R go-w "$HERE"
echo "== running lockdown.sh --all, answering 'y' to EVERYTHING (scanners skipped). Watch tests/scorer.sh on the host."
mods="$(./lockdown.sh --list | tr ' ' '\n' | grep -vE '^(backup|scanners)$' | paste -sd, -)"
start=$(date +%s)
# a bounded stream of "y" (an endless one makes `script` buffer gigabytes)
yes y | head -n 3000 | script -qfec "./lockdown.sh --only $mods" /tmp/chaos.typescript >/dev/null 2>&1
echo "   took $(( $(date +%s) - start ))s; full transcript: /tmp/chaos.typescript"
grep -aE 'SERVICE GUARD|service guard: everything' /tmp/chaos.typescript | sed 's/\x1b\[[0-9;]*m//g' | sed 's/^/   /'
after_checks
if [[ "${1:-}" == --reboot ]]; then echo "rebooting in 5s. After boot: sudo $HERE/tests/chaos.sh --after-reboot"; sleep 5; reboot; fi
