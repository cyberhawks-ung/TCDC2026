#!/usr/bin/env bash
# lab-up.sh - run on YOUR Ubuntu machine (the host). Builds the competition's 5 Ubuntu boxes as Multipass VMs,
# with the same hostnames (so lockdown.conf picks the right ports), installs the services, and snapshots them.
# Nothing here touches your host except installing multipass. Needs ~6 GB free RAM for all 5 (or use ONE=1).
#   tests/lab-up.sh            # 5 VMs: ns1 ftp-archive artifactorium ipcam ssh-workstation
#   ONE=1 tests/lab-up.sh      # 1 VM "lab" with every service (low-RAM machines)
#   tests/lab-up.sh reset      # restore every VM to its clean snapshot (seconds)
#   tests/lab-up.sh ips        # print the VMs' IPs (for tests/scorer.sh)
#   tests/lab-up.sh down       # delete the VMs
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-26.04}"          # 'multipass find' lists images; competition boxes are Ubuntu Server 26.04
if [[ "${ONE:-0}" == 1 ]]; then VMS="lab:all"; else VMS="ns1:dns ftp-archive:ftp artifactorium:web ipcam:web ssh-workstation:ssh"; fi

command -v multipass >/dev/null || { echo "installing multipass (snap)..."; sudo snap install multipass; }
if ! grep -qE 'vmx|svm' /proc/cpuinfo; then
  echo "WARNING: no hardware virtualization (vmx/svm). VMs will be very slow or fail."
  echo "  If this machine is itself a VM, enable nested virtualization; otherwise enable VT-x/AMD-V in the BIOS."
fi

case "${1:-up}" in
  up)
    for e in $VMS; do
      n="${e%%:*}"; role="${e#*:}"
      if multipass info "$n" >/dev/null 2>&1; then echo "== $n exists, skipping"; continue; fi
      echo "== $n ($role)"
      # 1 vCPU / 1.5 GB is close to a small competition VM: problems with CPU/RAM show up here too
      multipass launch "$IMAGE" --name "$n" --cpus 1 --memory 1536M --disk 10G
      multipass transfer --recursive "$KIT" "$n:/home/ubuntu/lockdown"
      multipass exec "$n" -- sudo bash -c "chown -R root:root /home/ubuntu/lockdown && chmod -R go-w /home/ubuntu/lockdown && LAB_OK=1 /home/ubuntu/lockdown/tests/lab-setup.sh $role"
      multipass exec "$n" -- sudo bash -c "cd /home/ubuntu/lockdown && cp lockdown.conf.example lockdown.conf"
      multipass stop "$n"; multipass snapshot "$n" --name clean; multipass start "$n"
    done
    "$0" ips
    echo; echo "Next: tests/scorer.sh in one terminal (mini scoring engine), then work in a VM: multipass shell ns1"
    echo "The VMs use competition hostnames, so the test tools need LAB_OK=1 there, e.g.: sudo LAB_OK=1 tests/selftest.sh";;
  reset)
    for e in $VMS; do n="${e%%:*}"; echo "== reset $n"; multipass stop "$n"; multipass restore "$n.clean" --destructive; multipass start "$n"; done;;
  ips)
    for e in $VMS; do n="${e%%:*}"; echo "$n $(multipass info "$n" --format csv | awk -F, 'NR==2{print $3}')"; done;;
  down)
    for e in $VMS; do multipass delete --purge "${e%%:*}" || true; done;;
  *) echo "usage: $0 [up|reset|ips|down]"; exit 1;;
esac
