#!/usr/bin/env bash
# checks.sh - quick "would the scorer pass?" check of DNS, HTTP, FTP and SSH, like the scoring engine:
# a real answer / real login, not just an open port.  Run it after EVERY change (and from another box too).
#   tests/checks.sh                       # practice VM: checks 127.0.0.1 with lab-setup.sh defaults
#   HOST=10.106.10.53 DNS_NAME=ns1.team6.playtcdc.org tests/checks.sh dns
#   HOST=10.106.10.21 FTP_USER=parks FTP_PASS='...' tests/checks.sh ftp
#   HOST=10.106.10.22 SSH_USER=streep SSH_PASS='...' tests/checks.sh ssh     (needs sshpass for a real login)
#   HOST=10.106.10.80 tests/checks.sh http
HOST="${HOST:-127.0.0.1}"
TESTPW="${TESTPW:-Museum-Test-2026}"
DNS_NAME="${DNS_NAME:-www.museum.test}"
HTTP_URL="${HTTP_URL:-http://$HOST/}"
FTP_USER="${FTP_USER:-parks}"; FTP_PASS="${FTP_PASS:-$TESTPW}"
SSH_USER="${SSH_USER:-streep}"; SSH_PASS="${SSH_PASS:-$TESTPW}"
WHICH="${1:-all}"; RC=0
ok()  { printf "  \e[32mPASS\e[0m %s\n" "$*"; }
no()  { printf "  \e[31mFAIL\e[0m %s\n" "$*"; RC=1; }
skip(){ printf "  \e[33mSKIP\e[0m %s\n" "$*"; }

if [[ $WHICH == all || $WHICH == dns ]]; then
  if ! command -v dig >/dev/null; then skip "dns: install dnsutils"
  else a="$(dig +short +time=3 +tries=1 @"$HOST" "$DNS_NAME" 2>&1)"
       [[ -n "$a" && "$a" != *"timed out"* && "$a" != *"connection refused"* ]] && ok "dns  $DNS_NAME @$HOST -> $(echo $a)" || no "dns  $DNS_NAME @$HOST: ${a:-empty answer}"
       a="$(dig +short +tcp +time=3 +tries=1 @"$HOST" "$DNS_NAME" 2>&1)"
       [[ -n "$a" && "$a" != *"timed out"* && "$a" != *"refused"* ]] && ok "dns  over TCP too" || no "dns  over TCP (53/tcp blocked?): ${a:-empty}"
  fi
fi
if [[ $WHICH == all || $WHICH == http ]]; then
  c="$(curl -sk -o /dev/null -m 5 -w '%{http_code}' "$HTTP_URL")"
  [[ "$c" =~ ^(2|3) ]] && ok "http $HTTP_URL -> $c" || no "http $HTTP_URL -> ${c:-no answer}"
fi
if [[ $WHICH == all || $WHICH == ftp ]]; then
  # --list-only forces a data connection, so passive ports get tested too
  if out="$(curl -s -m 10 --list-only "ftp://$HOST/" --user "$FTP_USER:$FTP_PASS" 2>&1)"; then ok "ftp  login + directory listing as $FTP_USER"
  else no "ftp  as $FTP_USER (curl exit $?): login, chroot or passive ports broken? $out"; fi
fi
if [[ $WHICH == all || $WHICH == ssh ]]; then
  if command -v sshpass >/dev/null; then
    if sshpass -p "$SSH_PASS" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 -o PubkeyAuthentication=no "$SSH_USER@$HOST" true 2>/dev/null
    then ok "ssh  password login as $SSH_USER"; else no "ssh  password login as $SSH_USER"; fi
  else
    b="$(timeout 5 bash -c "exec 3<>/dev/tcp/$HOST/22; head -1 <&3" 2>/dev/null)"
    [[ "$b" == SSH-* ]] && ok "ssh  banner: $b (install sshpass to test a real password login)" || no "ssh  no banner on $HOST:22"
  fi
fi
exit $RC
