#!/usr/bin/env bash
# selftest.sh - prove lockdown.sh works on THIS Ubuntu version before comp day.
# Run on a PRACTICE VM after tests/lab-setup.sh and a snapshot. Never on competition boxes (R24).
#   sudo tests/selftest.sh            # everything except the slow scanners (~3 min)
#   sudo tests/selftest.sh --scanners # also run lynis/rkhunter/chkrootkit through the false-positive filter
# Prints PASS/FAIL per check. Revert the VM snapshot afterwards.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LD="$HERE/lockdown.sh"; T="$HERE/tests"
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
# Lab tools only: they plant backdoors and create FAKE Wazuh/Xen units. On competition boxes that would break
# R14/R15 (impersonating staff tools) and R24 (test outside competition infrastructure). Competition boxes are
# Xen VMs, so "is it a VM" isn't enough: refuse on Xen, on playtcdc.org names, and on competition hostnames.
virt="$(systemd-detect-virt 2>/dev/null || echo none)"
fqdn="$(hostname -f 2>/dev/null) $(grep -hE '^(search|domain)' /etc/resolv.conf 2>/dev/null | tr '\n' ' ')"
if [[ "$virt" == xen || "$fqdn" == *playtcdc* || "$(hostname -s)" =~ ^(ns1|ipcam|ftp-archive|artifactorium|ssh-workstation|jumpbox|ad|mqtt|opnsense)$ && "${LAB_OK:-0}" != 1 ]]; then
  echo "this looks like COMPETITION infrastructure (Xen VM, playtcdc.org name or a competition hostname): refusing (R14/R24)."
  echo "In your own Multipass lab with competition hostnames, run with LAB_OK=1."; exit 1
fi
[[ "$virt" == xen || "$fqdn" == *playtcdc* ]] && { echo "refusing on Xen / playtcdc.org even with LAB_OK=1"; exit 1; }
if [[ "$virt" == none && "${FORCE:-0}" != 1 ]]; then echo "this looks like a REAL machine, not a VM: refusing (it adds users/backdoors and hardens for real). Use tests/lab-up.sh to make VMs."; exit 1; fi
SCAN=false; [[ "${1:-}" == --scanners ]] && SCAN=true
P=0; F=0; FAILS=""
pass() { printf "  \e[32mPASS\e[0m %s\n" "$1"; P=$((P+1)); }
fail() { printf "  \e[31mFAIL\e[0m %s\n" "$1"; F=$((F+1)); FAILS="$FAILS\n  - $1"; }
t()    { local d="$1"; shift; if "$@" >/dev/null 2>&1; then pass "$d"; else fail "$d"; fi; }
sec()  { printf "\n\e[1;36m== %s\e[0m\n" "$*"; }
nocol(){ sed 's/\x1b\[[0-9;]*m//g'; }
lib()  { ( LOCKDOWN_LIB=1; source "$LD"; YES=true; "$@" ); }   # run lockdown.sh functions directly

# keep the user's real state out of the way
[[ -d /root/.lockdown ]] && { rm -rf /root/.lockdown.selftest-bak; mv /root/.lockdown /root/.lockdown.selftest-bak; }
finish() {
  bash "$T/plant.sh" --undo >/dev/null 2>&1
  rm -rf /root/.lockdown; [[ -d /root/.lockdown.selftest-bak ]] && mv /root/.lockdown.selftest-bak /root/.lockdown
  printf "\n\e[1m%d passed, %d failed\e[0m" "$P" "$F"; [[ $F -gt 0 ]] && printf "%b" "$FAILS"; echo
  echo "Revert the VM snapshot now (the hardening steps changed real settings)."
}
trap finish EXIT
chmod 700 "$LD"; chown root:root "$LD" "$HERE"; chmod go-w "$HERE"

sec "0. Environment"
. /etc/os-release; echo "  OS: $PRETTY_NAME   sudo: $(sudo --version 2>/dev/null | head -1)   ls -> $(readlink -f "$(command -v ls)")"
[[ "$VERSION_ID" == 26.04 ]] && pass "running on Ubuntu 26.04 like the competition" || fail "not Ubuntu 26.04 (competition boxes are 26.04): results may differ"
for c in ss sshd ufw iptables crontab getcap dpkg systemctl findmnt flock; do t "tool present: $c" command -v "$c"; done
t "visudo or visudo-rs present" bash -c 'command -v visudo || command -v visudo-rs'
t "bash syntax" bash -n "$LD"

sec "1. Helpers work with this system's coreutils (Rust uutils on 26.04)"
printf "%064d  /a\n%064d  /b\n" 1 2 > /tmp/st.o; printf "%064d  /a\n%064d  /c\n" 9 2 > /tmp/st.n
out="$(lib hashdiff /tmp/st.o /tmp/st.n | tr -s ' ')"
t "hashdiff: changed/new/removed" bash -c "grep -q 'changed: /a' <<<'$out' && grep -q 'new: /c' <<<'$out' && grep -q 'removed: /b' <<<'$out'"
out="$(printf '53/tcp\n53/udp\n22/tcp\n80/tcp\n' | sort -u | sort -t/ -k1,1n -k2,2 | tr '\n' ' ')"
t "port list keeps 53/tcp AND 53/udp (old bug)" bash -c "[[ '$out' == '22/tcp 53/tcp 53/udp 80/tcp ' ]]"
t "pkg_status: /usr/bin/passwd is packaged+unchanged" bash -c "[[ \"\$(LOCKDOWN_LIB=1; source '$LD'; pkg_status /usr/bin/passwd)\" == *unchanged* ]]"
t "stat -c '%a:%U:%G' works" bash -c "[[ \$(stat -c '%a:%U:%G' /etc/passwd) == 644:root:root ]]"
t "date -d @N works (account rollback)" bash -c "[[ \$(date -u -d @86400 +%F) == 1970-01-02 ]]"
t "tac works (rollback order)" bash -c "[[ \$(printf '1\n2\n' | tac | head -1) == 2 ]]"
if systemctl is-active --quiet named 2>/dev/null || systemctl is-active --quiet bind9 2>/dev/null; then
  out="$(lib detect_ports)"; t "detect_ports finds 53/tcp and 53/udp from bind9" bash -c "[[ '$out' == *53/tcp* && '$out' == *53/udp* ]]"
fi

sec "2. Baseline: quiet when nothing changed"
"$LD" --baseline >/dev/null 2>&1
out="$("$LD" --diff 2>&1 | nocol)"; t "--diff right after --baseline says no changes" grep -q "no changes" <<<"$out"
for s in ssh named apache2 vsftpd cron; do systemctl is-active --quiet "$s" 2>/dev/null && systemctl restart "$s"; done; sleep 2
out="$("$LD" --diff 2>&1 | nocol)"
grep -q "no changes" <<<"$out" && pass "restarting services is not reported (no pid noise)" || { fail "service restarts show up as changes"; echo "$out" | head -20; }

sec "3. Baseline catches planted persistence"
bash "$T/plant.sh" >/dev/null 2>&1; sleep 1
D="$("$LD" --diff 2>&1 | nocol)"
while IFS='|' read -r name pat; do t "diff: $name" grep -qE "$pat" <<<"$D"; done <<'EOF'
new user redteam|^\s*\+\s+redteam:x:
UID 0 user toor|toor:x:0:0
www-data got a shell|www-data:.*/bin/bash
sudoers NOPASSWD file|redteam ALL=\(ALL\) NOPASSWD
root authorized_keys|redteam-key
/etc/cron.d file|/etc/cron.d/sysupdate
user crontab|crontab redteam
PAM change + its content|pam_permit
systemd drop-in override|cron.service.d/override.conf
new systemd unit|sysmon.service
motd hook|update-motd.d/99-x
APT hook|apt.conf.d/99x
udev rule|udev/rules.d/99-x.rules
sshd drop-in|sshd_config.d/0-redteam.conf
listener on 31337|:31337
SUID copy of bash|/var/tmp/.sh
capability on python|cap_setuid
root .bashrc changed|/root/.bashrc
EOF
[[ -d /var/www/html ]] && t "diff: webshell" grep -q "x.php" <<<"$D"
t "diff: content of changed critical file is shown" grep -qE '^\s+\+auth sufficient pam_permit' <<<"$D"

sec "4. Audit mode flags them (and changes nothing)"
before="$(sha256sum /etc/passwd /etc/shadow /etc/pam.d/common-auth | sha256sum)"
A="$("$LD" --audit --only users,sudo,ssh,keys,persistence,perms,caps,web 2>&1 | nocol)"
while IFS='|' read -r name pat; do t "audit: $name" grep -qE "$pat" <<<"$A"; done <<'EOF'
extra UID 0|UID 0 account that isn't root: toor
empty password|EMPTY password: toor
service account shell|system account www-data
primary group sudo|franklin has sudo as its PRIMARY group
lxd root-equivalent|members of 'lxd' can become root
sudoers rule for a non-admin|in /etc/sudoers.d/zz giving root to someone who is NOT on the admin list
sshd drop-in that beats ours|0-redteam.conf sorts before 00-lockdown.conf
PAM pam_permit|PAM pam_permit can grant access
drop-in override|drop-in override .*ExecStartPost=/tmp/.x
unknown unit|sysmon.service
motd|motd script not from a package.*99-x
APT hook|APT hook .*99x
udev|udev rule runs a program
user crontab|crontab for redteam
cron.d file|cron file not from any package: /etc/cron.d/sysupdate
unpackaged SUID|unpackaged SUID/SGID: /var/tmp/.sh
SUID on find|SUID on .*find
capability|dangerous capability: .*cap_setuid
dotfile alias|alias sudo=
EOF
[[ -d /var/www/html ]] && t "audit: webshell" grep -q "suspicious: .*x.php" <<<"$A"
t "audit changed nothing" bash -c "[[ \"\$(sha256sum /etc/passwd /etc/shadow /etc/pam.d/common-auth | sha256sum)\" == '$before' ]]"

sec "5. --yes never does the risky things"
"$LD" --yes --only users,keys,persistence,perms,caps >/dev/null 2>&1
t "--yes kept root's authorized_keys" grep -q redteam-key /root/.ssh/authorized_keys
t "--yes kept redteam's crontab"      bash -c 'crontab -l -u redteam | grep -q /tmp/.x'
t "--yes did not lock redteam"        bash -c '[[ $(getent passwd redteam | cut -d: -f7) == /bin/bash ]]'
t "--yes left the SUID file alone"    test -u /var/tmp/.sh
t "--yes left capabilities alone"     bash -c "getcap '$(readlink -f "$(command -v python3)")' | grep -q setuid"

sec "6. Harden, services still pass, rollback restores exactly"
"$LD" --baseline >/dev/null 2>&1          # baseline of the current (planted) state
"$LD" --yes --only sudo,ssh,sysctl,perms > /tmp/st.harden 2>&1
H="$(nocol < /tmp/st.harden)"
t "sysctl file uses the 99-zz name" test -f /etc/sysctl.d/99-zz-lockdown.conf
t "sshd: lockdown drop-in written" test -f /etc/ssh/sshd_config.d/00-lockdown.conf
t "sshd: reports that 0-redteam.conf still wins" grep -q "another config file wins" <<<"$H"
t "--yes leaves a non-admin's sudoers rule for a human to remove" grep -q '^redteam ALL' /etc/sudoers.d/zz
t "blackteam NOPASSWD kept (R8)" grep -q '^blackteam ALL' /etc/sudoers.d/90-blackteam
bash "$T/checks.sh" >/tmp/st.checks 2>&1 && pass "scored-service checks pass after hardening" || { fail "scored-service checks after hardening"; cat /tmp/st.checks; }
"$LD" --yes --rollback >/tmp/st.rb 2>&1
out="$("$LD" --diff 2>&1 | nocol)"
grep -q "no changes" <<<"$out" && pass "after --rollback the box equals the pre-harden baseline" || { fail "rollback left differences"; echo "$out" | head -25; }

sec "7. Account rollback doesn't wipe later changes"
( LOCKDOWN_LIB=1; source "$LD"; YES=true; mod_backup >/dev/null 2>&1; lock_user redteam >/dev/null 2>&1 )
t "redteam locked (nologin + expired)" bash -c '[[ $(getent passwd redteam | cut -d: -f7) == */nologin && $(getent shadow redteam | cut -d: -f8) == 1 ]]'
useradd -m legit2 && usermod -aG sudo legit2
"$LD" --yes --rollback >/dev/null 2>&1
t "redteam back to /bin/bash, not expired" bash -c '[[ $(getent passwd redteam | cut -d: -f7) == /bin/bash && -z $(getent shadow redteam | cut -d: -f8) ]]'
t "user added after the run survived (passwd, group, sudo)" bash -c 'getent passwd legit2 && getent group legit2 && id -nG legit2 | grep -qw sudo'
userdel -r legit2 >/dev/null 2>&1

sec "8. Undo, then harden again, then undo again (menu flow)"
( LOCKDOWN_LIB=1; source "$LD"; YES=true
  mod_backup >/dev/null; mod_sysctl >/dev/null 2>&1; do_rollback >/dev/null 2>&1
  new_run; mod_backup >/dev/null; mod_sysctl >/dev/null 2>&1
  [[ "$(last_undoable)" == "$BK" ]] && echo SAME > /tmp/st.menu || echo "DIFF $(last_undoable) vs $BK" > /tmp/st.menu
  do_rollback >/dev/null 2>&1 )
t "second change went into a new, undoable run" grep -q SAME /tmp/st.menu
t "second undo removed the sysctl file" test ! -e /etc/sysctl.d/99-zz-lockdown.conf

sec "9. Firewall auto-reverts if you don't type KEEP"
echo "  (don't type anything for ~8 seconds)"
was="$(ufw status | head -1)"
( LOCKDOWN_LIB=1; source "$LD"; YES=true; FW_ROLLBACK_SECS=5; ALLOWED_PORTS="22/tcp 53/tcp 53/udp 21/tcp 80/tcp 40000:50000/tcp"
  mod_backup >/dev/null; mod_firewall </dev/null >/dev/null 2>&1 )
t "firewall was applied" bash -c 'ufw status | grep -q "Status: active" || iptables -S INPUT | grep -q LOCKDOWN_IN'
sleep 8
if [[ "$was" == *inactive* ]]; then t "firewall reverted to inactive after the timer" bash -c 'ufw status | grep -q "Status: inactive"'
else t "firewall rules reverted after the timer" bash -c '! ufw status | grep -q "40000:50000"'; fi

sec "10. Scanner false-positive filter"
printf 'Warning: Hidden directory found: /etc/.java\nWarning: Suspicious file types found in /dev:\n         /dev/shm/evil.sh: ELF 64-bit\n' > /tmp/st.rk
out="$(LOCKDOWN_LIB=1; source "$LD"; scan_findings rkhunter /tmp/st.rk | while read -r l; do [[ "$l" =~ $SCAN_IGNORE_RE ]] || echo "$l"; done)"
t "stock /etc/.java hidden, /dev/shm finding kept and joined into one line" bash -c "[[ \$(wc -l <<<'$out') -eq 1 && '$out' == *'/dev/shm/evil.sh'* ]]"
if $SCAN; then
  out="$( (LOCKDOWN_LIB=1; source "$LD"; YES=false; AUDIT=true; mod_scanners) 2>&1 | nocol )"
  echo "$out" | grep -E 'new, |likely false|\[XX\]' | sed 's/^/     /'
  t "scanners ran and summarised" grep -q "new, .* known on this box" <<<"$out"
else echo "  (skipped real scanner runs; use --scanners)"; fi

sec "11. Roles vs the packet (who can become root)"
ROLE_ENV='ADMIN_USERS="washington kennedy teddy lincoln ross"; KEEP_USERS="washington kennedy teddy lincoln ross streep franklin parks armstrong hamilton mlk tubman manziel deniro bush"'
getent group devs >/dev/null || groupadd devs
usermod -aG sudo streep; echo 'parks ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/st-helpdesk; chmod 440 /etc/sudoers.d/st-helpdesk
usermod -aG devs bush; echo '%devs ALL=(ALL) ALL' > /etc/sudoers.d/st-devs; chmod 440 /etc/sudoers.d/st-devs
gpasswd -d ross sudo >/dev/null 2>&1
R="$( (LOCKDOWN_LIB=1; source "$LD"; eval "$ROLE_ENV"; role_check) 2>&1 )"
t "employee added to sudo group is flagged"      grep -q "streep is an EMPLOYEE" <<<"$R"
t "employee given a direct sudoers rule"          grep -q "parks is an EMPLOYEE.*NOPASSWD" <<<"$R"
t "employee given sudo through a %group rule"     grep -q "bush is an EMPLOYEE.*via %devs" <<<"$R"
t "admin who lost sudo is flagged"                grep -q "admin ross has NO sudo" <<<"$R"
t "blackteam (protected) is not flagged"          bash -c "! grep -q blackteam <<<'$R'"
gpasswd -d streep sudo >/dev/null; gpasswd -d bush devs >/dev/null; usermod -aG sudo ross; rm -f /etc/sudoers.d/st-helpdesk /etc/sudoers.d/st-devs

sec "12. Extra watched folders (repos): new, deleted and stealthily edited files"
mkdir -p /srv/st-repo && for i in 1 2 3; do echo "v$i" > /srv/st-repo/a$i.txt; done
( LOCKDOWN_LIB=1; source "$LD"; hash_tree st /srv/st-repo > /tmp/st.h1 )
touch -r /srv/st-repo/a1.txt /tmp/st.ref; echo pwn >> /srv/st-repo/a1.txt; touch -r /tmp/st.ref /srv/st-repo/a1.txt   # edit + fake mtime
echo x > /srv/st-repo/new.php; rm /srv/st-repo/a2.txt
out="$( (LOCKDOWN_LIB=1; source "$LD"; hash_tree st /srv/st-repo > /tmp/st.h2; hashdiff /tmp/st.h1 /tmp/st.h2) )"
t "new file in repo"                       grep -q "new: .*new.php" <<<"$out"
t "deleted file in repo"                   grep -q "removed: .*a2.txt" <<<"$out"
t "edited file with faked timestamp"       grep -q "changed: .*a1.txt" <<<"$out"
rm -rf /srv/st-repo

sec "13. Service guard: a module that kills a scored service gets undone"
pkill -f 'bind\(\("0.0.0.0",18080' 2>/dev/null
nohup python3 -c 'import socket,time;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(("0.0.0.0",18080));s.listen();time.sleep(9999)' >/dev/null 2>&1 & sleep 1
( LOCKDOWN_LIB=1; source "$LD"; YES=true; SCORED_PORTS="18080/tcp"
  mod_backup >/dev/null; guard_start >/dev/null; mod_sysctl >/dev/null 2>&1
  pkill -f 'bind\(\("0.0.0.0",18080'; guard_check sysctl > /tmp/st.guard 2>&1 )
t "guard noticed the scored port went down"   grep -q "SERVICE GUARD" /tmp/st.guard
t "guard undid the run automatically (--yes)" test ! -e /etc/sysctl.d/99-zz-lockdown.conf

sec "14. Firewall refuses to block a scored port; reverse-shell check spares servers"
nohup python3 -c 'import socket,time;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(("0.0.0.0",18080));s.listen();c,_=s.accept();time.sleep(9999)' >/dev/null 2>&1 & sleep 1
out="$( (LOCKDOWN_LIB=1; source "$LD"; YES=true; SCORED_PORTS="18080/tcp"; ALLOWED_PORTS="22/tcp"; mod_backup >/dev/null; mod_firewall) 2>&1 | nocol )"
t "firewall not applied when a scored port is missing" grep -q "firewall not applied" <<<"$out"
nohup python3 -c 'import socket,time;c=socket.create_connection(("127.0.0.1",18080));time.sleep(9999)' >/dev/null 2>&1 & sleep 1
out="$("$LD" --audit --only persistence 2>&1 | nocol | sed -n '/OUTBOUND connections/,/processes running from/p')"
t "outbound interpreter connection flagged"            grep -qE '\[XX\].*:18080 +users' <<<"$out"
t "server side of the same connection NOT flagged"     bash -c "! grep -qE '\[XX\].*127.0.0.1:18080 +127' <<<'$out'"
pkill -f 18080 2>/dev/null

sec "15. Watch cost on this box"
s=$SECONDS; ( LOCKDOWN_LIB=1; source "$LD"; snapshot /tmp/st.snap1 full ) >/dev/null 2>&1; full=$((SECONDS-s))
s=$SECONDS; ( LOCKDOWN_LIB=1; source "$LD"; snapshot /tmp/st.snap2 light /tmp/st.snap1 ) >/dev/null 2>&1; light=$((SECONDS-s))
echo "  full check: ${full}s   light check: ${light}s   (watch runs light checks, full every HEAVY_EVERY, at nice 19)"
t "a light watch check takes under 15 s" test "$light" -lt 15

sec "16. Packet v2: sudoers, crontab undo, root rotation, jumpbox, containers"
printf 'washington ALL=(ALL) NOPASSWD:ALL\nparks ALL=(ALL) ALL\nUser_Alias STAFF = blackteam, whiteteam\nSTAFF ALL=(ALL) NOPASSWD: ALL\n' > /etc/sudoers.d/st-mix; chmod 440 /etc/sudoers.d/st-mix
( LOCKDOWN_LIB=1; source "$LD"; YES=false; ADMIN_USERS="washington kennedy teddy lincoln ross"
  mod_backup >/dev/null; mod_sudo </dev/null >/dev/null 2>&1 ) # no tty -> asks say no: nothing may change
t "sudo: nothing changes without a yes" grep -q '^washington ALL=(ALL) NOPASSWD:ALL' /etc/sudoers.d/st-mix
( LOCKDOWN_LIB=1; source "$LD"; YES=true; ADMIN_USERS="washington kennedy teddy lincoln ross"
  mod_backup >/dev/null; mod_sudo >/dev/null 2>&1 )
t "sudo: admin keeps sudo, loses NOPASSWD"        grep -qx 'washington ALL=(ALL) ALL' /etc/sudoers.d/st-mix
t "sudo: --yes does NOT remove employee rules"    grep -qx 'parks ALL=(ALL) ALL' /etc/sudoers.d/st-mix
t "sudo: staff alias rule untouched"              grep -qx 'STAFF ALL=(ALL) NOPASSWD: ALL' /etc/sudoers.d/st-mix
t "sudo: result passes visudo"                    bash -c '(command -v visudo || command -v visudo-rs) >/dev/null && $(command -v visudo || command -v visudo-rs) -c'
rm -f /etc/sudoers.d/st-mix
echo '*/5 * * * * /bin/true # st-cron' | crontab -u intern - 2>/dev/null || { useradd -m st-cronuser; echo '*/5 * * * * /bin/true # st-cron' | crontab -u st-cronuser -; }
CU="$(id intern >/dev/null 2>&1 && echo intern || echo st-cronuser)"
( LOCKDOWN_LIB=1; source "$LD"; YES=true
  mod_backup >/dev/null; mkdir -p "$BK/crontabs"; crontab -l -u "$CU" > "$BK/crontabs/$CU"; echo "crontab:$CU" >> "$BK/manifest"; crontab -r -u "$CU" )
t "crontab removed" bash -c "! crontab -l -u $CU 2>/dev/null | grep -q st-cron"
"$LD" --yes --rollback >/dev/null 2>&1
t "crontab restored by rollback (any cron implementation)" bash -c "crontab -l -u $CU | grep -q st-cron"
crontab -r -u "$CU" 2>/dev/null; id st-cronuser >/dev/null 2>&1 && userdel -r st-cronuser 2>/dev/null
out="$( (LOCKDOWN_LIB=1; source "$LD"; YES=true; prompt(){ [[ "$1" == Rotate* ]] && echo root || echo "$2"; }; mod_backup >/dev/null; mod_users) 2>&1 | nocol)"
t "root rotation needs a typed confirmation (--yes skips it)" grep -q "never done automatically: root's password" <<<"$out"
nohup python3 -c 'import socket,time;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(("0.0.0.0",18081));s.listen();time.sleep(9999)' >/dev/null 2>&1 &
sleep 1; nohup python3 -c 'import socket,time;c=socket.create_connection(("127.0.0.1",18081));time.sleep(9999)' >/dev/null 2>&1 & sleep 1
out="$( (LOCKDOWN_LIB=1; source "$LD"; YES=false; IS_JUMPBOX=yes; mod_persistence </dev/null) 2>&1 | nocol)"
t "jumpbox profile: outbound shells are report-only (R16)" grep -q "jumpbox: may be your own purple-team tooling" <<<"$out"
pkill -f 18081 2>/dev/null
mkdir -p /var/lib/docker/overlay2/st/diff/usr/bin && cp /bin/true /var/lib/docker/overlay2/st/diff/usr/bin/st-suid && chmod 4755 /var/lib/docker/overlay2/st/diff/usr/bin/st-suid
out="$( (LOCKDOWN_LIB=1; source "$LD"; suid_scan) )"
t "SUID scan skips container image layers" bash -c "! grep -q st-suid <<<'$out'"
rm -rf /var/lib/docker/overlay2/st; rmdir /var/lib/docker/overlay2 /var/lib/docker 2>/dev/null
