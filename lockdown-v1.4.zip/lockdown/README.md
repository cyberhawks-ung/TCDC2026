# lockdown.sh

Interactive hardening and persistence hunting for Ubuntu/Debian boxes in blue-team competitions.
Built and tested for **Ubuntu Server 26.04** (sudo-rs, Rust coreutils), also runs on 24.04 / Debian 12.
It's one bash file with no dependencies. It shows every change before making it, backs up every file it touches, and can undo everything with `--rollback`.

## Comp-day playbook (per Ubuntu box, ~15 minutes)

Scoring is 80% uptime, checked every 30 s. Every step below keeps the scored service up or tells you at once.

| When | Do | Time | Breaks a service? |
|---|---|---|---|
| T+0 | Open a **second root session** and keep it open. Copy the folder over, `cp lockdown.conf.example lockdown.conf`, `chown -R root:root . && chmod -R go-w .` | 1 min | no |
| T+1 | `ss -tulpn` and check that this box's `SCORED_PORTS`/`ALLOWED_PORTS` in lockdown.conf match reality | 1 min | no |
| T+2 | `sudo ./lockdown.sh --audit` and read it (roles vs packet, backdoors, keys) | 1-2 min | no |
| T+4 | `sudo ./lockdown.sh` menu: **users, sudo, keys, persistence** (harden) | 3-5 min | guarded |
| T+9 | **ssh** then **firewall** (type KEEP only after a NEW ssh login and `tests/checks.sh` from the jumpbox pass) | 2-3 min | guarded, auto-revert |
| T+12 | **services, sysctl, perms, caps, web, db, other** | 2 min | guarded |
| T+14 | `--baseline` (fingerprint on paper or a screenshot; copy the .tgz to the **jumpbox**, never your laptop: R23), then leave `--watch 120` running | 1 min | no |
| later, calm moment | **scanners** (minutes of low-priority CPU/disk) | 3-15 min | no |

If you change a password: **update https://dash.playtcdc.org/team/passwords right away.**

### What keeps services up
- **Service guard:** before hardening it records which ports are listening (or `SCORED_PORTS`), and re-checks them
  after every module. If one stopped, it says which module did it and offers to undo the whole run on the spot
  (`--yes` undoes automatically). `SERVICE_CHECK_CMD` adds a real functional check (e.g. `tests/checks.sh dns`).
- A unit or process **serving a listening port** is never stopped on a plain `y`: you must type its name.
  The reverse-shell check ignores servers' inbound connections (the scorer talking to a python/php app).
- The **firewall** lists every listening port it would block, refuses to block `SCORED_PORTS` unless you type
  BLOCK, and reverts after 90 s unless you type KEEP.
- Service restarts it does itself (sshd, apache, vsftpd) are config-tested first and restored if the service
  doesn't come back. Accounts that run a listening service never get their shell changed.

### What it costs
- `--watch`: runs at nice 19 / idle I/O. Files are re-hashed only when their inode/size/ctime changed (a faked
  mtime doesn't hide an edit), so a multi-GB repo costs a directory walk, not a re-read. SUID/capability scans
  run every `HEAVY_EVERY` (5) checks. Each check prints how long it took.
- Scanners are the only heavy part: run them once early, at low priority. ClamAV is not installed unless
  `INSTALL_CLAMAV=yes` (~1 GB RAM and a resident updater).

### What --watch and --diff track
Accounts, groups, password changes, **who can become root and how** (sudo group incl. primary group, sudoers rules
incl. %groups and User_Alias, docker/lxd/disk, UID 0), sudoers, authorized_keys, cron/at, critical config files
(with the changed lines), listening ports, SUID files, capabilities, enabled units, dotfiles, kernel modules,
web roots, **`WATCH_DIRS`** (repos, FTP roots), the rest of /etc. Plus two absolute checks every time:
- **Roles vs the packet:** an employee who can become root, a user not in the packet who can log in or become
  root, a packet admin who lost sudo, a packet user that's missing (`ADMIN_USERS`/`KEEP_USERS` in lockdown.conf).
- **Scored ports down:** any `SCORED_PORTS` with nothing listening.

## How dangerous is it to run during the competition?

Short version: **with lockdown.conf filled in for the box, run interactively, the script itself is low risk;
the real risks are a wrong port list, an unknown service account, and password changes not put in the dashboard.**
The guard only knows whether a port is *listening*, not whether a *login* works, so the three "not caught by the
guard" rows below are the ones to respect. Verified in the lab: answering **y to every prompt** on all modules kept
DNS/HTTP/FTP/SSH at 100% uptime and left staff tooling, admins and packet users untouched.

| Risk | What breaks | Caught/limited by | What you must do |
|---|---|---|---|
| Firewall port list wrong (scored service on another port, FTP passive range missing) | scored service unreachable from outside | preview of what gets blocked; refuses to block SCORED_PORTS; vsftpd passive check; auto-revert after 90 s (worst case ~3 lost ticks) | check `ss -tulpn` first; test from the jumpbox with `tests/checks.sh` BEFORE typing KEEP |
| Locking / nologin on an **OS or service account** from Discord | FTP (vsftpd needs a valid shell) and SSH logins fail | packet users and SERVICE_USERS are never locked or given nologin | put every OS/service user from Discord that isn't in the packet into SERVICE_USERS |
| Password rotated, dashboard not updated | every check using that user fails (packet "Password Changes": the checker is NOT updated automatically, and you aren't told which user it uses) | loud reminder with the URL | update https://dash.playtcdc.org/team/passwords immediately for every user you changed (same after a rollback or store revert). root can be rotated too (typed confirmation) |
| sshd settings (PermitRootLogin no, MaxAuthTries 4, no forwarding) | a check/staff login that uses root or forwarding | `sshd -t`, effective-value check; **not** the guard (port stays open) | ask Black Team if anyone uses root SSH; set SERVICE_CHECK_CMD to a real SSH login check |
| Disabling anonymous FTP | an anonymous FTP check | **not** the guard (port stays open) | only if you know the check uses an account |
| Stopping a custom unit / killing a process | the scored app | typed unit name if it serves a port; servers' inbound connections never offered for kill; guard + instant undo | read ExecStart before typing |
| Staff tooling (Wazuh, auditd, Xen tools, cloud-init, blackteam/whiteteam) | R7/R15 violation, staff can't manage the box | PROTECTED_RE / PROTECTED_USERS on every action; their listening ports kept open; their sudo rules (also via aliases) kept; root's keys need `root` typed | ask about the cloud image's default user (e.g. `ubuntu`) and add it if staff use it |
| Scanners | CPU/disk load slows services on a 1-vCPU box | nice 19 / idle I/O, timeouts, no ClamAV by default | run once early, not mid-incident |
| Rollback | brings back old passwords / old files | per-item restore, preview, select mode | update dashboard after restoring accounts |
| Reboot during the 90 s firewall window | ufw stays enabled (timer is lost) | allow list still applies | don't reboot before KEEP/revert |
| Ubuntu 26.04 differences (Rust coreutils, sudo-rs) | a command behaving differently | removed risky constructs; self-test checks the helpers | **run `tests/selftest.sh` on a 26.04 VM before comp day** |
| Red team edits lockdown.sh on a compromised box | the tool lies or does damage | none inside the box | keep the master copy on the jumpbox and the public repo (R20); compare `sha256sum lockdown.sh` with the repo before each run. The jumpbox is in scope now (R6), so check it too |
| Running it on the **jumpbox** (in scope since packet v2, R6) | your own purple-team tools (R16), the browser/RDP clients on 3001-3008, SSH tunnels | jumpbox profile (`IS_JUMPBOX=yes`): outbound shells report-only, 3001-3008 allowed, forwarding kept, Docker layers skipped by SUID/caps scans | set the jumpbox's real hostname in the config; add your C2/listener ports to its ALLOWED_PORTS |
| Copying backups/baselines to your laptop | **R23** (no artifacts off competition infrastructure; only screenshots and passwords) | the script only suggests the jumpbox | keep copies on the jumpbox; fingerprints on paper or screenshots |
| Running the lab tools on a competition box | plants backdoors and fake Wazuh/Xen units: R14/R15/R24 | lab tools refuse on Xen, playtcdc.org names and competition hostnames | only use them in your own Multipass lab (`LAB_OK=1`) |
| Hands-off periods (R10) | rules violation | watch prints a reminder | stop changing things; ask Black Team before leaving --watch running |

## Testing on one Ubuntu machine (do this before comp day)

**Never run the tests on your real install**: they create users, plant backdoors and harden for real.
`lab-setup.sh`, `plant.sh`, `selftest.sh` and `chaos.sh` refuse to run outside a VM (`systemd-detect-virt`).
Your machine is the host; the boxes are VMs on it, and the host plays the scoring engine from outside, so the
firewall is tested exactly as the real scorer sees it.

1. **Check virtualization**: `grep -cE 'vmx|svm' /proc/cpuinfo` must be > 0 (enable VT-x/AMD-V in BIOS, or nested
   virtualization if your Ubuntu is itself a VM).
2. **Build the lab** (installs Multipass, ~6 GB RAM for 5 VMs; `ONE=1` for a single VM with all services):
   `tests/lab-up.sh` creates ns1, ftp-archive, artifactorium, ipcam, ssh-workstation on Ubuntu 26.04 with the
   same hostnames (so lockdown.conf picks the right ports), installs DNS/FTP/HTTP/SSH, packet users, a Discord-style
   service user, and *simulated staff tooling* (Wazuh/Xen units, staff cron, staff SUID, blackteam sudo); then snapshots.
3. **Start the mini scorer on the host** in its own terminal: `tests/scorer.sh` (checks every 30 s like the real
   one, real logins, logs every DOWN tick with a timestamp, prints uptime % on Ctrl-C). `sudo apt install sshpass dnsutils`.
4. **Rehearse exactly like comp day** in each VM (`multipass shell ns1`, `cd /home/ubuntu/lockdown`): follow the
   playbook above, time yourself, and watch the scorer. Any DOWN tick = find the step in the scorer log.
5. **Self-test**: `sudo tests/selftest.sh` (~95 automatic checks) and `sudo tests/selftest.sh --scanners`.
6. **Worst-case operator**: `sudo tests/chaos.sh` answers y to everything; the scorer must stay 100% and the
   staff-tooling checks must pass.
7. **Reboot test**: `sudo tests/chaos.sh --reboot`, then after boot `sudo tests/chaos.sh --after-reboot`
   (sshd, firewall and services must come back on their own).
8. **Red team drill**: `sudo tests/plant.sh` while `--watch 30` runs; every backdoor should alert.
9. **Reset** between rounds: `tests/lab-up.sh reset` (seconds). `tests/lab-up.sh down` deletes everything.

## Quick start (per Ubuntu box)

```bash
# keep a SECOND root shell open the whole time
cp lockdown.conf.example lockdown.conf      # ports are picked by hostname; check them with: ss -tulpn
chown -R root:root . && chmod go-w . lockdown.conf   # it refuses a config others can edit
sudo ./lockdown.sh                          # text menu: explains each module, its risk and what it changes
sudo ./lockdown.sh --audit                  # 1. look first. Changes nothing
sudo ./lockdown.sh --all                    # 2. harden. Answer y/N for each change
tests/checks.sh   (with HOST/creds set)     # 2b. scored services still answer?
sudo ./lockdown.sh --baseline               # 3. snapshot the hardened state; fingerprint on paper/screenshot, .tgz copy on the jumpbox (R23)
sudo ./lockdown.sh --watch 120              # 4. leave running. Prints anything that changes
```

Run single modules with `--only ssh,firewall`. List them with `--list`.

## Menu

Running with no options opens a numbered menu with every module, colored by risk (READ-ONLY, LOW, MEDIUM, HIGH). Pick a number to see what it does and what it would change, then choose **a**udit (look only), **h**arden (asks before every change) or **b**ack. Letters cover the rest: A audit all, H harden all, D diff, W watch, U undo last run, L list runs, Q quit.

## Undo

Undo is per item: accounts get back their own shell/expiry/password (other users added since are kept),
services go back to their exact previous state (enabled/disabled, running/stopped, masked), and file restores
are atomic. Before restoring, you see each item (and how many lines a file restore would overwrite) and can
answer **a**ll, **s**elect one by one, or nothing. A run is marked undone only if every item succeeded.


- `--rollback` (or **U** in the menu) undoes the newest run that hasn't been undone yet, in reverse order: files, permissions, SUID bits, disabled services, kernel settings, firewall rules. It reloads sshd, ufw and apache as needed. Run it again to undo the run before that.
- `--runs` lists only runs that changed something, and marks which are undone and which is next.
- `--rollback run-YYYYMMDD-HHMMSS` undoes a specific run. It warns you if newer runs are still active, and asks before re-running an undo.
- Audit runs, and runs where you answered no to everything, record nothing and aren't listed.
- **Not reversible:** killed processes and dropped MySQL users or test databases. Undoing a password rotation brings the old passwords back, so update the dashboard.

## Modules

| Module | What it does |
|---|---|
| users | Finds extra UID 0 accounts, empty passwords, and logins not on your keep list. Can rotate passwords (saved to a root-only file). |
| sudo | Removes non-admins from sudo groups and comments out NOPASSWD rules. Each change is checked with `visudo -c`. |
| ssh | Writes `sshd_config.d/00-lockdown.conf`. `sshd -t` must pass before reload, and the file is restored if it fails. |
| keys | Lists every authorized_keys file and fingerprint and flags forced-command keys. Quarantines files you pick. |
| firewall | ufw (or iptables): deny inbound except your ports. **Auto-reverts in 90s unless you type KEEP.** |
| persistence | Checks cron, at, systemd units not owned by any package, ld.so.preload, rc.local, PAM, and backdoored shell rc files. Runs `dpkg --verify` on key binaries, looks for reverse-shell connections, and finds processes running from /tmp or deleted binaries. |
| services | Stops risky legacy services (telnet, rsh, tftp, avahi, cups, rpcbind…) if you confirm. Leaves everything else alone. |
| sysctl | Applies safe kernel and network hardening. Leaves ip_forward unchanged. |
| perms | Fixes perms on shadow, passwd and sudoers. Flags world-writable files, unpackaged SUID binaries (all local filesystems), and SUID GTFOBins. |
| caps | Flags dangerous file capabilities (cap_setuid on python = root backdoor) and removes the ones you approve. |
| web | Pattern-matches webshells, checks for scripts in upload dirs and recently changed web files. Hides the Apache version, flags directory listing and risky php.ini settings. |
| db | MySQL: anonymous users, `%` hosts, test db, over-privileged users. Postgres: `trust` auth and superusers. |
| other | vsftpd anonymous/chroot, Postfix open relay, BIND zone transfer and recursion, Samba guest shares. |
| scanners | Runs Lynis, rkhunter, chkrootkit, ClamAV and maldet. Hides stock-Ubuntu false positives, labels every file a finding names with dpkg's verdict, and lets you mark checked findings as known so later runs show only new ones. Skips ClamAV on low RAM. |
| baseline | Saves a state snapshot (+ fingerprint and off-box .tgz) for `--diff` and `--watch`, and runs `rkhunter --propupd`. |

## Safety rails

- **Never touched:** `root` keys and crontab are reviewed, but `blackteam` and `whiteteam` are never locked, de-sudo'd, re-keyed or re-passworded. Wazuh, auditd, cloud-init and Xen guest tools are never stopped or quarantined. Edit `PROTECTED_USERS` / `PROTECTED_RE` if staff announce others.
- **Nothing is deleted.** Users are locked, not removed. Files are moved to `/root/.lockdown/run-*/files`.
- `--rollback` restores every file from the last run, including SUID bits.
- A full `/etc` tarball is saved at the start of each run.
- **Password changes:** update the scoring dashboard immediately, or the service checks fail.

## Comp-day notes

- Run `--audit` first on every box and read the output before changing anything.
- Lock users and remove keys only when you know they're not used by the scorer.
- Firewall rules must follow your event's network rules (TCDC R18: inbound blocks apply to all sources, no default-deny outbound). The script only adds inbound rules.
- Test on a VM before the event.

## False positives (scanners and the persistence hunt)

Stock Ubuntu always trips a few alarms (rkhunter: `/etc/.java`, "user sshd added"; chkrootkit: `.build-id`, `.jinfo`,
RTNETLINK noise; image files like `60-unminimize` that no package owns). lockdown.sh handles them in three layers:

1. **Built-in ignore list** (`SCAN_IGNORE_RE`): known stock noise is counted, not shown. Extend it in lockdown.conf.
2. **dpkg verdict on every file a finding names**: `[packaged (...), unchanged]` = the distro vouches for it,
   almost always a false positive. `[not from a package]` or `[MODIFIED]` = look at it.
3. **Per-box known list**: after you've checked a first run, answer y to "mark as known". Scanner findings go to
   `/root/.lockdown/scan-known.txt`, unpackaged files to `known-files.txt` **with their hash**, so if anyone edits a
   file later it is flagged again. `--yes` never marks anything known. Delete a line to see it again.

Best practice: run the scanners once on a **fresh practice VM** to learn what's normal for 26.04, then on comp day
run them right after your first audit, mark what you've checked as known, and rerun later to see only what's new.

## Testing before comp day (R24: test outside competition infrastructure)

Use a throwaway **VM** (not a Docker container: no systemd, no real firewall) with Ubuntu Server 26.04, and keep a
clean snapshot so you can reset it to a fresh image in seconds:

| Tool | Create | Save clean state | Reset to clean |
|---|---|---|---|
| Multipass | `multipass launch 26.04 -n lab -c 2 -m 2G -d 15G` (`multipass find` lists images) | `multipass stop lab; multipass snapshot lab -n clean` | `multipass stop lab; multipass restore lab.clean --destructive` |
| LXD | `lxc launch ubuntu:26.04 lab --vm` | `lxc snapshot lab clean` | `lxc restore lab clean` |
| VirtualBox / VMware | install from the 26.04 Server ISO | `VBoxManage snapshot lab take clean` (or the Snapshot menu) | power off, `VBoxManage snapshot lab restore clean` |

Then:

```bash
sudo tests/lab-setup.sh            # packet users, blackteam/whiteteam, bind9 + vsftpd + apache + ssh
# take snapshot "lab-clean" now
sudo tests/selftest.sh             # ~80 PASS/FAIL checks: baseline, 22 planted backdoors, audit, --yes safety,
                                   # harden + service checks + rollback, account rollback, menu undo, firewall auto-revert
sudo tests/selftest.sh --scanners  # also the real scanners through the false-positive filter
# revert to "lab-clean" before the next round
```

`tests/plant.sh` plants the backdoors by itself (practice), `tests/checks.sh` tests DNS/HTTP/FTP/SSH like the scorer
(a real answer or login, not just an open port). Keep the lab VM on NAT/host-only: the planted backdoors are real.

## Resetting during the competition

You can't reimage boxes yourself. The store (https://dash.playtcdc.org/team/store) sells **snapshots and reverts** with a fixed budget (no way to earn more):
harden, confirm with `tests/checks.sh` that every scored service passes, then buy a snapshot of that known-good state.
For individual changes use `--rollback` (free). Reverting a box also brings back whatever passwords it had then:
update the password dashboard.

## Rules reminders (TCDC SMC F26 packet, v2)

- R6: 9 boxes are in scope **including the jumpbox**. By default nobody outside your team can reach it; any
  firewall rules you add there must follow R18.
- R16: attack infrastructure **may** be hosted on your jumpbox (changed in packet v2). Use the jumpbox profile.
- R18: inbound blocks must apply to all sources (this script's default-deny inbound does); never default-deny outbound.
- R20: this tool (tests/ included) must be in a **public repository**, and the link submitted via the Tool Links form before you use it.
- R21: the packet says NO AI USAGE. If Black Team cleared AI help for *building* tools, get that in writing on Discord.
- R23: no data or artifacts off competition infrastructure, except screenshots and passwords. Keep backups,
  baselines and scan output on the boxes / jumpbox.
- R10: change nothing during hands-off periods (lunch 12:00-13:00 CT). `--watch` only reads, but ask Black Team before leaving it running.
