# Read-only Windows host inventory: run locally on your authorized Windows host.
# Do not publish output containing host-specific or personal data.
# Does not change protected users, audit/logging services, or host configuration.
$ErrorActionPreference = 'Continue'
$result = [ordered]@{
    CheckedAt = (Get-Date).ToUniversalTime().ToString('o')
    Hostname = $env:COMPUTERNAME
    Users = @(Get-LocalUser | Select-Object Name,Enabled,SID)
    Administrators = @(Get-LocalGroupMember -Group 'Administrators' | Select-Object Name,ObjectClass,PrincipalSource)
    ScheduledTasks = @(Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft\*' } | Select-Object TaskName,TaskPath,State)
    StartupRegistryPaths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    )
    Services = @(Get-Service | Select-Object Name,DisplayName,StartType,Status)
}
$result | ConvertTo-Json -Depth 6
