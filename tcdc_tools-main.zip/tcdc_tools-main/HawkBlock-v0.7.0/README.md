# HawkBlock

CyberHawks' defense dashboard for **TCDC SMC 2026 — Team 6**.

HawkBlock helps the team check scored services, review host security summaries, investigate outages, and track injects. The portal is local, and nothing runs on a schedule. All checks must be started manually.

## Install and launch

Requires Python 3.10+ and OpenSSH (`ssh`) for remote checks.

```bash
cd ~/tcdc/HawkBlock-v0.7.0
source ~/tcdc/.venv/bin/activate
python3 -m pip install -e .
hawkblock dashboard
```

Open **http://127.0.0.1:8765** in a browser on the machine running HawkBlock. Stop the portal with **Ctrl+C**.

Team 6's IPs are built in. You do **not** need to run `setup` again. The portal does not contact any hosts when you open it.

## What you can do in the portal

| Tab | What it does |
| --- | --- |
| **HawkEye** | Manually check the seven scored network services; see failures and service-specific guides |
| **Remote Actions** | Choose a host or all eight, run read-only SSH checks, and compare summarized findings with an in-memory baseline |
| **Team Hosts** | View all eight authorized Team 6 machines and their IP addresses |
| **HawkLock / HawkStalker** | Check the **local computer running HawkBlock**, and save/compare its local baseline |
| **HawkRescue** | Show service troubleshooting playbooks without restarting anything |
| **Inject Board** | Keep track of inject owners and progress; submission still happens on TCDC's official dashboard |

Remote Actions collects only **summary information**, such as counts of accounts, privileged group members, startup entries, scheduled tasks, common file permissions, and likely service states. It does **not** download files, retrieve password or SSH-key contents, run arbitrary commands, install agents, change settings, or restart services.

Remote baselines exist only in memory while the dashboard is open. A changed count is a **lead for investigation**, not proof of compromise.

## Remote Actions setup

Remote auditing requires **authorized SSH access** from the computer running HawkBlock. HawkBlock only sends predefined read-only collectors to the eight Team 6 host IPs. It uses **SSH keys or an existing ssh-agent**; it does not collect passwords in the portal.

1. Get the authorized SSH login and access method from TCDC staff. Do not create new access or enable SSH/WinRM just to use HawkBlock without approval.
2. Make sure the SSH client works and you have *already verified* the host's SSH fingerprint. HawkBlock uses strict host-key checking and will not auto-trust an unknown fingerprint.
3. Launch the portal. In **Remote Actions**, select one host, enter the authorized username, and click **Scan selected**. You may also start it with a default SSH user:

```bash
hawkblock dashboard --ssh-user YOUR_LOGIN
```

If you have a specific approved SSH private key:

```bash
hawkblock dashboard --ssh-user YOUR_LOGIN --ssh-key ~/.ssh/id_ed25519
```

The portal does not retain passwords or private-key contents. The key remains on your machine. **Never commit private keys, credentials, local baselines, or captured results to the public repository.**

Click **Save summary baseline** after a successful scan of **one** host to compare that host's later scans. Use **All team hosts** to try all eight approved machines. It attempts a maximum of three remote SSH connections at once, with a timeout, and doesn't retry indefinitely.

**Windows:** Remote collection works only if the Windows host already has an authorized OpenSSH server and PowerShell available for that SSH login. Windows Server AD roles might not expose local account commands, so account counts can be unavailable. If SSH isn't enabled or permitted, use approved RDP/Windows administrative tools instead. Remote collection does **not** enable WinRM or SSH or perform domain-wide Active Directory enumeration.

**OPNsense:** The IP is listed, but remote SSH collection is intentionally unsupported. Use authorized OPNsense management tools instead.

**Linux:** Remote collectors require Python 3 on the target and a functioning SSH login. Some hardening checks require additional privileges; HawkBlock does not attempt privilege escalation.

## Main commands

```bash
hawkblock dashboard                   # Open the portal
hawkblock dashboard --port 8766       # Another localhost port
hawkblock dashboard --ssh-user USER   # Default login for Remote Actions
hawkblock hosts                       # Print all Team 6 machines (offline)
hawkblock guide mqtt                  # MQTT troubleshooting guide (offline)
hawkblock guide ns1                   # DNS troubleshooting guide (offline)
hawkblock watch                       # One round of manual scored-service checks
hawkblock harden                      # Audit this computer's configuration
hawkblock audit --save-baseline local.json
hawkblock audit --baseline local.json
hawkblock recover nginx              # Diagnose local nginx (no restart)
hawkblock setup --team 6              # Optional: write config/services.json
```

Use `hawkblock COMMAND --help` to see all supported options. Linux `recover restart --apply --yes` is supported from the CLI for specific local services, but the **web portal does not offer restarts**.

## Team 6 network

These host IPs are from page 13 of the competition packet. HawkBlock's **port numbers are conventional defaults**, not necessarily the official checker's settings.

| Host | IP | Function |
| --- | --- | --- |
| `opnsense` | `10.106.40.1` | Firewall (not scored) |
| `ns1` | `10.106.10.53` | DNS |
| `ipcam` | `10.150.0.6` | Cloud HTTP |
| `ftp-archive` | `10.106.10.21` | FTP |
| `artifactorium` | `10.106.10.80` | HTTP |
| `ssh-workstation` | `10.106.10.22` | SSH |
| `ad` | `10.106.20.88` | Active Directory |
| `mqtt` | `10.106.30.49` | MQTT |

**Jumpbox:** `10.99.6.2` is access infrastructure, not an additional scoring target. HawkBlock's remote audit allowlist excludes the jumpbox, White/Black Team systems, scoreboard, Wazuh, auditd, and other infrastructure.

## Before competition use

- Publish the custom tool source and submit its repository link to Black Team under **R20**.
- Obtain Black Team authorization for the remote checks and the **security metadata returned to the portal** under **R23** (no data/artifact exfiltration), as well as tool eligibility under the competition's rules.
- Test outside competition systems before the event, as required by **R24**.
- **R10:** No remote scans or service checks during hands-off periods. The program uses the packet's November 7 Central Time windows (08:00–12:00, 13:00–16:00), but staff announcements override the packet. Stop the portal before hands-off time.
- **R7/R8:** Do not touch protected accounts, Wazuh/auditd, cloud tools, or competition infrastructure. Do not lock yourself or the scoring checker out.

A successful HawkEye probe does **not** guarantee an official scoring tick: DNS records, login requirements, and application content may need different checks.

## Troubleshooting

- **Remote SSH fails:** Check VPN/jumpbox routing, correct login, SSH permissions, and previously verified host keys. HawkBlock never prompts for a password or bypasses host-key validation.
- **Remote returns an error on Windows:** OpenSSH with PowerShell might not be configured. Use approved Windows access methods.
- **Checks are disabled:** It isn't a scheduled hands-on window. Use the offline `hosts` and `guide` commands to prepare.
- **Dashboard only opens inside the VM:** That's intentional. It binds to `127.0.0.1` rather than exposing an unauthenticated network service.
- **All watchdog checks fail:** Check routing, ports, and the expected service behavior. Failure of a probe alone doesn't mean the whole host is offline.

Run tests locally with `python3 -m unittest discover -s tests -q`.
