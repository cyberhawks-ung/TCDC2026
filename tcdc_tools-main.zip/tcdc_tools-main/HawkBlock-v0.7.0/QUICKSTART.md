# HawkBlock — Quick Start (Team 6)

## Start the portal

```bash
cd ~/tcdc/HawkBlock-v0.7.0
source ~/tcdc/.venv/bin/activate
python3 -m pip install -e .
hawkblock dashboard
```

Open **http://127.0.0.1:8765** on the same VM. Press `Ctrl+C` to stop.

## What to click

1. **HawkEye → Check services:** Run the seven scored-service checks during hands-on time.
2. **Remote Actions:** Select an approved team machine, enter its SSH username, and click **Scan selected**. Requires existing authorized SSH access; no passwords are entered here.
3. **Save summary baseline:** After a successful single-host scan, save a session-only baseline and compare future scans.
4. **HawkRescue:** Open the guide if a service check fails.
5. **Inject Board:** Assign injects; submit them in the official TCDC portal.

For a default SSH username, start with `hawkblock dashboard --ssh-user USER`. For a preapproved key file, add `--ssh-key ~/.ssh/id_ed25519`.

**Windows:** The remote scan needs OpenSSH and PowerShell already configured; RDP alone is not sufficient. **OPNsense:** Listed, but not remotely SSH-scanned.

**Rules:** Remote checks only during hands-on periods, only against authorized hosts. Get Black Team approval for custom tools and for transferring security summaries under R23. Do not use an unapproved tool during the competition.
