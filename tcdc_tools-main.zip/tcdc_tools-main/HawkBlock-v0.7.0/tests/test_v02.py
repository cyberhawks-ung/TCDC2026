import http.server
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from hawkblock.cli import main
from hawkblock.watchdog import run
from hawkblock.auditor import compare
from hawkblock import recovery

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'GOOD content')
    def log_message(self, *args):
        pass

class NewTests(unittest.TestCase):
    def test_http_content_check(self):
        server = http.server.HTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            base = {'name':'web','type':'http','host':'127.0.0.1','port':server.server_port}
            self.assertEqual(run([{**base, 'contains':'GOOD'}])[0]['status'], 'ok')
            self.assertEqual(run([{**base, 'contains':'BAD'}])[0]['status'], 'fail')
        finally:
            server.shutdown()
            server.server_close()

    def test_diff_categories(self):
        results = compare({'cron_files':{'old':{'sha256':'a'}}, 'authorized_keys':{}}, {'cron_files':{'new':{'sha256':'b'}}, 'authorized_keys':{'u':{'sha256':'c'}}})
        self.assertEqual({r['change'] for r in results}, {'added','removed'})

    def test_recovery_default_diagnosis(self):
        with patch('hawkblock.recovery.platform.system', return_value='Linux'), patch('hawkblock.recovery.call', return_value={'returncode':0,'stdout':'active','stderr':''}):
            result = recovery.execute('nginx')
            self.assertEqual(result['mode'], 'read-only')
            self.assertEqual(result['config_check'], 'PASS')

    def test_cli_monitor_alert(self):
        with tempfile.TemporaryDirectory() as directory:
            filename = Path(directory) / 'config.json'
            filename.write_text(json.dumps({'services':[{'name':'bad-test','type':'tcp','host':'127.0.0.1','port':1}]}))
            with patch('hawkblock.cli.watchdog.run', return_value=[{'name':'bad-test','status':'fail','detail':'refused','duration_ms':1, 'checked_at':'today'}]):
                self.assertEqual(main(['watch','--config',str(filename),'--alert-after','1']),1)

if __name__ == '__main__':
    unittest.main()
