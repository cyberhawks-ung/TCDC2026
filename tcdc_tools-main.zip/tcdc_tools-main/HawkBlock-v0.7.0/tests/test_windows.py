import unittest
from unittest.mock import patch
from hawkblock import auditor, hardening, recovery, windows

class WindowsIntegrationTests(unittest.TestCase):
    def test_windows_inventory_routes_to_powershell(self):
        with patch('hawkblock.auditor.platform.system', return_value='Windows'), patch('hawkblock.windows.run', return_value={'hostname':'WIN','platform':'Windows','files':{},'accounts':[]}) as called:
            data = auditor.local_inventory([])
        self.assertEqual(data['hostname'], 'WIN')
        called.assert_called_once_with('audit')

    def test_windows_hardening_routes_to_powershell(self):
        with patch('hawkblock.hardening.platform.system', return_value='Windows'), patch('hawkblock.windows.run', return_value=[{'check':'Firewall profiles','status':'review','detail':'on'}]):
            self.assertEqual(hardening.audit()[0]['check'], 'Firewall profiles')

    def test_windows_service_diagnosis_and_no_restart(self):
        with patch('hawkblock.recovery.platform.system', return_value='Windows'), patch('hawkblock.windows.run', return_value={'mode':'read-only','active':'Running'}) as called:
            self.assertEqual(recovery.execute('DNS')['active'], 'Running')
            called.assert_called_once_with('service', 'DNS')
            with self.assertRaises(ValueError):
                recovery.execute('DNS','restart',apply=True,yes=True)
            with self.assertRaises(ValueError):
                recovery.execute('wazuh-agent')

    def test_windows_list_diffs(self):
        before={'hostname':'WIN','accounts':[{'name':'user','enabled':True}]}
        after={'hostname':'WIN','accounts':[{'name':'user','enabled':False},{'name':'new','enabled':True}]}
        changes=auditor.compare(before,after)
        self.assertEqual({c['change'] for c in changes}, {'added','modified'})
        with self.assertRaises(ValueError):
            auditor.compare(before,{'hostname':'OTHER'})

    def test_powershell_script_is_bundled(self):
        self.assertTrue(windows.SCRIPT.is_file())

if __name__ == '__main__':
    unittest.main()
