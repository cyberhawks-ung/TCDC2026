"""Regression tests for Linux JSON account baselines."""
import json
import unittest
from unittest.mock import patch
from hawkblock.auditor import compare, local_inventory


class BaselineRoundtripTests(unittest.TestCase):
    @patch("hawkblock.auditor.platform.system", return_value="Linux")
    def test_accounts_match_after_json_roundtrip(self, _mock_system):
        snapshot = local_inventory([])
        loaded = json.loads(json.dumps(snapshot))
        self.assertEqual(compare(loaded, snapshot), [])

    def test_legacy_list_of_pairs_baseline(self):
        baseline = {"hostname": "test", "accounts": [["alice", {"uid": 1000, "gid": 1000, "shell": "/bin/bash"}]]}
        current = {"hostname": "test", "accounts": [["alice", {"uid": 1000, "gid": 1000, "shell": "/bin/bash"}]]}
        self.assertEqual(compare(baseline, current), [])


if __name__ == "__main__":
    unittest.main()
