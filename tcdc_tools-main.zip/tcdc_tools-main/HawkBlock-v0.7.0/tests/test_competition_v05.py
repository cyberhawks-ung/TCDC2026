import contextlib
import io
import json
import os
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from hawkblock import competition, auditor
from hawkblock.board import Board
from hawkblock.cli import main
from hawkblock.dashboard import DashboardState


class TCDCConfigTests(unittest.TestCase):
    def test_tcdc_targets_match_packet(self):
        config = competition.build_config(4)
        self.assertEqual(len(config['hosts']), 8)
        self.assertEqual(len(config['services']), 7)
        actual = {s['machine']: s['host'] for s in config['services']}
        self.assertEqual(actual, {
            'ns1': '10.104.10.53', 'ipcam': '10.150.0.4', 'ftp-archive': '10.104.10.21',
            'artifactorium': '10.104.10.80', 'ssh-workstation': '10.104.10.22',
            'ad': '10.104.20.88', 'mqtt': '10.104.30.49',
        })
        self.assertEqual(config['hosts'][0]['host'], '10.104.40.1')
        with self.assertRaises(ValueError): competition.build_config(0)
        with self.assertRaises(ValueError): competition.build_config(100)

    def test_event_hands_on_guards(self):
        config = competition.build_config(4)
        tz = ZoneInfo('America/Chicago')
        for day, hour, minute, allowed in [(7,8,0,True),(7,11,59,True),(7,12,0,False),(7,12,30,False),(7,13,0,True),(7,15,59,True),(7,16,0,False),(6,10,0,False)]:
            with self.subTest(day=day,hour=hour,minute=minute):
                now = datetime(2026,11,day,hour,minute,tzinfo=tz)
                self.assertEqual(competition.allowed_now(config, now)[0], allowed)
        self.assertTrue(competition.allowed_now({'services': []})[0])

    def test_windows_timezone_fallback(self):
        from zoneinfo import ZoneInfoNotFoundError
        config = competition.build_config(3)
        with patch('hawkblock.competition.ZoneInfo', side_effect=ZoneInfoNotFoundError):
            actual, note = competition.allowed_now(config, datetime(2026,11,7,15,0,tzinfo=__import__('datetime').timezone.utc))
            self.assertTrue(actual)  # 09:00 CST
            self.assertIn('CST fallback',note)

    def test_setup_makes_config_but_does_not_probe(self):
        with tempfile.TemporaryDirectory() as tmp:
            cwd = os.getcwd()
            try:
                os.chdir(tmp)
                with patch('hawkblock.cli.watchdog.run') as probe, contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(main(['setup','--team','9']), 0)
                    self.assertEqual(main(['setup','--team','9']), 2)
                probe.assert_not_called()
                content = json.loads((Path(tmp)/'config/services.json').read_text())
                self.assertEqual(content['services'][0]['host'],'10.109.10.53')
                self.assertEqual(content['team'],9)
            finally:
                os.chdir(cwd)

    def test_dashboard_rejects_checks_outside_window(self):
        config = competition.build_config(4)
        with tempfile.TemporaryDirectory() as tmp:
            state = DashboardState(config['services'],0.1,config,Path(tmp)/'board.json')
            with patch('hawkblock.dashboard.competition.allowed_now', return_value=(False,'Hands-off period')), patch('hawkblock.dashboard.watchdog.run') as probe:
                self.assertFalse(state.snapshot()['can_check'])
                with self.assertRaises(PermissionError): state.check()
                probe.assert_not_called()


class BoardTests(unittest.TestCase):
    def test_task_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            board = Board(Path(tmp)/'board.json')
            item = board.add({'title':'Submit inject','owner':'Ops'})
            self.assertEqual(len(board.list()),1)
            board.update({'id':item['id'],'status':'doing'})
            self.assertEqual(Board(Path(tmp)/'board.json').list()[0]['status'],'doing')
            with self.assertRaises(ValueError):board.update({'id':item['id'],'status':'invalid'})
            with self.assertRaises(ValueError):board.add({'title':''})

    def test_account_changes_identify_user(self):
        before = {'hostname':'box','accounts':[['alice',{'uid':1000,'shell':'/bin/bash'}]]}
        after = {'hostname':'box','accounts':[['alice',{'uid':1000,'shell':'/bin/zsh'}],['bob',{'uid':1001,'shell':'/bin/bash'}]]}
        changes = auditor.compare(before,after)
        self.assertEqual([(v['item'],v['change']) for v in changes],[('alice','modified'),('bob','added')])

if __name__ == '__main__': unittest.main()
