import http.client
import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch, Mock

from hawkblock import competition, remote
from hawkblock.dashboard import DashboardState, make_handler


class RemoteV07Tests(unittest.TestCase):
    def test_team_scope_exact_and_rejects_substituted_target(self):
        config = competition.build_config(6)
        self.assertEqual(len(remote.targets(config)), 8)
        self.assertEqual(remote.targets(config)['ad']['host'], '10.106.20.88')
        config['hosts'][0]['host'] = '10.106.99.99'
        with self.assertRaisesRegex(ValueError, 'official team topology'):
            remote.targets(config)

    def test_rejects_unknown_host_and_username_injection(self):
        cfg = competition.build_config(6)
        with self.assertRaises(ValueError):
            remote.scan(cfg, 'blackteam', 'student')
        with self.assertRaises(ValueError):
            remote.scan(cfg, 'ns1', '-oProxyCommand=evil')

    def test_opnsense_not_remotely_scanned(self):
        with patch('hawkblock.remote.subprocess.run') as runner:
            result = remote.scan(competition.build_config(6), 'opnsense', 'student')
        self.assertEqual(result['status'], 'unsupported')
        runner.assert_not_called()

    def test_linux_ssh_command_and_result(self):
        fake = {'hostname':'ns1','platform':'Linux',
                'summary':{'accounts':24, 'privileged_members':2},
                'hardening':[{'check':'/etc/passwd','mode':'0o644'}],
                'service_candidates':{'bind9':'active'}}
        with patch('hawkblock.remote.subprocess.run', return_value=Mock(returncode=0, stdout=json.dumps(fake), stderr='')) as runner:
            result = remote.scan(competition.build_config(6), 'ns1', 'student')
        self.assertEqual(result['summary']['accounts'], 24)
        cmd = runner.call_args.args[0]
        self.assertIn('StrictHostKeyChecking=yes', cmd)
        self.assertIn('BatchMode=yes', cmd)
        self.assertIn('student@10.106.10.53', cmd)
        self.assertNotIn('blackteam', result)

    def test_windows_ssh_command_fixed_powershell(self):
        fake = {'hostname':'AD', 'platform':'Windows',
                'summary':{'accounts':None,'scheduled_tasks':5},'hardening':[], 'service_candidates':{'DNS':'Running'}}
        with patch('hawkblock.remote.subprocess.run', return_value=Mock(returncode=0, stdout=json.dumps(fake), stderr='')) as runner:
            result = remote.scan(competition.build_config(6),'ad','operator')
        self.assertEqual(result['platform'], 'Windows')
        self.assertIn('powershell.exe -NoProfile', runner.call_args.args[0][-1])

    def test_session_baseline_count_changes(self):
        old = {'summary': {'accounts': 10, 'privileged_members': 1}, 'hardening':[]}
        current = {'summary': {'accounts': 11, 'privileged_members': 1}, 'hardening':[]}
        self.assertEqual(remote.change_summary(old, current), [{'field':'accounts', 'before':10,'after':11}])


class RemoteWebV07Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = competition.build_config(6)
        self.state = DashboardState(self.cfg['services'], 1, self.cfg,
                                    Path(self.tmp.name) / 'board.json')
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.state))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(2); self.tmp.cleanup()

    def call(self, endpoint, data, token=True):
        c = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        body = json.dumps(data)
        h = {'Content-Type':'application/json'}
        if token:
            h['X-HawkBlock-Token'] = self.state.token
        c.request('POST', endpoint, body, h)
        r = c.getresponse()
        out = r.status, json.loads(r.read())
        c.close()
        return out

    def test_remote_rejects_off_schedule(self):
        with patch('hawkblock.dashboard.competition.allowed_now', return_value=(False,'Hands-off')), patch('hawkblock.dashboard.remote.scan_many') as scan:
            status, data = self.call('/api/remote/scan', {'host':'ns1','username':'student'})
        self.assertEqual(status, 403)
        scan.assert_not_called()

    def test_remote_web_scan_auth_and_baseline(self):
        sample = {'target':'ns1','ip':'10.106.10.53','status':'ok', 'hostname':'dns','platform':'Linux',
                  'summary':{'accounts':10},'hardening':[], 'service_candidates':{}}
        with patch('hawkblock.dashboard.competition.allowed_now',return_value=(True,'Lab')), patch('hawkblock.dashboard.remote.scan_many',return_value=[sample]):
            self.assertEqual(self.call('/api/remote/scan', {'host':'ns1','username':'student'},token=False)[0],403)
            self.assertEqual(self.call('/api/remote/scan', {'host':'outside','username':'student'})[0],400)
            self.assertEqual(self.call('/api/remote/scan', {'host':'ns1','username':'student'})[0],200)
            status, data = self.call('/api/remote/baseline', {'host':'ns1'})
        self.assertEqual(status,200)
        self.assertIn('baseline', data['note'])
        self.assertEqual(self.state.remote_baselines['ns1']['summary']['accounts'],10)

if __name__ == '__main__':
    unittest.main()
