import http.server
import json
import socket
import socketserver
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from hawkblock.watchdog import run, validate
from hawkblock.auditor import compare, hash_file
from hawkblock.recovery import safe_unit, execute

class HTTPHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'ok')
    def log_message(self, *args):
        pass

class ToolkitTests(unittest.TestCase):
    def test_http_probe_local(self):
        server = http.server.HTTPServer(('127.0.0.1', 0), HTTPHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            rows = run([{'name':'local','type':'http','host':'127.0.0.1','port':server.server_port,'path':'/','expected_status':[200]}])
            self.assertEqual(rows[0]['status'], 'ok')
        finally:
            server.shutdown()
            server.server_close()

    def test_validation(self):
        with self.assertRaises(ValueError):
            validate({'name':'bad','type':'http','host':'127.0.0.1','port':0})
        with self.assertRaises(ValueError):
            run([{'name': 'x', 'type': 'unknown', 'host': 'localhost', 'port': 8}])

    def test_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'config'
            p.write_text('original')
            first = hash_file(p)
            p.write_text('changed')
            second = hash_file(p)
            self.assertNotEqual(first['sha256'],second['sha256'])
            delta = compare({'files':{'config':first}}, {'files':{'config':second}})
            self.assertEqual(len(delta),1)

    def test_protected_recovery(self):
        for name in ('wazuh-agent', 'auditd', 'cloud-init', 'xen-guest'):
            with self.assertRaises(ValueError):
                safe_unit(name)
        with self.assertRaises(ValueError):
            safe_unit('custom-service')
        with patch('hawkblock.recovery.platform.system', return_value='Linux'):
            result = execute('nginx','restart')
            self.assertEqual(result['mode'],'dry-run')

if __name__ == '__main__':
    unittest.main()
