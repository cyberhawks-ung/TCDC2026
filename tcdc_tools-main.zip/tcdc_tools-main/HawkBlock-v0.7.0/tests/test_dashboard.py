import http.client
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from hawkblock.dashboard import DashboardState, make_handler


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.state = DashboardState([{'name': 'Local test', 'type': 'tcp', 'host': '127.0.0.1', 'port': 1}], 0.2)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.state))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def request(self, method, path, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        conn.request(method, path, headers=headers or {})
        response = conn.getresponse()
        data = response.read()
        status = response.status
        conn.close()
        return status, data

    def test_home_and_status_are_read_only(self):
        status, data = self.request('GET', '/')
        self.assertEqual(status, 200)
        self.assertIn(b'HawkBlock', data)
        status, data = self.request('GET', '/api/status')
        self.assertEqual(status, 200)
        self.assertIsNone(json.loads(data)['last'])
        self.assertEqual(self.state.history, [])

    def test_requires_token_and_explicit_check(self):
        self.assertEqual(self.request('POST', '/api/check')[0], 403)
        self.assertEqual(self.state.history, [])
        with patch('hawkblock.dashboard.watchdog.run', return_value=[{'name': 'Local test', 'status': 'ok', 'detail': 'passed', 'duration_ms': 1, 'checked_at': 'test'}]):
            status, _ = self.request('POST', '/api/check', {'X-HawkBlock-Token': self.state.token})
        self.assertEqual(status, 200)
        self.assertEqual(len(self.state.history), 1)
        self.assertEqual(self.request('GET', '/api/status')[0], 200)

    def test_rejects_other_origins_and_unknown_actions(self):
        token = {'X-HawkBlock-Token': self.state.token, 'Origin': 'https://external.invalid'}
        self.assertEqual(self.request('POST', '/api/check', token)[0], 403)
        self.assertEqual(self.request('POST', '/api/restart', {'X-HawkBlock-Token': self.state.token})[0], 404)


if __name__ == '__main__':
    unittest.main()
