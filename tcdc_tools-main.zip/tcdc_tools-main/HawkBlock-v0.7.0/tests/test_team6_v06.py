"""Team 6 defaults, offline commands, and dashboard status regression tests."""
import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hawkblock import competition
from hawkblock.cli import config_path, main
from hawkblock.dashboard import DashboardState


class TeamSixTests(unittest.TestCase):
    def test_team_six_packet_ips(self):
        config = competition.team6_config()
        self.assertEqual(config['team'], 6)
        self.assertEqual(config['jumpbox'], '10.99.6.2')
        self.assertEqual(len(config['hosts']), 8)
        self.assertEqual(len(config['services']), 7)
        expected = {
            'opnsense': '10.106.40.1',
            'ns1': '10.106.10.53',
            'ipcam': '10.150.0.6',
            'ftp-archive': '10.106.10.21',
            'artifactorium': '10.106.10.80',
            'ssh-workstation': '10.106.10.22',
            'ad': '10.106.20.88',
            'mqtt': '10.106.30.49',
        }
        self.assertEqual({x['name']: x['host'] for x in config['hosts']}, expected)
        self.assertEqual(json.loads(Path(__file__).resolve().parents[1].joinpath('hawkblock', 'team6.json').read_text())['team'], 6)

    def test_default_config_works_from_unrelated_directory(self):
        old = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            try:
                os.chdir(tmp)
                cfg = json.loads(Path(config_path(None)).read_text())
                self.assertEqual(cfg['team'], 6)
                self.assertEqual(cfg['services'][0]['host'], '10.106.10.53')
            finally:
                os.chdir(old)

    def test_hosts_and_guides_are_offline(self):
        old = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            try:
                os.chdir(tmp)
                buf = io.StringIO()
                with patch('hawkblock.cli.watchdog.run') as probe, contextlib.redirect_stdout(buf):
                    self.assertEqual(main(['hosts']), 0)
                    self.assertEqual(main(['guide', 'mqtt']), 0)
                    self.assertEqual(main(['guide', 'ns1']), 0)
                probe.assert_not_called()
                text = buf.getvalue()
                self.assertIn('10.106.30.49', text)
                self.assertIn('10.99.6.2', text)
                self.assertIn('MQTT', text)
                self.assertIn('DNS', text)
            finally:
                os.chdir(old)

    def test_snapshot_does_not_claim_untested_hosts_down(self):
        config = competition.team6_config()
        with tempfile.TemporaryDirectory() as tmp:
            state = DashboardState(config['services'], 0.2, config, Path(tmp) / 'board.json')
            snapshot = state.snapshot()
            self.assertIsNone(snapshot['last'])
            self.assertEqual(snapshot['failures'], [])
            self.assertEqual(snapshot['jumpbox'], '10.99.6.2')
            self.assertEqual(next(x for x in snapshot['hosts'] if x['name'] == 'opnsense')['probe_status'], 'unscored')
            self.assertTrue(all(x['probe_status'] == 'not_checked' for x in snapshot['hosts'] if x['scored']))
            self.assertEqual(len(snapshot['guides']['AD TCP availability']['steps']), 4)

            with state.lock:
                state.history.append({'time': 'simulated-test-time', 'results': [
                    {'name': service['name'], 'status': 'fail' if service['machine'] == 'mqtt' else 'ok',
                     'detail': 'simulated failure', 'duration_ms': 1, 'alert': False} for service in config['services']
                ]})
            snapshot = state.snapshot()
            self.assertEqual(len(snapshot['failures']), 1)
            self.assertEqual(snapshot['failures'][0]['name'], 'MQTT broker')
            self.assertEqual(next(x for x in snapshot['hosts'] if x['name'] == 'mqtt')['probe_status'], 'probe_failed')
            self.assertEqual(next(x for x in snapshot['hosts'] if x['name'] == 'ad')['probe_status'], 'probe_passed')
            self.assertEqual(next(x for x in snapshot['hosts'] if x['name'] == 'opnsense')['probe_status'], 'unscored')

    def test_playbooks_are_complete(self):
        for name, _, _, _, _ in competition.SERVICES:
            guide = competition.get_playbook(name)
            self.assertIsNotNone(guide, name)
            self.assertGreaterEqual(len(guide['steps']), 3)
            self.assertTrue(guide['probe'])
            self.assertTrue(guide['caution'])


if __name__ == '__main__':
    unittest.main()
