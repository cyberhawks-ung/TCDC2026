"""Single-shot, unprivileged, read-only service checks. No infrastructure scanning."""
import ftplib
import http.client
import json
import os
import socket
import ssl
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
from .common import stamp

SUPPORTED = {"tcp", "http", "https", "dns", "ftp", "ssh", "mqtt"}


def validate(service):
    name = service.get("name", "unnamed")
    kind = service.get("type")
    if kind not in SUPPORTED:
        raise ValueError(f"{name}: invalid service type {kind!r}")
    if not service.get("host"):
        raise ValueError(f"{name}: missing host")
    port = service.get("port", {"http": 80, "https": 443, "dns": 53, "ftp": 21, "ssh": 22, "mqtt": 1883}.get(kind))
    if not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError(f"{name}: invalid port")
    return port


def read_exact(sock, n):
    parts = []
    while n:
        chunk = sock.recv(n)
        if not chunk:
            raise ConnectionError("connection closed")
        parts.append(chunk)
        n -= len(chunk)
    return b"".join(parts)


def dns_query(host, port, timeout, hostname):
    # Minimal DNS A/IN query with 16-bit randomized transaction ID.
    labels = hostname.strip(".").split(".")
    if not hostname or any(not label or len(label.encode("idna")) > 63 for label in labels):
        raise ValueError("invalid DNS query name")
    txid = int.from_bytes(__import__("os").urandom(2), "big")
    query_name = b"".join(bytes([len(label.encode("idna"))]) + label.encode("idna") for label in labels) + b"\x00"
    payload = txid.to_bytes(2, "big") + b"\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + query_name + b"\x00\x01\x00\x01"
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(timeout)
        sock.sendto(payload, (host, port))
        data, _ = sock.recvfrom(4096)
    if len(data) < 12 or int.from_bytes(data[:2], "big") != txid or not (data[2] & 0x80):
        raise ValueError("invalid DNS response")
    rcode = data[3] & 0x0f
    if rcode != 0:
        raise ValueError(f"DNS RCODE {rcode}")
    if int.from_bytes(data[6:8], "big") == 0:
        raise ValueError("DNS response contains no answers")
    return "DNS answer received"


def mqtt_ping(host, port, timeout):
    # MQTT 3.1.1 CONNECT, wait for CONNACK, then DISCONNECT.
    # Test only with approval: may count as an unauthenticated connection, not broker functionality.
    ident = b"cyberhawks-health"
    variable = b"\x00\x04MQTT\x04\x02\x00\x0a"
    payload = len(ident).to_bytes(2, "big") + ident
    body = variable + payload
    if len(body) >= 128:
        raise ValueError("unsupported MQTT packet size")
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall(b"\x10" + bytes([len(body)]) + body)
        response = read_exact(sock, 4)
        if response[:3] != b"\x20\x02\x00" or response[3] != 0:
            raise ValueError(f"MQTT CONNACK rejected ({response.hex()})")
        sock.sendall(b"\xe0\x00")
    return "MQTT session accepted (not publish/subscribe)"


def probe(service, timeout=2.0):
    port = validate(service)
    kind, host = service["type"], service["host"]
    start = time.monotonic()
    try:
        if kind in {"tcp", "ssh"}:
            with socket.create_connection((host, port), timeout=timeout) as sock:
                sock.settimeout(timeout)
                if kind == "ssh":
                    banner = sock.recv(256)
                    if not banner.startswith(b"SSH-"):
                        raise ValueError("No SSH banner")
                    detail = "SSH banner received (not authentication)"
                else:
                    detail = "TCP connected (not application validation)"
        elif kind in {"http", "https"}:
            path = service.get("path", "/")
            if not isinstance(path, str) or not path.startswith("/"):
                raise ValueError("HTTP path must begin with /")
            conn = (http.client.HTTPSConnection if kind == "https" else http.client.HTTPConnection)(host, port, timeout=timeout)
            try:
                conn.request("GET", path, headers={"User-Agent": "HawkBlock/0.2"})
                response = conn.getresponse()
                # Read small response only; no file collection.
                body = response.read(4096)
                contains = service.get("contains")
                if contains is not None and (not isinstance(contains, str) or contains.encode("utf-8") not in body):
                    raise ValueError("Expected HTTP response text not found")
                expected = service.get("expected_status", [200])
                if response.status not in expected:
                    raise ValueError(f"HTTP {response.status} not in {expected}")
                detail = f"HTTP {response.status}"
            finally:
                conn.close()
        elif kind == "dns":
            query = service.get("query", "example.org")
            detail = dns_query(host, port, timeout, query)
        elif kind == "ftp":
            with ftplib.FTP() as ftp:
                ftp.connect(host, port, timeout=timeout)
                username_var = service.get("username_env")
                password_var = service.get("password_env")
                if bool(username_var) != bool(password_var):
                    raise ValueError("FTP authentication needs both username_env and password_env")
                if username_var:
                    username, password = os.environ.get(username_var), os.environ.get(password_var)
                    if not username or password is None:
                        raise ValueError("FTP credential environment variables not set")
                    ftp.login(username, password)
                    ftp.voidcmd("NOOP")
                    detail = "FTP authentication and NOOP succeeded"
                else:
                    detail = "FTP welcome received (not authentication)"
        elif kind == "mqtt":
            detail = mqtt_ping(host, port, timeout)
        return {"name": service["name"], "status": "ok", "detail": detail, "duration_ms": round((time.monotonic() - start) * 1000), "checked_at": stamp()}
    except (OSError, ValueError, TimeoutError, EOFError, ftplib.Error, ssl.SSLError) as error:
        return {"name": service["name"], "status": "fail", "detail": f"{type(error).__name__}: {error}", "duration_ms": round((time.monotonic() - start) * 1000), "checked_at": stamp()}


def run(services, timeout=2.0):
    if not services or not isinstance(services, list):
        raise ValueError("services must be a nonempty list")
    if len(services) > 16:
        raise ValueError("Limit is 16 explicitly configured services")
    for svc in services:
        validate(svc)
    with ThreadPoolExecutor(max_workers=min(4, len(services))) as pool:
        futures = {pool.submit(probe, svc, timeout): i for i, svc in enumerate(services)}
        results = [None] * len(services)
        for future in as_completed(futures):
            results[futures[future]] = future.result()
    return results
