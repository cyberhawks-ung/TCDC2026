"""Allowlisted, manual Linux service diagnosis and recovery. Never touch protected agents."""
import platform
import subprocess

BLOCKED = ('wazuh', 'auditd', 'xen', 'cloud-init', 'xe-guest', 'blackteam', 'whiteteam')
DEFAULT_ALLOWED = {'ssh', 'sshd', 'nginx', 'apache2', 'bind9', 'named', 'vsftpd', 'mosquitto', 'proftpd'}
CONFIG_TESTS = {'nginx': ['nginx', '-t'], 'apache2': ['apache2ctl', 'configtest'], 'sshd': ['sshd', '-t'], 'ssh': ['sshd', '-t'], 'named': ['named-checkconf'], 'bind9': ['named-checkconf']}


def safe_unit(name):
    if not name or len(name) > 70 or not all(c.isalnum() or c in '_.@-' for c in name):
        raise ValueError('Invalid systemd service name')
    if any(term in name.lower() for term in BLOCKED):
        raise ValueError('Protected service cannot be targeted')
    if name not in DEFAULT_ALLOWED:
        raise ValueError(f'{name!r} is not in the approved service allowlist')
    return name


def call(command):
    try:
        p = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
        return {'returncode': p.returncode, 'stdout': p.stdout.strip()[:600], 'stderr': p.stderr.strip()[:300]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'returncode': 2, 'stderr': str(exc)}


def execute(name, action='diagnose', apply=False, yes=False):
    if platform.system() == 'Windows':
        if action == 'restart':
            raise ValueError('Windows restarts are intentionally disabled; use Windows Services after verifying impact')
        if action not in ('diagnose', 'status'):
            raise ValueError('Only Windows service status/diagnose is supported')
        safe_windows_service(name)
        from . import windows
        return windows.run('service', name)
    if platform.system() != 'Linux':
        raise ValueError('Supported systems: Linux and Windows')
    safe_unit(name)
    if action not in ('status', 'diagnose', 'restart'):
        raise ValueError('Action must be diagnose, status, or restart')
    if action == 'restart':
        command = ['systemctl', 'restart', name]
        if not (apply and yes):
            return {'mode': 'dry-run', 'command': command, 'note': 'No changes. Run with --apply --yes only after checking scorer impact.'}
        outcome = call(command)
        return {'mode': 'executed', 'command': command, **outcome, 'note': 'Run diagnose and the service watchdog to verify the service.'}
    active = call(['systemctl', 'is-active', name])
    result = {'mode': 'read-only', 'active': active['stdout'] or active['stderr'] or 'unknown'}
    if action == 'diagnose':
        enabled = call(['systemctl', 'is-enabled', name])
        result['enabled'] = enabled['stdout'] or enabled['stderr'] or 'unknown'
        if name in CONFIG_TESTS:
            test = call(CONFIG_TESTS[name])
            result['config_check'] = 'PASS' if test['returncode'] == 0 else 'REVIEW: ' + (test['stderr'] or test['stdout'] or f'exit {test["returncode"]}')
        result['note'] = 'Read-only diagnosis; use restart --apply --yes only if needed. Check health afterward.'
    return result


def safe_windows_service(name):
    allowed = {'sshd', 'W3SVC', 'DNS', 'NTDS', 'mosquitto', 'FTPSVC', 'MSMQ'}
    if name not in allowed:
        raise ValueError(f'{name!r} is not in the Windows diagnostic allowlist')
    return name
