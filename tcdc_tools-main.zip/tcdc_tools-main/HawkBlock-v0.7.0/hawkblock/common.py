"""Local safety controls and JSON configuration helpers."""
import json
import os
import pathlib
import sys
from datetime import datetime, timezone


def load_json(path):
    with open(path, encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("Configuration must be a JSON object")
    return value


def save_json(path, data):
    destination = pathlib.Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.replace(temporary, destination)


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def require_confirm(yes, intent):
    if not yes:
        raise ValueError(f"Refusing {intent}; pass --apply --yes to authorize this exact action")


def print_json(data):
    json.dump(data, sys.stdout, indent=2)
    print()
