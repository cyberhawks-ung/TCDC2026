"""Small local-only inject task board. Does not contact the competition dashboard."""
import json
import os
import secrets
from pathlib import Path

STATUSES = ('todo', 'doing', 'submitted')


class Board:
    def __init__(self, path):
        self.path = Path(path)

    def list(self):
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(data, list) or len(data) > 100:
            raise ValueError('Invalid local task board')
        return data

    def save(self, data):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name('.' + self.path.name + '.' + secrets.token_hex(5) + '.tmp')
        fd = os.open(tmp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
                f.write('\n')
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        finally:
            if tmp.exists():
                tmp.unlink()

    def add(self, payload):
        tasks = self.list()
        if len(tasks) >= 100:
            raise ValueError('Task board limit is 100 items')
        title = payload.get('title')
        owner = payload.get('owner', '')
        if not isinstance(title, str) or not 1 <= len(title.strip()) <= 100:
            raise ValueError('Title must be 1-100 characters')
        if not isinstance(owner, str) or len(owner) > 48:
            raise ValueError('Owner must be 48 characters or less')
        task = {'id': secrets.token_hex(6), 'title': title.strip(), 'owner': owner.strip(), 'status': 'todo'}
        tasks.append(task)
        self.save(tasks)
        return task

    def update(self, payload):
        task_id, status = payload.get('id'), payload.get('status')
        if status not in STATUSES:
            raise ValueError('Status must be todo, doing, or submitted')
        tasks = self.list()
        for task in tasks:
            if task['id'] == task_id:
                task['status'] = status
                self.save(tasks)
                return task
        raise ValueError('Unknown task ID')
