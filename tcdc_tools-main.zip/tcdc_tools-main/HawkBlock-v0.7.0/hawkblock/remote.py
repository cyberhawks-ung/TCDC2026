"""Small, allowlisted, read-only remote host checks using key-based SSH.

Never accepts shell commands, arbitrary IP targets or passwords from the browser.
Only summarized security metadata comes back; no file contents or key material.
"""
from __future__ import annotations

import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import ipaddress
import json
import re
import shlex
import subprocess
from pathlib import Path

MAX_OUTPUT = 65536
USER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_.-]{0,31}$')
HOST_NAMES = {'opnsense', 'ns1', 'ipcam', 'ftp-archive', 'artifactorium', 'ssh-workstation', 'ad', 'mqtt'}

# Fixed code executed on Ubuntu targets. Deliberately excludes protected accounts,
# cloud-init/Xen tools, Wazuh and auditd, and returns summaries (not file content).
LINUX_SCRIPT = r'''
import json, os, pathlib, pwd, grp, platform, subprocess, stat, glob
blocked = ('blackteam','whiteteam','wazuh','auditd','cloud-init','xe-')
def safe(s): return not any(x in str(s).lower() for x in blocked)
def file_mode(p):
    try: return oct(stat.S_IMODE(os.stat(p).st_mode))
    except OSError: return 'unavailable'
def count_files(paths):
    found=[]
    for d in paths:
        try: found += [x for x in pathlib.Path(d).iterdir() if x.is_file() and safe(x.name)]
        except OSError: pass
    return len(found)
def active(service):
    try:
        p=subprocess.run(['systemctl','is-active',service],text=True,capture_output=True,timeout=2)
        return p.stdout.strip()[:25] if p.returncode == 0 else 'not-active/unknown'
    except (OSError,subprocess.TimeoutExpired): return 'unavailable'
accounts=[u for u in pwd.getpwall() if safe(u.pw_name)]
priv=[]
for gname in ('sudo','wheel'):
    try:
        g=grp.getgrnam(gname)
        priv.extend(m for m in g.gr_mem if safe(m))
        priv.extend(u.pw_name for u in accounts if u.pw_gid==g.gr_gid)
    except KeyError: pass
candidate={'ns1':['named','bind9'],'ipcam':['nginx','apache2'],
 'ftp-archive':['vsftpd','proftpd'],'artifactorium':['nginx','apache2'],
 'ssh-workstation':['ssh','sshd']}.get('__HOST_LABEL__',[])
result={'hostname':platform.node(),'platform':'Linux',
 'summary':{'accounts':len(accounts), 'interactive_accounts':sum(u.pw_shell not in ('/sbin/nologin','/usr/sbin/nologin','/bin/false') for u in accounts),
 'privileged_members':len(set(priv)),'cron_files':count_files(['/etc/cron.d','/etc/cron.daily','/etc/cron.hourly','/etc/cron.weekly','/etc/cron.monthly']),
 'custom_services':count_files(['/etc/systemd/system']),
 'authorized_key_files':sum((pathlib.Path(u.pw_dir)/'.ssh/authorized_keys').is_file() for u in accounts if u.pw_uid==0 or u.pw_uid>=1000)},
 'hardening':[{'check':p,'mode':file_mode(p)} for p in ('/etc/passwd','/etc/shadow','/etc/sudoers','/etc/ssh/sshd_config')],
 'service_candidates':{name:active(name) for name in candidate},
 'note':'Read-only summary. Service names are guesses, not proof of scoring health.'}
print(json.dumps(result,separators=(',',':')))
'''

# Read-only Windows PowerShell via an already configured OpenSSH server.
# On DCs, Get-LocalUser may not be available; null means not collected.
WINDOWS_SCRIPT = r'''
$ErrorActionPreference = 'SilentlyContinue'
function Count-Filtered($items) {
  return @($items | Where-Object { $_ -and $_.Name -notmatch '(?i)blackteam|whiteteam|wazuh|auditd|cloud-init|xe-' }).Count
}
$computer = $env:COMPUTERNAME
$users = @(Get-LocalUser -ErrorAction SilentlyContinue)
$admins = @(Get-LocalGroupMember -Group 'Administrators' -ErrorAction SilentlyContinue)
if ('__HOST_LABEL__' -eq 'ad') { $users = $null; $admins = $null } # DC local accounts cannot be enumerated this way
$tasks = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -notmatch '(?i)blackteam|whiteteam|wazuh|auditd|cloud-init|xe-' })
$startup = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '(?i)blackteam|whiteteam|wazuh|auditd|cloud-init|xe-' })
$firewall = @(Get-NetFirewallProfile -ErrorAction SilentlyContinue | ForEach-Object { [pscustomobject]@{name=$_.Name;enabled=$_.Enabled} })
$svcNames = @()
if ('__HOST_LABEL__' -eq 'ad') { $svcNames = @('DNS','NTDS') }
if ('__HOST_LABEL__' -eq 'mqtt') { $svcNames = @('mosquitto') }
$svc = @{}
foreach ($name in $svcNames) {
 $s = Get-Service -Name $name -ErrorAction SilentlyContinue
 if ($s) { $svc[$name] = [string]$s.Status } else { $svc[$name] = 'not-found' }
}
$r = [pscustomobject]@{
 hostname=$computer;platform='Windows';
 summary=[pscustomobject]@{
   accounts=$(if ($null -eq $users) {$null} else {Count-Filtered $users});
   privileged_members=$(if ($null -eq $admins) {$null} else {Count-Filtered $admins});
   scheduled_tasks=(Count-Filtered $tasks);
   startup_entries=(Count-Filtered $startup)
 };
 hardening=@($firewall);
 service_candidates=$svc;
 note='Read-only summary. No domain-wide AD enumeration or credential export.'
}
$r | ConvertTo-Json -Depth 6 -Compress
'''


def targets(config):
    """Only named team boxes; never the jumpbox, scoreboard or arbitrary IP."""
    items = config.get('hosts', [])
    if not isinstance(items, list) or len(items) > 8:
        raise ValueError('Expected at most eight team hosts')
    result = {}
    for item in items:
        if not isinstance(item, dict) or item.get('name') not in HOST_NAMES:
            raise ValueError('Remote host not in the team box allowlist')
        ip = str(ipaddress.IPv4Address(item['host']))
        if not ipaddress.ip_address(ip).is_private:
            raise ValueError('Remote targets must be private network addresses')
        if ip == config.get('jumpbox') or item['name'] in result:
            raise ValueError('Invalid or duplicate team target')
        result[item['name']] = {**item, 'host': ip}
    # A competition config must match the official team topology exactly.
    if config.get('competition') == 'TCDC SMC 2026':
        from .competition import build_config
        expected = {x['name']: x['host'] for x in build_config(config['team'])['hosts']}
        if {name: x['host'] for name, x in result.items()} != expected:
            raise ValueError('Remote target list differs from the official team topology')
    return result


def validate_user(username):
    if not isinstance(username, str) or not USER_RE.fullmatch(username):
        raise ValueError('Enter an authorized SSH login name (letters, digits, _ . -)')
    return username


def remote_command(label, is_windows):
    if label not in HOST_NAMES:
        raise ValueError('Unknown host label')
    if is_windows:
        script = WINDOWS_SCRIPT.replace('__HOST_LABEL__', label)
        encoded = base64.b64encode(script.encode('utf-16-le')).decode('ascii')
        return 'powershell.exe -NoProfile -NonInteractive -EncodedCommand ' + encoded
    script = LINUX_SCRIPT.replace('__HOST_LABEL__', label)
    encoded = base64.b64encode(script.encode('utf-8')).decode('ascii')
    # The script is a fixed bundled constant; no user input becomes a shell command.
    wrapper = 'import base64;exec(base64.b64decode(' + repr(encoded) + '))'
    return 'python3 -c ' + shlex.quote(wrapper)



def _filter_hardening(value):
    if not isinstance(value, list):
        return []
    output = []
    for item in value[:12]:
        if not isinstance(item, dict):
            continue
        if 'check' in item:
            output.append({'check': str(item.get('check', ''))[:70], 'mode': str(item.get('mode', ''))[:25]})
        elif 'name' in item:
            output.append({'name': str(item.get('name', ''))[:50], 'enabled': bool(item.get('enabled', False))})
    return output


def _filter_services(value):
    if not isinstance(value, dict):
        return {}
    allowed = {'named', 'bind9', 'nginx', 'apache2', 'vsftpd', 'proftpd', 'ssh', 'sshd', 'DNS', 'NTDS', 'mosquitto'}
    return {key: str(value[key])[:35] for key in allowed if key in value}

def scan(config, name, username, key_file=None, timeout=12):
    hosts = targets(config)
    if name not in hosts:
        raise ValueError('Choose a host from the Team Hosts list')
    username = validate_user(username)
    if not 3 <= timeout <= 30:
        raise ValueError('Remote timeout must be 3-30 seconds')
    host = hosts[name]
    if host['os'].lower().startswith('opnsense'):
        return {'target': name, 'ip': host['host'], 'status': 'unsupported',
                'error': 'OPNsense is not scanned over SSH. Use authorized OPNsense administration instead.'}
    is_windows = host['os'].lower().startswith('windows')
    cmd = [
        'ssh', '-T', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
        '-o', 'NumberOfPasswordPrompts=0', '-o', 'ConnectTimeout=5',
        '-o', 'ConnectionAttempts=1', '-o', 'LogLevel=ERROR',
    ]
    if key_file:
        key = Path(key_file).expanduser()
        if not key.is_file():
            raise ValueError('SSH private key file does not exist')
        cmd.extend(['-i', str(key)])
    cmd.extend(['--', f'{username}@{host["host"]}', remote_command(name, is_windows)])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except FileNotFoundError:
        return {'target': name, 'ip': host['host'], 'status': 'error', 'error': 'OpenSSH client not installed on dashboard machine'}
    except subprocess.TimeoutExpired:
        return {'target': name, 'ip': host['host'], 'status': 'error', 'error': 'SSH connection/check timed out'}
    if proc.returncode:
        # Do not echo untrusted remote stderr, which may contain sensitive data.
        return {'target': name, 'ip': host['host'], 'status': 'error',
                'error': 'SSH failed; check login, known_hosts, access, and remote Python/PowerShell availability'}
    if len(proc.stdout) > MAX_OUTPUT:
        return {'target': name, 'ip': host['host'], 'status': 'error', 'error': 'Remote summary exceeded output limit'}
    try:
        result = json.loads(proc.stdout.strip())
        if not isinstance(result, dict) or result.get('platform') not in ('Linux', 'Windows') or not isinstance(result.get('summary'), dict):
            raise ValueError('Unexpected remote result')
    except (json.JSONDecodeError, ValueError):
        return {'target': name, 'ip': host['host'], 'status': 'error',
                'error': 'Remote output could not be parsed; check remote shell and collector availability'}
    # Explicit field allowlist limits how much remote information enters the portal.
    return {'target': name, 'ip': host['host'], 'status': 'ok',
            'hostname': str(result.get('hostname', ''))[:80], 'platform': result['platform'],
            'summary': {str(k)[:40]: v for k, v in result['summary'].items() if isinstance(v, (int, bool, str, type(None)))},
            'hardening': _filter_hardening(result.get('hardening')),
            'service_candidates': _filter_services(result.get('service_candidates')),
            'note': str(result.get('note', ''))[:200]}


def scan_many(config, names, username, key_file=None, timeout=12):
    allowed = targets(config)
    if names == 'all':
        names = list(allowed)
    else:
        names = [names]
    for name in names:
        if name not in allowed:
            raise ValueError('Remote target is not on the team allowlist')
    validate_user(username)
    results = {}
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(scan, config, name, username, key_file, timeout): name for name in names}
        for future in as_completed(futures):
            name = futures[future]
            try:
                results[name] = future.result()
            except (OSError, ValueError) as exc:
                results[name] = {'target': name, 'status': 'error', 'error': str(exc)[:160]}
    return [results[name] for name in names]


def change_summary(previous, current):
    """Compare only aggregate counts and static hardening state, not raw artifacts."""
    old = previous.get('summary', {})
    new = current.get('summary', {})
    changes = []
    for key in sorted(set(old) | set(new)):
        if old.get(key) != new.get(key):
            changes.append({'field': key, 'before': old.get(key), 'after': new.get(key)})
    if previous.get('hardening') != current.get('hardening'):
        changes.append({'field': 'hardening', 'before': 'previous results', 'after': 'changed'})
    return changes
