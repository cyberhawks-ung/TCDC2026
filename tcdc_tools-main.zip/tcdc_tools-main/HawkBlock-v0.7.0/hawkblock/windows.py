"""Local PowerShell read-only inventory; packaged alongside the Python CLI."""
import json
import pathlib
import platform
import shutil
import subprocess

SCRIPT = pathlib.Path(__file__).with_name('windows.ps1')


def run(mode, service=None):
    if platform.system() != 'Windows':
        raise ValueError('Windows checks must run locally on a Windows host')
    exe = shutil.which('powershell.exe') or shutil.which('powershell') or shutil.which('pwsh')
    if not exe:
        raise ValueError('PowerShell is required for Windows checks')
    cmd = [exe, '-NoProfile', '-NonInteractive', '-File', str(SCRIPT), '-Mode', mode]
    if service is not None:
        cmd.extend(['-Service', service])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=45, check=False)
    except subprocess.TimeoutExpired as exc:
        raise ValueError('Windows check timed out') from exc
    if proc.returncode:
        raise ValueError('PowerShell check failed: ' + (proc.stderr.strip()[:240] or f'exit {proc.returncode}'))
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError('Windows check returned invalid JSON') from exc
