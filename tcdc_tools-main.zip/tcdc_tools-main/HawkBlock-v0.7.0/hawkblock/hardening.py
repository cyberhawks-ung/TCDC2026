"""Read-only Linux configuration checks; no automatic hardening."""
import grp
import os
import pathlib
import platform
import pwd
import shutil
import socket
import stat
import subprocess


def check_file(path, maximum):
    try:
        mode = stat.S_IMODE(pathlib.Path(path).stat().st_mode)
    except (OSError, ValueError) as e:
        return {'check': path, 'status': 'unknown', 'detail': str(e)}
    return {'check': path, 'status': 'ok' if mode & ~maximum == 0 else 'review', 'detail': f'{oct(mode)} (recommended max {oct(maximum)})'}


def inspect_sshd():
    if not pathlib.Path('/etc/ssh/sshd_config').exists():
        return [{'check': 'sshd', 'status': 'unknown', 'detail': 'Not installed'}]
    if not shutil.which('sshd'):
        return [{'check': 'sshd', 'status': 'unknown', 'detail': 'sshd -T unavailable'}]
    try:
        proc = subprocess.run(['sshd', '-T'], capture_output=True, text=True, timeout=5, check=False)
        if proc.returncode:
            return [{'check': 'sshd', 'status': 'unknown', 'detail': 'sshd -T failed (may require privileges)'}]
        settings = dict(line.split(' ', 1) for line in proc.stdout.splitlines() if ' ' in line)
        result = []
        for name, flagged in [('permitrootlogin', {'yes'}), ('permitemptypasswords', {'yes'}), ('passwordauthentication', {'yes'})]:
            value = settings.get(name)
            result.append({'check': 'ssh:' + name, 'status': 'unknown' if value is None else 'review' if value in flagged else 'ok', 'detail': f'{value or "unknown"}; do not change auth without checking scoring'})
        return result
    except (OSError, subprocess.TimeoutExpired):
        return [{'check': 'sshd', 'status': 'unknown', 'detail': 'Could not inspect effective SSH config'}]


def privileged_users():
    result = []
    for group in ('sudo', 'wheel'):
        try:
            g = grp.getgrnam(group)
        except KeyError:
            continue
        members = set(g.gr_mem)
        for account in pwd.getpwall():
            if account.pw_gid == g.gr_gid:
                members.add(account.pw_name)
        result.append({'check': f'group:{group}', 'status': 'review', 'detail': ', '.join(sorted(members)) or '(no members)'})
    return result


def listeners():
    # ss prints local listening socket endpoints only; never scans other hosts.
    if not shutil.which('ss'):
        return [{'check': 'listeners', 'status': 'unknown', 'detail': 'ss not installed'}]
    try:
        proc = subprocess.run(['ss', '-lnt'], capture_output=True, text=True, timeout=5, check=False)
        if proc.returncode:
            return [{'check': 'listeners', 'status': 'unknown', 'detail': 'ss failed'}]
        endpoints = []
        for line in proc.stdout.splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 4:
                endpoints.append(fields[3])
        return [{'check': 'listening TCP', 'status': 'review', 'detail': ', '.join(sorted(endpoints)[:15]) + (' ...' if len(endpoints) > 15 else '') or '(none)'}]
    except (OSError, subprocess.TimeoutExpired):
        return [{'check': 'listeners', 'status': 'unknown', 'detail': 'Could not inspect sockets'}]


def audit():
    if platform.system() == 'Windows':
        from . import windows
        result = windows.run('harden')
        return result if isinstance(result, list) else [result]
    if platform.system() != 'Linux':
        raise ValueError('Supported systems: Linux and Windows')
    rows = [check_file('/etc/passwd', 0o644), check_file('/etc/shadow', 0o640), check_file('/etc/sudoers', 0o440)]
    rows += inspect_sshd() + privileged_users() + listeners()
    rows.append({'check': 'scorer / firewall', 'status': 'manual', 'detail': 'Verify dashboard passwords, service access, R18, and protected accounts before making changes'})
    return rows
