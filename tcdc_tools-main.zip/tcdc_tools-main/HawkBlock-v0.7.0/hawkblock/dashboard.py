"""Loopback-only web dashboard with manual read-only checks and local notes."""
import json
from datetime import datetime, timezone, timedelta
import secrets
from pathlib import Path
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from urllib.parse import urlparse

from . import watchdog, hardening, auditor, recovery, competition, remote
from .common import load_json, stamp, save_json
from .board import Board


class DashboardState:
    def __init__(self, services, timeout, config=None, board_path=None, ssh_user=None, ssh_key=None):
        self.services = services
        self.timeout = timeout
        self.config = config or {"services": services}
        self.board = Board(board_path or Path.home() / ".hawkblock" / "injects.json")
        self.baseline_file = Path.home() / ".hawkblock" / "baseline.json"
        self.token = secrets.token_urlsafe(24)
        self.lock = threading.Lock()
        self.history = []
        self.streaks = {}
        self.ssh_user = ssh_user
        self.ssh_key = ssh_key
        self.remote_reports = {}
        self.remote_baselines = {}
        self.remote_busy = threading.Lock()

    def check(self):
        permitted, reason = competition.allowed_now(self.config)
        if not permitted:
            raise PermissionError(reason)
        rows = watchdog.run(self.services, self.timeout)
        with self.lock:
            for row in rows:
                name = row['name']
                self.streaks[name] = self.streaks.get(name, 0) + 1 if row['status'] != 'ok' else 0
                row['fail_streak'] = self.streaks[name]
                row['alert'] = self.streaks[name] >= 2
            report = {'time': stamp(), 'results': rows}
            self.history.append(report)
            self.history = self.history[-25:]
        return report

    def scan_remote(self, host, username):
        permitted, reason = competition.allowed_now(self.config)
        if not permitted:
            raise PermissionError(reason)
        # An all-host scan can last several SSH timeouts; do not begin one
        # when it could cross into the competition's hands-off period.
        future_permitted, _ = competition.allowed_now(
            self.config, now=datetime.now(timezone.utc) + timedelta(seconds=60)
        )
        if not future_permitted:
            raise PermissionError('Too close to hands-off time for a remote scan. Stop before the break.')
        user = username or self.ssh_user
        if not user:
            raise ValueError('Enter the SSH login supplied for these hosts')
        if not self.remote_busy.acquire(blocking=False):
            raise ValueError('Another remote scan is already running')
        try:
            reports = remote.scan_many(self.config, host, user, self.ssh_key)
            with self.lock:
                for report in reports:
                    name = report['target']
                    baseline = self.remote_baselines.get(name)
                    report['changes'] = remote.change_summary(baseline, report) if baseline and report['status'] == 'ok' else None
                    self.remote_reports[name] = report
            return {'reports': reports}
        finally:
            self.remote_busy.release()

    def baseline_remote(self, host):
        permitted, reason = competition.allowed_now(self.config)
        if not permitted:
            raise PermissionError(reason)
        with self.lock:
            report = self.remote_reports.get(host)
            if report is None or report['status'] != 'ok':
                raise ValueError('Scan this host successfully before saving a baseline')
            # Session-only summary; no disk persistence or bulk data export.
            self.remote_baselines[host] = {
                'summary': dict(report.get('summary', {})),
                'hardening': list(report.get('hardening', [])),
            }
        return {'note': 'Summary baseline kept in memory until you close the dashboard.'}

    def snapshot(self):
        permitted, reason = competition.allowed_now(self.config)
        with self.lock:
            latest = self.history[-1] if self.history else None
            results = {x['name']: x for x in latest['results']} if latest else {}
            services = []
            failures = []
            host_probes = {}
            for svc in self.services:
                port = watchdog.validate(svc)
                name = svc['name']
                last = results.get(name)
                guide = competition.get_playbook(name)
                machine = svc.get('machine')
                services.append({'name': name, 'machine': machine, 'type': svc['type'],
                                 'host': svc['host'], 'port': port,
                                 'probe_description': guide['probe'] if guide else svc['type'].upper() + ' service check'})
                if machine:
                    host_probes[machine] = 'not_checked' if last is None else ('probe_passed' if last['status'] == 'ok' else 'probe_failed')
                if last and last['status'] != 'ok':
                    failures.append({'name': name, 'machine': machine or svc['host'], 'detail': last['detail'],
                                     'steps': guide['steps'][:2] if guide else ['Review this service on the authorized host.']})
            hosts = [{**host, 'probe_status': 'unscored' if not host.get('scored') else host_probes.get(host['name'], 'not_checked')}
                     for host in self.config.get('hosts', [])]
            return {'competition': self.config.get('competition'), 'team': self.config.get('team'),
                    'jumpbox': self.config.get('jumpbox'), 'config_notes': self.config.get('notes', ''),
                    'hosts': hosts, 'can_check': permitted, 'schedule_note': reason,
                    'guides': {name: competition.get_playbook(name) for name in competition.RECOVERY},
                    'services': services, 'failures': failures,
                    'remote_supported': bool(self.config.get('hosts')),
                    'remote_default_user': self.ssh_user or '',
                    'remote_reports': dict(self.remote_reports),
                    'remote_baselined': list(self.remote_baselines),
                    'last': latest,
                    'history': [{'time': item['time'], 'passing': sum(x['status'] == 'ok' for x in item['results']),
                                 'total': len(item['results'])} for item in self.history]}


def make_handler(state):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'HawkBlock/0.7'

        def log_message(self, fmt, *args):
            # Keep credentials out of HTTP logs; only loopback accepted.
            return

        def respond(self, code, data, mime='application/json'):
            content = data if isinstance(data, bytes) else json.dumps(data).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(content)

        def trusted_host(self):
            return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}')

        def do_GET(self):
            if not self.trusted_host():
                return self.respond(403, {'error': 'Localhost only'})
            path = urlparse(self.path).path
            if path == '/':
                content = files('hawkblock').joinpath('dashboard.html').read_text(encoding='utf-8').replace('__SESSION_TOKEN__', state.token)
                return self.respond(200, content.encode(), 'text/html; charset=utf-8')
            if path == '/api/status':
                return self.respond(200, state.snapshot())
            if path == '/api/tasks':
                return self.respond(200, {'tasks': state.board.list()})
            return self.respond(404, {'error': 'Not found'})

        def do_POST(self):
            if not self.trusted_host():
                return self.respond(403, {'error': 'Localhost only'})
            if self.headers.get('X-HawkBlock-Token') != state.token or self.headers.get('Origin') not in (None, f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
                return self.respond(403, {'error': 'Unauthorized request'})
            path = urlparse(self.path).path
            try:
                body_len = int(self.headers.get('Content-Length', '0'))
                if not 0 <= body_len <= 1024:
                    return self.respond(400, {'error': 'Invalid request size'})
                if path in ('/api/remote/scan', '/api/remote/baseline'):
                    if not body_len:
                        return self.respond(400, {'error': 'JSON body is required'})
                    payload = json.loads(self.rfile.read(body_len))
                    if not isinstance(payload, dict):
                        return self.respond(400, {'error': 'JSON object required'})
                    host = payload.get('host')
                    if not isinstance(host, str):
                        raise ValueError('Choose a team host')
                    if path.endswith('baseline'):
                        remote.targets(state.config)
                        if host not in remote.targets(state.config):
                            raise ValueError('Choose a team host')
                        return self.respond(200, state.baseline_remote(host))
                    if host != 'all' and host not in remote.targets(state.config):
                        raise ValueError('Choose a team host')
                    return self.respond(200, state.scan_remote(host, payload.get('username')))
                if path == '/api/tasks/add' or path == '/api/tasks/update':
                    if not body_len:
                        return self.respond(400, {'error': 'JSON body is required'})
                    payload = json.loads(self.rfile.read(body_len))
                    if not isinstance(payload, dict):
                        return self.respond(400, {'error': 'JSON object required'})
                    with state.lock:
                        task = state.board.add(payload) if path.endswith('add') else state.board.update(payload)
                    return self.respond(200, {'task': task})
                if body_len:
                    return self.respond(400, {'error': 'Request body not supported'})
                if path == '/api/check':
                    return self.respond(200, state.check())
                if path in ('/api/harden', '/api/audit', '/api/audit/baseline'):
                    permitted, reason = competition.allowed_now(state.config)
                    if not permitted:
                        raise PermissionError(reason)
                if path == '/api/harden':
                    return self.respond(200, {'checks': hardening.audit(), 'note': 'Checks run on the local machine hosting the dashboard.'})
                if path == '/api/audit' or path == '/api/audit/baseline':
                    paths = [] if __import__('sys').platform == 'win32' else ['/etc/ssh/sshd_config', '/etc/passwd', '/etc/sudoers']
                    snapshot = auditor.local_inventory(paths)
                    if path.endswith('baseline'):
                        state.baseline_file.parent.mkdir(parents=True, exist_ok=True)
                        save_json(str(state.baseline_file), snapshot)
                        state.baseline_file.chmod(0o600)
                        return self.respond(200, {'note': 'Baseline saved locally. Re-run audit later to compare.'})
                    changes = None
                    if state.baseline_file.exists():
                        changes = auditor.compare(load_json(state.baseline_file), snapshot)
                    # No account details, file contents or secrets sent to browser.
                    return self.respond(200, {'hostname': snapshot.get('hostname'), 'platform': snapshot.get('platform'), 'accounts': len(snapshot.get('accounts', [])), 'files_checked': len(snapshot.get('files', {})),
                        'baseline_exists': state.baseline_file.exists(),
                        'changes': [{'category': x['category'], 'item': x.get('item','-'), 'change': x.get('change')} for x in (changes or [])][:50],
                        'change_count': len(changes) if changes is not None else None})
                return self.respond(404, {'error': 'Not found'})
            except PermissionError as exc:
                return self.respond(403, {'error': str(exc)[:240]})
            except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                return self.respond(400, {'error': str(exc)[:240]})
            except OSError as exc:
                return self.respond(500, {'error': str(exc)[:240]})

    return Handler


def serve(config, port=8765, timeout=2.0, ssh_user=None, ssh_key=None):
    if not 1024 <= port <= 65535:
        raise ValueError('port must be between 1024 and 65535')
    if not 0.1 <= timeout <= 10:
        raise ValueError('timeout must be 0.1-10 seconds')
    config_data = load_json(config)
    services = config_data.get('services')
    if not isinstance(services, list) or not 1 <= len(services) <= 16:
        raise ValueError('config must include 1-16 services')
    for service in services:
        watchdog.validate(service)
    remote.targets(config_data) if config_data.get('hosts') else None
    server = ThreadingHTTPServer(('127.0.0.1', port), make_handler(DashboardState(services, timeout, config_data, ssh_user=ssh_user, ssh_key=ssh_key)))
    print(f'HawkBlock dashboard: http://127.0.0.1:{port}')
    print('Manual checks only; remote host checks require approved SSH access. Ctrl+C to stop.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nDashboard stopped.')
    finally:
        server.server_close()
