"""Small, local CLI for defensive checks and the TCDC dashboard."""
import argparse
import json
import sys
import time
from pathlib import Path
from . import __version__, watchdog, auditor, hardening, recovery, competition
from .common import load_json, save_json, stamp


def show(rows, keys):
    widths = [min(55, max(len(k.upper()), *(len(str(row.get(k, '-'))) for row in rows))) for k in keys]
    fmt = '  '.join('{:<%d}' % width for width in widths)
    print(fmt.format(*(k.upper() for k in keys)))
    print('  '.join('-' * width for width in widths))
    for row in rows:
        print(fmt.format(*(str(row.get(k, '-')).replace('\n', ' ')[:width] for k, width in zip(keys, widths))))


DEFAULT_CONFIG = 'config/services.json'


def config_path(explicit):
    if explicit:
        return explicit
    if Path(DEFAULT_CONFIG).exists():
        return DEFAULT_CONFIG
    # Shipped Team 6 defaults work from any current working directory.
    return str(Path(__file__).with_name('team6.json'))


def load_service_config(path):
    config = load_json(path)
    services = config.get('services')
    if not isinstance(services, list) or not 1 <= len(services) <= 16:
        raise ValueError('Configuration requires 1-16 services')
    for svc in services:
        watchdog.validate(svc)
    return config


def main(argv=None):
    p = argparse.ArgumentParser(prog='hawkblock', description='HawkBlock: check, audit, and troubleshoot authorized systems')
    p.add_argument('--version', action='version', version=__version__)
    sub = p.add_subparsers(dest='command', required=True)
    hosts_cmd = sub.add_parser('hosts', help='Print the team IP list without connecting to targets')
    hosts_cmd.add_argument('--config', default=None, help='Alternate team configuration')
    guide_cmd = sub.add_parser('guide', help='Show a manual troubleshooting playbook (no network access)')
    guide_cmd.add_argument('service', help='Scored service name or hostname, e.g. dns, ns1, mqtt')
    setup = sub.add_parser('setup', help='Create TCDC team config (no network access)')
    setup.add_argument('--team', type=int, required=True, help='Your assigned TCDC team number')
    setup.add_argument('--output', default=DEFAULT_CONFIG, help='Destination config (default: config/services.json)')
    setup.add_argument('--force', action='store_true', help='Overwrite an existing config')
    w = sub.add_parser('watch', help='HawkEye: check listed services')
    w.add_argument('--config', default=None, help='Service config (auto: config/services.json, else localhost example)')
    w.add_argument('--repeat', type=int, default=1, help='Number of checks, 1-20; never runs forever')
    w.add_argument('--interval', type=int, default=30, help='Seconds between cycles, minimum 30')
    w.add_argument('--timeout', type=float, default=2.0)
    w.add_argument('--alert-after', type=int, default=2, help='Consecutive failures before alert (default 2)')
    w.add_argument('--json', action='store_true', help='Machine-readable output')
    w.add_argument('--log', help='Write local check results as JSON Lines; keep private')
    h = sub.add_parser('harden', help='HawkLock: read-only host checks')
    h.add_argument('--json', action='store_true')
    a = sub.add_parser('audit', help='HawkStalker: local user and persistence snapshot')
    a.add_argument('--paths', nargs='*', default=None)
    a.add_argument('--save-baseline', metavar='FILE', help='Save a private local baseline')
    a.add_argument('--baseline', metavar='FILE', help='Compare to an earlier baseline')
    a.add_argument('--json', action='store_true')
    r = sub.add_parser('recover', help='HawkRescue: diagnose/status supported services; Linux restarts require confirmation')
    r.add_argument('service', help='Allowlisted service name, e.g. nginx')
    r.add_argument('action', nargs='?', default='diagnose', choices=['diagnose', 'status', 'restart'])
    r.add_argument('--apply', action='store_true', help='Only with --yes: actually restart')
    r.add_argument('--yes', action='store_true')
    r.add_argument('--json', action='store_true')
    d = sub.add_parser('dashboard', help='Local manual-check dashboard and inject board')
    d.add_argument('--config', default=None, help='Service config (auto: config/services.json, else localhost example)')
    d.add_argument('--port', type=int, default=8765, help='Local HTTP port (default 8765)')
    d.add_argument('--timeout', type=float, default=2.0, help='Service timeout 0.1-10 seconds')
    d.add_argument('--ssh-user', default=None, help='Default SSH username for remote dashboard checks')
    d.add_argument('--ssh-key', default=None, help='Optional path to SSH private key (never uploaded)')
    args = p.parse_args(argv)
    try:
        if args.command == 'hosts':
            config = load_service_config(config_path(args.config))
            print(f'HawkBlock | TCDC Team {config.get("team", "lab")} | inventory only')
            show([{'name': h['name'], 'ip': h['host'], 'os': h.get('os', 'unknown'),
                   'scored': 'yes' if h.get('scored') else 'no'} for h in config.get('hosts', [])],
                 ['name', 'ip', 'os', 'scored'])
            if config.get('jumpbox'):
                print(f'Jumpbox: {config["jumpbox"]} (access infrastructure; not a scored host)')
            print('No checks were run.')
            return 0
        if args.command == 'guide':
            lookup = args.service.casefold()
            service = next((name for name, item in competition.RECOVERY.items()
                            if name.casefold() == lookup or item[0].casefold() == lookup), None)
            if not service:
                names = ', '.join(x[0] for x in competition.RECOVERY.values())
                raise ValueError(f'Unknown service {args.service!r}; use one of these hostnames: {names}')
            data = competition.get_playbook(service)
            print(f'HawkRescue | {service} | {data["machine"]} ({data["os"]})')
            print('Probe: ' + data['probe'])
            for idx, step in enumerate(data['steps'], start=1):
                print(f' {idx}. {step}')
            print('Caution: ' + data['caution'])
            print('Reference only; no network access or service changes.')
            return 0
        if args.command == 'setup':
            destination = Path(args.output).expanduser()
            if destination.exists() and not args.force:
                raise ValueError(f'{destination} exists; use --force only if you want to replace it')
            config = competition.build_config(args.team)
            save_json(str(destination), config)
            print(f'HawkBlock configured for TCDC team {args.team}: {destination}')
            print('7 scored services, 8 hosts; no checks were run.')
            print('Next: hawkblock dashboard')
            print('Review targets, check semantics, and event windows before use.')
            return 0
        if args.command == 'dashboard':
            from .dashboard import serve
            serve(config_path(args.config), args.port, args.timeout, args.ssh_user, args.ssh_key)
            return 0
        if args.command == 'watch':
            if not 1 <= args.repeat <= 20 or args.interval < 30 or not 0.1 <= args.timeout <= 10 or not 1 <= args.alert_after <= 20:
                raise ValueError('repeat must be 1-20, interval >= 30, timeout 0.1-10, alert-after 1-20')
            config = load_service_config(config_path(args.config))
            permitted, reason = competition.allowed_now(config)
            if not permitted:
                raise ValueError(reason)
            services = config.get('services')
            # validate before opening the optional log
            if not isinstance(services, list) or not services:
                raise ValueError('config needs a nonempty services list')
            for service in services:
                watchdog.validate(service)
            streaks = {}
            failures = 0
            for cycle in range(args.repeat):
                if cycle:
                    time.sleep(args.interval)
                permitted, reason = competition.allowed_now(config)
                if not permitted:
                    raise ValueError(reason)
                rows = watchdog.run(services, args.timeout)
                for row in rows:
                    key = row['name']
                    streaks[key] = streaks.get(key, 0) + 1 if row['status'] != 'ok' else 0
                    row['fail_streak'] = streaks[key]
                    row['alert'] = streaks[key] >= args.alert_after
                    if row['status'] != 'ok':
                        failures += 1
                output = {'time': stamp(), 'cycle': cycle + 1, 'results': rows}
                if args.json:
                    print(json.dumps(output))
                else:
                    print(f'\nHawkEye | cycle {cycle + 1}/{args.repeat} | {output["time"]}')
                    show([{'service': x['name'], 'state': 'ALERT' if x['alert'] else x['status'].upper(), 'ms': x['duration_ms'], 'detail': x['detail']} for x in rows], ['service', 'state', 'ms', 'detail'])
                    print(f'Passing: {sum(x["status"] == "ok" for x in rows)}/{len(rows)}; alerts: {sum(x["alert"] for x in rows)}')
                if args.log:
                    logfile = Path(args.log).expanduser()
                    logfile.parent.mkdir(parents=True, exist_ok=True)
                    with logfile.open('a', encoding='utf-8') as f:
                        f.write(json.dumps(output) + '\n')
            return 1 if failures else 0
        if args.command == 'harden':
            rows = hardening.audit()
            if args.json:
                print(json.dumps({'checks': rows}, indent=2))
            else:
                show(rows, ['check', 'status', 'detail'])
                print('\nReview findings manually; nothing has been changed.')
            return 0
        if args.command == 'audit':
            snapshot = auditor.local_inventory(args.paths if args.paths is not None else ([] if sys.platform == 'win32' else ['/etc/ssh/sshd_config', '/etc/passwd', '/etc/sudoers']))
            changes = auditor.compare(load_json(args.baseline), snapshot) if args.baseline else None
            if args.json:
                print(json.dumps({'changes': changes, 'current': snapshot}, indent=2))
            elif changes is not None:
                print(f'HawkStalker | {len(changes)} change(s)')
                show([{'category': x['category'], 'item': x.get('item', '-'), 'change': x.get('change', 'modified')} for x in changes], ['category', 'item', 'change'])
            else:
                print(f'HawkStalker | host {snapshot["hostname"]} | {len(snapshot.get("accounts", []))} accounts | {len(snapshot["files"])} selected files')
                print('Use --save-baseline FILE now and --baseline FILE later to see changes.')
            if args.save_baseline:
                save_json(args.save_baseline, snapshot)
                print('Baseline written locally (do not commit it): ' + args.save_baseline, file=sys.stderr)
            return 0
        if args.command == 'recover':
            result = recovery.execute(args.service, args.action, apply=args.apply, yes=args.yes)
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f'HawkRescue | {args.service} | {result.get("mode", "unknown")}')
                for key in ('active', 'enabled', 'config_check', 'note', 'detail', 'stdout', 'stderr'):
                    if result.get(key):
                        print(f'{key}: {result[key]}')
                if result.get('command'):
                    print('command: ' + ' '.join(result['command']))
            return 1 if result.get('returncode', 0) or result.get('mode') == 'error' else 0
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
