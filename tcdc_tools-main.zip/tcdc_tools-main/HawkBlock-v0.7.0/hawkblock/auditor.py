"""Read-only local host inventory and change detection. No log/agent tampering."""
import hashlib
import os
import pathlib
import platform
import subprocess
from .common import stamp

MAX_HASH_BYTES = 2 * 1024 * 1024


def hash_file(path):
    p = pathlib.Path(path)
    if not p.is_file() or p.is_symlink():
        return {"present": False}
    stats = p.stat()
    result = {"present": True, "size": stats.st_size, "mode": oct(stats.st_mode & 0o777), "uid": getattr(stats, "st_uid", None), "gid": getattr(stats, "st_gid", None)}
    if stats.st_size <= MAX_HASH_BYTES:
        try:
            result["sha256"] = hashlib.sha256(p.read_bytes()).hexdigest()
        except OSError as e:
            result["error"] = str(e)
    else:
        result["hash_note"] = "file exceeds 2 MiB hash limit"
    return result


def local_inventory(paths):
    system = platform.system()
    if system == "Windows":
        from . import windows
        data = windows.run("audit")
        # Keep user-selected file hashing local and separate from PowerShell defaults.
        for path in paths:
            p = pathlib.Path(path).expanduser()
            if p.exists():
                data["files"][str(p)] = hash_file(p)
        return data
    data = {"checked_at": stamp(), "hostname": platform.node(), "platform": system, "files": {}}
    for path in paths:
        p = pathlib.Path(path).expanduser()
        # No recursive traversal; no secrets exported; metadata and hash only.
        data["files"][str(p)] = hash_file(p)
    if system == "Linux":
        import pwd
        import grp
        data["accounts"] = [[name, details] for name, details in sorted({u.pw_name: {"uid": u.pw_uid, "gid": u.pw_gid, "shell": u.pw_shell} for u in pwd.getpwall()}.items())]
        groups = {}
        for g in grp.getgrall():
            if g.gr_name in ("sudo", "wheel", "adm"):
                groups[g.gr_name] = sorted(g.gr_mem)
        data["privileged_groups"] = groups
        data["root_authorized_keys"] = hash_file("/root/.ssh/authorized_keys")
        # Metadata/hashes only: never store public key contents or command outputs.
        data["authorized_keys"] = {}
        for user in pwd.getpwall():
            if user.pw_uid == 0 or user.pw_uid >= 1000:
                keyfile = pathlib.Path(user.pw_dir) / ".ssh" / "authorized_keys"
                if keyfile.exists():
                    data["authorized_keys"][user.pw_name] = hash_file(keyfile)
        data["cron_files"] = {}
        for directory in ("/etc/cron.d", "/etc/cron.daily", "/etc/cron.hourly", "/etc/cron.weekly", "/etc/cron.monthly"):
            try:
                for path in sorted(pathlib.Path(directory).iterdir()):
                    if path.is_file() and not path.is_symlink():
                        data["cron_files"][str(path)] = hash_file(path)
            except OSError:
                pass
        # List timer/service names only. No access to auditd or Wazuh.
        try:
            proc = subprocess.run(["systemctl", "list-unit-files", "--type=service", "--no-legend", "--no-pager"], capture_output=True, text=True, timeout=5, check=False)
            data["service_names"] = sorted(line.split()[0] for line in proc.stdout.splitlines() if line.split())[:1000]
        except (OSError, subprocess.TimeoutExpired):
            data["service_names"] = []
        try:
            proc = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=5, check=False)
            # Count without capturing commands or potentially sensitive content.
            data["user_crontab_entries"] = sum(bool(line.strip()) and not line.lstrip().startswith("#") for line in proc.stdout.splitlines())
        except (OSError, subprocess.TimeoutExpired):
            data["user_crontab_entries"] = None
    else:
        data["note"] = "Linux accounts/services supported; Windows audit commands are in docs/windows-audit.ps1"
    return data


def compare(baseline, current):
    if baseline.get("hostname") and current.get("hostname") and baseline["hostname"] != current["hostname"]:
        raise ValueError('Baseline belongs to a different host')
    changes = []
    for field in ("files", "accounts", "privileged_groups", "root_authorized_keys", "authorized_keys", "cron_files", "service_names", "user_crontab_entries", "scheduled_tasks", "startup_entries", "services"):
        if field in baseline and baseline.get(field) != current.get(field):
            if isinstance(baseline.get(field), dict) and isinstance(current.get(field), dict):
                keys = sorted(set(baseline[field]) | set(current[field]))
                for key in keys:
                    if baseline[field].get(key) != current[field].get(key):
                        changes.append({"category": field, "item": key, "change": "added" if key not in baseline[field] else "removed" if key not in current[field] else "modified", "previous": baseline[field].get(key), "current": current[field].get(key)})
            elif field == "accounts" and isinstance(baseline.get(field), list) and isinstance(current.get(field), list) and all(isinstance(x, (list, tuple)) and len(x) == 2 for x in baseline[field] + current[field]):
                # Linux pwd entries are [username, {uid, gid, shell}].
                before = dict(baseline[field])
                after = dict(current[field])
                for item in sorted(set(before) | set(after)):
                    if before.get(item) != after.get(item):
                        changes.append({"category": field, "item": item, "change": "added" if item not in before else "removed" if item not in after else "modified"})
            elif field in ("accounts", "scheduled_tasks", "startup_entries", "services") and isinstance(baseline.get(field), list) and isinstance(current.get(field), list) and all(isinstance(x, dict) for x in baseline[field] + current[field]):
                def key(item):
                    return (item.get("location", ""), item.get("path", ""), item.get("name", ""))
                before = {key(x): x for x in baseline[field]}
                after = {key(x): x for x in current[field]}
                for item in sorted(set(before) | set(after)):
                    if before.get(item) != after.get(item):
                        changes.append({"category": field, "item": "/".join(str(v) for v in item if v), "change": "added" if item not in before else "removed" if item not in after else "modified"})
            else:
                changes.append({"category": field, "change": "modified", "previous": baseline.get(field), "current": current.get(field)})
    return changes
