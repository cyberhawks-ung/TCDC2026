# HawkBlock Windows checks. Local, read-only; no external connections.
param(
    [ValidateSet('audit','harden','service')][string]$Mode = 'audit',
    [string]$Service = ''
)
$ErrorActionPreference = 'Stop'
function TryGet([scriptblock]$Block, $Fallback) {
    try { & $Block } catch { $Fallback }
}
function FilterProtected($Items) {
    @($Items | Where-Object { $_ -notmatch '(?i)wazuh|auditd|xen|cloud.init|xe.guest|blackteam|whiteteam' })
}
function FileInfo([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return @{present=$false} }
    try {
        $item = Get-Item -LiteralPath $Path -ErrorAction Stop
        $entry = @{present=$true;size=$item.Length;last_write_utc=$item.LastWriteTimeUtc.ToString('o')}
        if ($item.Length -le 2097152) { $entry.sha256 = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
        return $entry
    } catch { return @{present=$true;error='Access denied or unreadable'} }
}
function LocalUsers {
    # Local accounts only; does not attempt to enumerate domain accounts.
    @(TryGet { Get-LocalUser -ErrorAction Stop | ForEach-Object { @{ name=$_.Name; enabled=[bool]$_.Enabled; sid=$_.SID.Value } } } @())
}
function Administrators {
    @(TryGet {
        Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop |
            ForEach-Object { @{ name=$_.Name; kind=[string]$_.ObjectClass; sid=if ($_.SID) { $_.SID.Value } else { '' } } }
    } @())
}
function GetStartup {
    $out = @()
    $locations = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run')
    foreach ($location in $locations) {
        if (Test-Path $location) {
            $props = TryGet { Get-ItemProperty -Path $location -ErrorAction Stop } $null
            if ($props) {
                foreach ($p in $props.PSObject.Properties) {
                    if ($p.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$') {
                        # Hash the startup value; avoid storing command lines containing secrets.
                        $bytes = [Text.Encoding]::UTF8.GetBytes([string]$p.Value)
                        $hasher = [Security.Cryptography.SHA256]::Create()
                        try { $hash = [BitConverter]::ToString($hasher.ComputeHash($bytes)).Replace('-','').ToLowerInvariant() } finally { $hasher.Dispose() }
                        $out += @{location=$location;name=$p.Name;value_sha256=$hash}
                    }
                }
            }
        }
    }
    $out
}
function ServiceInventory {
    @(TryGet { Get-CimInstance Win32_Service -ErrorAction Stop |
        Where-Object { $_.Name -notmatch '(?i)wazuh|auditd|xen|cloud.init|xe.guest|blackteam|whiteteam' } |
        ForEach-Object { @{name=$_.Name;start_mode=$_.StartMode;state=$_.State} } } @())
}
if ($Mode -eq 'audit') {
    $files = @{}
    foreach ($path in @("$env:windir\System32\drivers\etc\hosts", "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup")) {
        if (Test-Path -LiteralPath $path -PathType Leaf) { $files[$path] = FileInfo $path }
    }
    $tasks = @(TryGet { Get-ScheduledTask -ErrorAction Stop |
        Where-Object { $_.TaskPath -notlike '\Microsoft\*' -and $_.TaskName -notmatch '(?i)wazuh|auditd|xen|cloud.init|blackteam|whiteteam' } |
        ForEach-Object { @{name=$_.TaskName;path=$_.TaskPath;state=[string]$_.State} } } @())
    $accounts = @(LocalUsers | Sort-Object name)
    $admins = @(Administrators | Sort-Object name)
    $startup = @(GetStartup | Sort-Object location,name)
    $services = @(ServiceInventory | Sort-Object name)
    $data = @{
        checked_at=(Get-Date).ToUniversalTime().ToString('o'); hostname=$env:COMPUTERNAME;
        platform='Windows'; accounts=$accounts; privileged_groups=@{Administrators=$admins};
        scheduled_tasks=$tasks; startup_entries=$startup; services=$services; files=$files
    }
    $data | ConvertTo-Json -Depth 9 -Compress
    exit 0
}
if ($Mode -eq 'harden') {
    $checks = @()
    $admins = @(Administrators)
    $checks += @{check='Local Administrators';status='review';detail="Review $($admins.Count) member(s) for unexpected privileged access"}
    $users = @(LocalUsers)
    $enabled = @($users | Where-Object { $_.enabled })
    $checks += @{check='Enabled local users';status='review';detail="$($enabled.Count) enabled local account(s); do not remove required competition users"}
    $profiles = TryGet { @(Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object { "$($_.Name):$($_.Enabled)" }) } @()
    $checks += @{check='Firewall profiles';status='review';detail=$(if ($profiles.Count) { $profiles -join ', ' } else { 'Unavailable; check manually' })}
    $listeners = @(TryGet { Get-NetTCPConnection -State Listen -ErrorAction Stop | Select-Object -ExpandProperty LocalPort -Unique | Sort-Object } @())
    $checks += @{check='Listening TCP ports';status='review';detail=$(if ($listeners.Count) { (@($listeners | Select-Object -First 20) -join ', ') } else { 'Unavailable or none' })}
    $checks += @{check='Windows Update';status='manual';detail='Review updates only after considering downtime and scoring requirements'}
    $checks += @{check='Active Directory';status='manual';detail='Review domain policies and domain privileges with native admin tools; no automated changes'}
    $checks | ConvertTo-Json -Depth 6 -Compress
    exit 0
}
if ($Mode -eq 'service') {
    if ($Service -notmatch '^[a-zA-Z0-9_-]{1,64}$' -or $Service -match '(?i)wazuh|auditd|xen|cloud.init|xe.guest|blackteam|whiteteam') { throw 'Invalid or protected service' }
    $svc = TryGet { Get-Service -Name $Service -ErrorAction Stop } $null
    if (-not $svc) { @{mode='read-only';note='Service not found';service=$Service;active='not found'} | ConvertTo-Json -Compress; exit 0 }
    @{mode='read-only';service=$Service;active=[string]$svc.Status;enabled=[string]$svc.StartType;note='Diagnostics only. No service changes performed.'} | ConvertTo-Json -Compress
    exit 0
}
