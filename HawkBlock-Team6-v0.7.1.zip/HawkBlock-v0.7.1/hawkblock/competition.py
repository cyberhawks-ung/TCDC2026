"""TCDC-specific Team 6 target generation and read-only recovery playbooks."""
from __future__ import annotations


SERVICES = (
    ('DNS', 'ns1', 'dns', '10.{t}.10.53', 53),
    ('Cloud IP Cam HTTP', 'ipcam', 'http', '10.150.0.{x}', 80),
    ('FTP archive', 'ftp-archive', 'ftp', '10.{t}.10.21', 21),
    ('Artifactorium HTTP', 'artifactorium', 'http', '10.{t}.10.80', 80),
    ('SSH workstation', 'ssh-workstation', 'ssh', '10.{t}.10.22', 22),
    ('AD TCP availability', 'ad', 'tcp', '10.{t}.20.88', 88),
    ('MQTT broker', 'mqtt', 'mqtt', '10.{t}.30.49', 1883),
)
HOSTS = ('opnsense', 'ns1', 'ipcam', 'ftp-archive', 'artifactorium', 'ssh-workstation', 'ad', 'mqtt')

RECOVERY = {
    'DNS': ('ns1', 'Linux', 'Check DNS responses; inspect named/bind9 config and service logs before any restart.'),
    'Cloud IP Cam HTTP': ('ipcam', 'Linux', 'Check HTTP response and application logs; this cloud host is separately addressed.'),
    'FTP archive': ('ftp-archive', 'Linux', 'Check FTP greeting, login if permitted, and vsftpd/proftpd status.'),
    'Artifactorium HTTP': ('artifactorium', 'Linux', 'Check HTTP page/content; inspect nginx/apache2 and configuration validity.'),
    'SSH workstation': ('ssh-workstation', 'Linux', 'Confirm SSH access using approved credentials before changing sshd settings.'),
    'AD TCP availability': ('ad', 'Windows', 'Port 88 is only a reachability test. Validate AD authentication and DNS separately; avoid automatic DC restarts.'),
    'MQTT broker': ('mqtt', 'Windows', 'Check the MQTT broker service and an approved publish/subscribe test; connection-only is incomplete.'),
}


def build_config(team):
    if not isinstance(team, int) or not 1 <= team <= 99:
        raise ValueError('Team number must be 1-99; confirm your assigned team ID')
    t = 100 + team
    services = []
    for name, host_label, kind, fmt, port in SERVICES:
        svc = {'name': name, 'machine': host_label, 'type': kind, 'host': fmt.format(t=t, x=team), 'port': port}
        if kind == 'http':
            svc.update(path='/', expected_status=[200])
        if kind == 'dns':
            svc['query'] = f'ns1.team{team}.playtcdc.org'
        services.append(svc)
    hosts = [{'name': 'opnsense', 'os': 'OPNsense', 'host': f'10.{t}.40.1', 'scored': False}]
    os_type = {'ad': 'Windows Server 2025', 'mqtt': 'Windows 11'}
    hosts.extend({'name': item['machine'], 'os': os_type.get(item['machine'], 'Ubuntu Server'), 'host': item['host'], 'scored': True} for item in services)
    return {
        'competition': 'TCDC SMC 2026', 'team': team,
        'notes': 'Targets from the official packet. Verify protocols, credentials and allowed checks before use.',
        'hosts': hosts, 'services': services,
    }



# Read-only, human-directed response plans. These are starting points, not
# assertions about the actual service software or the official scorer.
PLAYBOOKS = {
    'DNS': {
        'probe': 'Requests an A record for ns1.team6.playtcdc.org (update the query if staff gives a different record).',
        'steps': [
            'Confirm you are using the Team 6 DNS IP and the VPN/jumpbox route is available.',
            'Verify the requested record is supposed to exist; a missing record does not prove DNS is down.',
            'On ns1, review the installed DNS daemon, zone configuration, and its logs.',
            'Test a known-good record directly against this DNS server before changing anything.',
        ],
        'caution': 'Never replace DNS zone data or restart a daemon solely because this example A-record probe failed.',
    },
    'Cloud IP Cam HTTP': {
        'probe': 'GET / over HTTP, expecting status 200 (path and response might differ).',
        'steps': [
            'Confirm cloud IP 10.150.0.6 is reachable from an approved access point.',
            'Check the assigned application URL and expected HTTP status with staff-provided details.',
            'Inspect application and web-server status/logs using authorized access.',
            'Retest the application endpoint after any approved adjustment.',
        ],
        'caution': 'Cloud IP cam is separately addressed. Avoid assuming its server uses nginx or Apache.',
    },
    'FTP archive': {
        'probe': 'Checks FTP greeting; without configured credential environment variables, it does not log in.',
        'steps': [
            'Check that FTP is reachable on the configured port.',
            'If authorized, test login using the service account specified by the competition.',
            'On ftp-archive, inspect the FTP service state, authentication logs and file access permissions.',
            'Confirm the service works with required credentials; a banner alone cannot prove scoring health.',
        ],
        'caution': 'Do not disable required service accounts or change checker passwords without updating the official dashboard.',
    },
    'Artifactorium HTTP': {
        'probe': 'GET / over HTTP, expecting status 200 (update path/content expectation after verification).',
        'steps': [
            'Check the expected page path and HTTP status from approved access.',
            'On artifactorium, inspect the web service and application logs.',
            'Check web-root integrity and configuration changes before any service restart.',
            'Recheck the page after a controlled, approved fix.',
        ],
        'caution': 'Do not replace web content, change app credentials, or restart services without understanding scoring impact.',
    },
    'SSH workstation': {
        'probe': 'Checks for an SSH banner; it does not attempt user authentication.',
        'steps': [
            'Confirm TCP reachability and an SSH banner on the configured port.',
            'On ssh-workstation, examine SSH daemon status and authentication logs.',
            'Test an authorized account login before deciding the service is healthy.',
            'Review SSH configuration carefully to avoid locking the team or scoring checker out.',
        ],
        'caution': 'Never disable protected users or remove required SSH access as a quick fix.',
    },
    'AD TCP availability': {
        'probe': 'TCP connection on default Kerberos port 88; not an Active Directory logon.',
        'steps': [
            'Check connectivity to the Team 6 domain controller and verify its required DNS records.',
            'From an authorized Windows host, validate AD and Kerberos using approved credentials.',
            'On the domain controller, inspect AD DS, DNS, time synchronization and related event logs.',
            'Confirm login and directory functionality before considering any configuration change.',
        ],
        'caution': 'Do not restart AD DS, reset domain passwords, or alter protected accounts automatically.',
    },
    'MQTT broker': {
        'probe': 'Attempts an MQTT 3.1.1 connection on default port 1883, without publish/subscribe.',
        'steps': [
            'Confirm the MQTT broker port and whether authentication is required.',
            'From an approved client, check a known-safe publish/subscribe workflow if authorized.',
            'On mqtt (Windows 11), inspect the actual broker service, Windows Firewall and event/application logs.',
            'Verify telemetry flow after an approved fix; a successful connection alone is not sufficient.',
        ],
        'caution': 'MQTT is not Windows MSMQ. The packet does not specify the broker product or exact checker behavior.',
    },
}


def team6_config():
    """Competition defaults from the packet; no network operations."""
    config = build_config(6)
    config['notes'] += ' Ports are standard defaults inferred from protocol, not guaranteed by the packet.'
    config['jumpbox'] = '10.99.6.2'
    return config


def get_playbook(service):
    """Return a copy of the human troubleshooting guide for a scored service."""
    data = PLAYBOOKS.get(service)
    if data is None:
        return None
    original = RECOVERY[service]
    return {
        'machine': original[0], 'os': original[1], 'note': original[2],
        'probe': data['probe'], 'steps': list(data['steps']), 'caution': data['caution'],
    }
