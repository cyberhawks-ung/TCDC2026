import http.client
import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from hawkblock import competition
from hawkblock.dashboard import DashboardState, make_handler


class WebV05Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        config = competition.build_config(8)
        self.state = DashboardState(config['services'], 0.2, config, Path(self.temp.name) / 'board.json')
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.state))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)
        self.temp.cleanup()

    def request(self, method, path, payload=None, token=True):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        headers = {'X-HawkBlock-Token': self.state.token} if token else {}
        body = json.dumps(payload) if payload is not None else None
        if body is not None: headers['Content-Type'] = 'application/json'
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        data = response.read()
        status = response.status
        connection.close()
        return status, (json.loads(data) if path != '/' else data)

    def test_status_includes_eight_hosts_without_schedule(self):
        code, data = self.request('GET', '/api/status')
        self.assertEqual(code, 200)
        self.assertEqual(len(data['hosts']), 8)
        self.assertEqual(len(data['services']), 7)
        self.assertNotIn('can_check', data)
        self.assertNotIn('schedule_note', data)
        self.assertNotIn('schedule', data)
        status, page = self.request('GET', '/')
        self.assertEqual(status, 200)
        self.assertNotIn(b'd.can_check', page)
        self.assertIn(b'id="remote-scan"', page)

    def test_inject_board_http_roundtrip(self):
        self.assertEqual(self.request('POST','/api/tasks/add', {'title':'Test'},token=False)[0],403)
        code, result = self.request('POST','/api/tasks/add', {'title':'Inject 1', 'owner':'Alex'})
        self.assertEqual(code,200)
        task = result['task']
        code, result = self.request('GET','/api/tasks')
        self.assertEqual(len(result['tasks']),1)
        self.assertEqual(result['tasks'][0]['status'],'todo')
        self.assertEqual(self.request('POST','/api/tasks/update', {'id':task['id'], 'status':'doing'})[0],200)
        self.assertEqual(self.request('GET','/api/tasks')[1]['tasks'][0]['status'],'doing')

    def test_check_permitted_with_manual_request(self):
        rows = [{'name': s['name'], 'status': 'ok', 'detail': 'ok'} for s in self.state.services]
        with patch('hawkblock.dashboard.watchdog.run', return_value=rows) as run:
            code, data = self.request('POST','/api/check')
            self.assertEqual(code,200)
            self.assertEqual(len(data['results']),7)
            run.assert_called_once()

if __name__ == '__main__': unittest.main()
