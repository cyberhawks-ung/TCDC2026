import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from hawkblock import competition, auditor
from hawkblock.board import Board
from hawkblock.cli import main
from hawkblock.dashboard import DashboardState


class TCDCConfigTests(unittest.TestCase):
    def test_tcdc_targets_match_packet(self):
        config = competition.build_config(4)
        self.assertEqual(len(config['hosts']), 8)
        self.assertEqual(len(config['services']), 7)
        actual = {s['machine']: s['host'] for s in config['services']}
        self.assertEqual(actual, {
            'ns1': '10.104.10.53', 'ipcam': '10.150.0.4', 'ftp-archive': '10.104.10.21',
            'artifactorium': '10.104.10.80', 'ssh-workstation': '10.104.10.22',
            'ad': '10.104.20.88', 'mqtt': '10.104.30.49',
        })
        self.assertEqual(config['hosts'][0]['host'], '10.104.40.1')
        with self.assertRaises(ValueError): competition.build_config(0)
        with self.assertRaises(ValueError): competition.build_config(100)

    def test_generated_config_has_no_time_window(self):
        config = competition.build_config(4)
        self.assertNotIn('schedule', config)
        self.assertFalse(hasattr(competition, 'allowed_now'))

    def test_setup_makes_config_but_does_not_probe(self):
        with tempfile.TemporaryDirectory() as tmp:
            cwd = os.getcwd()
            try:
                os.chdir(tmp)
                with patch('hawkblock.cli.watchdog.run') as probe, contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(main(['setup','--team','9']), 0)
                    self.assertEqual(main(['setup','--team','9']), 2)
                probe.assert_not_called()
                content = json.loads((Path(tmp)/'config/services.json').read_text())
                self.assertEqual(content['services'][0]['host'],'10.109.10.53')
                self.assertEqual(content['team'],9)
            finally:
                os.chdir(cwd)

    def test_dashboard_manual_check_not_time_gated(self):
        config = competition.build_config(4)
        with tempfile.TemporaryDirectory() as tmp:
            state = DashboardState(config['services'],0.1,config,Path(tmp)/'board.json')
            rows = [{'name': service['name'], 'status': 'ok', 'detail': 'ok'} for service in config['services']]
            with patch('hawkblock.dashboard.watchdog.run', return_value=rows) as probe:
                self.assertNotIn('can_check', state.snapshot())
                self.assertEqual(len(state.check()['results']), 7)
                probe.assert_called_once()


class BoardTests(unittest.TestCase):
    def test_task_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            board = Board(Path(tmp)/'board.json')
            item = board.add({'title':'Submit inject','owner':'Ops'})
            self.assertEqual(len(board.list()),1)
            board.update({'id':item['id'],'status':'doing'})
            self.assertEqual(Board(Path(tmp)/'board.json').list()[0]['status'],'doing')
            with self.assertRaises(ValueError):board.update({'id':item['id'],'status':'invalid'})
            with self.assertRaises(ValueError):board.add({'title':''})

    def test_account_changes_identify_user(self):
        before = {'hostname':'box','accounts':[['alice',{'uid':1000,'shell':'/bin/bash'}]]}
        after = {'hostname':'box','accounts':[['alice',{'uid':1000,'shell':'/bin/zsh'}],['bob',{'uid':1001,'shell':'/bin/bash'}]]}
        changes = auditor.compare(before,after)
        self.assertEqual([(v['item'],v['change']) for v in changes],[('alice','modified'),('bob','added')])

if __name__ == '__main__': unittest.main()
